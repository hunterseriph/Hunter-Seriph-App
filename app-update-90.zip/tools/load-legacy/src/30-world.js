/* =====================================================================================================
   WORLD: a grid of one-screen rooms (32x16 tiles). Each run gets a new seed, so the castle rebuilds itself.
   Tiles: 0 air, 1 wall, 2 one-way ledge, 3 spikes, 4 illusion wall (looks solid, walk through),
          5 illusion ledge (gives way under you), 6 barrier (solid only while a fight has the room locked)
   ===================================================================================================== */
var TA = 0, TW = 1, TL = 2, TS = 3, TF = 4, TV = 5, TB = 6, TG = 7;
var WORLD = null;
function key2(x, y) { return x + ',' + y; }
var DIRV = { l: [-1, 0], r: [1, 0], u: [0, -1], d: [0, 1] }, OPP = { l: 'r', r: 'l', u: 'd', d: 'u' };

function genWorld(seed, castle) {
  var r = mulberry(seed), rooms = {}, CK = CASTLES[castle] ? castle : 'cum', CS = CASTLES[CK], HUB = CS.hub, UP = CS.up, DN = CS.down, RT = CS.right, home = CK === 'cum';
  function inArea(a, x, y) { var A = AREAS[a]; return x >= A.ox && y >= A.oy && x < A.ox + A.w && y < A.oy + A.h; }
  function add(a, x, y) { var k = key2(x, y); if (!rooms[k]) rooms[k] = { cx: x, cy: y, area: a, type: 'normal', ex: {} }; return rooms[k]; }
  function link(a, b, d) { a.ex[d] = 1; b.ex[OPP[d]] = 1; }
  function walkTo(a, from, tx, ty) { // a wandering but always-arriving path inside an area
    var x = from.cx, y = from.cy, cur = from, guard = 0;
    while ((x !== tx || y !== ty) && guard++ < 200) {
      var opts = []; if (x < tx) opts.push('r'); if (x > tx) opts.push('l'); if (y < ty) opts.push('d'); if (y > ty) opts.push('u');
      if (r() < 0.25) { var side = ['l', 'r', 'u', 'd'][Math.floor(r() * 4)], nx = x + DIRV[side][0], ny = y + DIRV[side][1]; if (inArea(a, nx, ny)) opts = [side]; }
      var d = opts[Math.floor(r() * opts.length)]; x += DIRV[d][0]; y += DIRV[d][1];
      var nx2 = add(a, x, y); link(cur, nx2, d); cur = nx2;
    }
    return cur;
  }
  function grow(a, n) {
    var list = Object.keys(rooms).map(function (k) { return rooms[k]; }).filter(function (q) { return q.area === a; }), tries = 0;
    while (list.length < n && tries++ < 600) {
      var s = list[Math.floor(r() * list.length)], d = ['l', 'r', 'u', 'd'][Math.floor(r() * 4)], nx = s.cx + DIRV[d][0], ny = s.cy + DIRV[d][1];
      if (!inArea(a, nx, ny) || rooms[key2(nx, ny)]) continue;
      var q = add(a, nx, ny); link(s, q, d); list.push(q);
    }
    // a few loops so it is not a pure tree
    list.forEach(function (q) { ['r', 'd'].forEach(function (d) { var o = rooms[key2(q.cx + DIRV[d][0], q.cy + DIRV[d][1])]; if (o && o.area === a && !q.ex[d] && r() < 0.18) link(q, o, d); }); });
    return list;
  }
  // the start room sits on the castle's left edge: nothing lies to the left of it
  var C = AREAS[HUB], start = add(HUB, C.ox, C.oy + 2); start.type = 'start';
  // connectors out of the castle
  var upX = C.ox + 1 + Math.floor(r() * 4), dnX = C.ox + 1 + Math.floor(r() * 4), rtY = C.oy + Math.floor(r() * C.h);
  // the starting room opens up, down and right, and each way leads on towards its own area
  var sU = add(HUB, start.cx, start.cy - 1), sD = add(HUB, start.cx, start.cy + 1), sR = add(HUB, start.cx + 1, start.cy);
  link(start, sU, 'u'); link(start, sD, 'd'); link(start, sR, 'r');
  var cu = walkTo(HUB, sU, upX, C.oy), cd = walkTo(HUB, sD, dnX, C.oy + C.h - 1), cr = walkTo(HUB, sR, C.ox + C.w - 1, rtY);
  start.signs = { u: UP, d: DN, r: RT };
  grow(HUB, C.rooms);
  var ru = add(UP, upX, C.oy - 1); link(cu, ru, 'u'); ru.entry = 1;
  var dd = add(DN, dnX, C.oy + C.h); link(cd, dd, 'd'); dd.entry = 1;
  var cc = add(RT, C.ox + C.w, rtY); link(cr, cc, 'r'); cc.entry = 1;
  grow(UP, AREAS[UP].rooms); grow(RT, AREAS[RT].rooms); grow(DN, AREAS[DN].rooms);
  // the secret area (only in Cumhead's Castle): not joined to the map at all. A hidden portal leads there.
  var me = null; if (home) { var M = AREAS.moon; me = add('moon', M.ox, M.oy + 1 + Math.floor(r() * 2)); me.entry = 1; me.type = 'moongate'; grow('moon', M.rooms); }
  // special rooms per area, chosen from the rooms furthest from the way in
  castleAreas(CK).concat(home ? ['moon'] : []).forEach(function (a) {
    var list = Object.keys(rooms).map(function (k) { return rooms[k]; }).filter(function (q) { return q.area === a; });
    var src = a === HUB ? start : list.filter(function (q) { return q.entry; })[0], dist = {}, qu = [src]; dist[key2(src.cx, src.cy)] = 0;
    while (qu.length) { var q = qu.shift(), dq = dist[key2(q.cx, q.cy)]; for (var d in q.ex) { var o = rooms[key2(q.cx + DIRV[d][0], q.cy + DIRV[d][1])]; if (o && dist[key2(o.cx, o.cy)] === undefined) { dist[key2(o.cx, o.cy)] = dq + 1; qu.push(o); } } }
    list.forEach(function (q) { q.dist = dist[key2(q.cx, q.cy)] || 0; });
    var free = list.filter(function (q) { return q.type === 'normal' && !q.entry && q !== start; }), moonA = a === 'moon';
    function deg(q) { return Object.keys(q.ex).length; }
    free.sort(function (p, q) { return (q.dist + (deg(q) === 1 ? 3 : 0)) - (p.dist + (deg(p) === 1 ? 3 : 0)); });
    var boss = free.shift(); if (boss) boss.type = 'bossdoor';
    shuffle(free, r);
    if (moonA) { ['merchant', 'shrine', 'powerup', 'challenge', 'ambush'].forEach(function (t) { var q = free.shift(); if (q) q.type = t; }); return; }
    var want = ['merchant', 'powerup', 'challenge', 'trap', 'illusion', 'shrine'].concat(AREAS[a].special || []), extra = ['powerup', 'challenge', 'trap', 'ambush', 'saws', 'crumble', 'cell', 'feast', 'saws', 'cell'].concat(moreTypes(a)); shuffle(extra, r); extra = extra.filter(function (t, i) { return extra.indexOf(t) === i; }); if (r() < 0.7) want.push('gamble'); want.push(extra[0]); want.push(extra[1]); if (r() < 0.8) want.push(extra[2]); if (r() < 0.6) want.push(extra[3]); if (r() < 0.4) want.push(extra[4]);
    want.forEach(function (t) { var q = free.shift(); if (q) q.type = t; });
    if (a === 'city') { // the Load Flume: four screens long, laid along one row of the park. Empty cells are filled in; cells already in use must be plain and have no way down
      var CA = AREAS.city, best = null, okC = function (x, y) { var q = rooms[key2(x, y)]; return !q || (q.area === 'city' && free.indexOf(q) >= 0 && !q.ex.d); };
      for (var len = 4; len >= 2 && !best; len--) { var cands = [];
        for (var fy = CA.oy; fy < CA.oy + CA.h; fy++) for (var fx = CA.ox; fx + len <= CA.ox + CA.w; fx++) { var ok = true, have = 0; for (var k2 = 0; k2 < len; k2++) { if (!okC(fx + k2, fy)) ok = false; else if (rooms[key2(fx + k2, fy)]) have++; } if (ok && have) cands.push([fx, fy, len]); }
        if (cands.length) best = cands[Math.floor(r() * cands.length)]; }
      if (best) {
        var n = best[2], cellsF = [];
        for (var k3 = 0; k3 < n; k3++) { var q3 = rooms[key2(best[0] + k3, best[1])]; if (q3) free.splice(free.indexOf(q3), 1); cellsF.push(q3 || { cx: best[0] + k3, cy: best[1], ex: {} }); }
        var FR = { cx: best[0], cy: best[1], cw: n, ch: 1, area: 'city', type: 'flume', ex: {}, exits: [], dist: 0, long: n };
        cellsF.forEach(function (q, i) { FR.dist = Math.max(FR.dist, q.dist || 0); for (var d in q.ex) { if ((d === 'r' && i < n - 1) || (d === 'l' && i > 0)) continue; FR.exits.push({ d: d, i: (d === 'u' || d === 'd') ? i : 0 }); FR.ex[d] = 1; } rooms[key2(q.cx, q.cy)] = FR; });
      } else { var fq = free.filter(function (q) { return !q.ex.d; })[0] || free[0]; if (fq) { fq.type = 'flume'; free.splice(free.indexOf(fq), 1); } }
    }
  });
  // some neighbouring plain rooms join into one big room: two screens wide, or two screens tall
  var list = Object.keys(rooms).map(function (k) { return rooms[k]; });
  function plain(q) { return q && q.type === 'normal' && !q.entry && !q.big && q !== start && Math.abs(q.cx - start.cx) + Math.abs(q.cy - start.cy) > 1; }
  shuffle(list, r);
  list.forEach(function (q) {
    if (rooms[key2(q.cx, q.cy)] !== q || !plain(q) || r() > 0.42) return;
    var opts = []; if (q.ex.r && plain(rooms[key2(q.cx + 1, q.cy)]) && rooms[key2(q.cx + 1, q.cy)].area === q.area) opts.push('r'); if (q.ex.d && plain(rooms[key2(q.cx, q.cy + 1)]) && rooms[key2(q.cx, q.cy + 1)].area === q.area) opts.push('d');
    if (!opts.length) return;
    var d = opts[Math.floor(r() * opts.length)], o = rooms[key2(q.cx + DIRV[d][0], q.cy + DIRV[d][1])], wide = d === 'r';
    var R = { cx: q.cx, cy: q.cy, cw: wide ? 2 : 1, ch: wide ? 1 : 2, area: q.area, type: 'normal', ex: {}, big: wide ? 'wide' : 'tall', exits: [], dist: Math.max(q.dist || 0, o.dist || 0) };
    for (var e1 in q.ex) if (e1 !== d) R.exits.push({ d: e1, i: 0 });
    for (var e2 in o.ex) if (e2 !== OPP[d]) R.exits.push({ d: e2, i: (wide ? (e2 === 'u' || e2 === 'd') : (e2 === 'l' || e2 === 'r')) ? 1 : 0 });
    rooms[key2(q.cx, q.cy)] = R; rooms[key2(o.cx, o.cy)] = R;
  });
  // one illusion room somewhere hides the portal in its alcove
  var ill = Object.keys(rooms).map(function (k) { return rooms[k]; }).filter(function (q) { return q.type === 'illusion'; });
  var pr = home ? ill[Math.floor(r() * ill.length)] : null; if (pr) pr.portal = 1;
  // Blumhead's Lair (Cumhead's Castle only): not joined to the map. You are dragged down into it after Super Blumhead falls (five wins on).
  var le = null; if (home) (function () {
    var LA = AREAS.lair; le = add('lair', LA.ox, LA.oy + 1); le.entry = 1; le.type = 'lairgate'; var llist = grow('lair', LA.rooms);
    var dist = {}, qu = [le]; dist[key2(le.cx, le.cy)] = 0;
    while (qu.length) { var q = qu.shift(), dq = dist[key2(q.cx, q.cy)]; for (var d in q.ex) { var o = rooms[key2(q.cx + DIRV[d][0], q.cy + DIRV[d][1])]; if (o && o.area === 'lair' && dist[key2(o.cx, o.cy)] === undefined) { dist[key2(o.cx, o.cy)] = dq + 1; qu.push(o); } } }
    llist.forEach(function (q) { q.dist = dist[key2(q.cx, q.cy)] || 0; });
    var fr = llist.filter(function (q) { return q !== le; }).sort(function (p, q) { return q.dist - p.dist; });
    var mega = fr.shift(); if (mega) mega.type = 'megadoor';
    var bs = shuffle(['beast', 'demon', 'sperm', 'pig'], r), picked = [];
    // the four guardians spread out: each one at least two cells from the others where possible
    fr.forEach(function (q) { if (picked.length < 4 && picked.every(function (p) { return Math.abs(p.cx - q.cx) + Math.abs(p.cy - q.cy) > 1; }) && Math.abs(q.cx - mega.cx) + Math.abs(q.cy - mega.cy) > 1) picked.push(q); });
    fr.forEach(function (q) { if (picked.length < 4 && picked.indexOf(q) < 0) picked.push(q); });
    picked.forEach(function (q, i) { q.type = 'bossdoor'; q.boss = bs[i]; });
    var rest = shuffle(fr.filter(function (q) { return q.type === 'normal'; }), r);
    ['merchant', 'shrine', 'powerup', 'goorise', 'eyewall', 'heart', 'goorise', 'eyewall', 'heart', 'challenge'].forEach(function (t) { var q = rest.shift(); if (q) q.type = t; });
  })();
  var uniq = []; Object.keys(rooms).forEach(function (k) { if (uniq.indexOf(rooms[k]) < 0) uniq.push(rooms[k]); });
  uniq.forEach(function (q, i) { q.id = i; if (!q.exits) { q.exits = []; for (var d in q.ex) q.exits.push({ d: d, i: 0 }); } });
  return { seed: seed, castle: CK, rooms: rooms, list: uniq, start: key2(start.cx, start.cy), moonEntry: me ? key2(me.cx, me.cy) : null, lairEntry: le ? key2(le.cx, le.cy) : null, portalFrom: pr ? key2(pr.cx, pr.cy) : null };
}

/* ---------- building one room's tiles and contents (deterministic per room) ---------- */
function roomRng(rm) { return mulberry(hash2(WORLD.seed, rm.cx + 50, rm.cy + 50)); }
function buildRoom(rm) {
  var W = CW * (rm.cw || 1), H = CH * (rm.ch || 1), tl = new Uint8Array(W * H), res = new Uint8Array(W * H), ents = [], r = roomRng(rm), A = AREAS[rm.area];
  function S(x, y, v) { if (x >= 0 && y >= 0 && x < W && y < H) tl[y * W + x] = v; }
  function G(x, y) { return (x < 0 || y < 0 || x >= W || y >= H) ? TW : tl[y * W + x]; }
  function RS(x0, y0, x1, y1) { for (var y = y0; y <= y1; y++) for (var x = x0; x <= x1; x++) if (x >= 0 && y >= 0 && x < W && y < H) res[y * W + x] = 1; }
  function free(x0, y0, x1, y1) { for (var y = y0; y <= y1; y++) for (var x = x0; x <= x1; x++) { if (x < 1 || y < 1 || x > W - 2 || y > H - 2) return false; if (res[y * W + x] || tl[y * W + x] !== TA) return false; } return true; }
  function rn(a, b) { return a + Math.floor(r() * (b - a + 1)); }
  for (var x = 0; x < W; x++) { S(x, 0, TW); S(x, H - 1, TW); }
  for (var y = 0; y < H; y++) { S(0, y, TW); S(W - 1, y, TW); }
  var ex = rm.ex;
  // the openings: rows 12-14 on the sides, columns 14-17 top and bottom, in whichever screen of a big room they belong to
  (rm.exits || []).forEach(function (e) {
    var oy = e.i * CH, ox = e.i * CW;
    if (e.d === 'l') { for (y = oy + 12; y <= oy + 14; y++) S(0, y, TA); RS(0, oy + 10, 4, oy + 14); }
    if (e.d === 'r') { for (y = oy + 12; y <= oy + 14; y++) S(W - 1, y, TA); RS(W - 5, oy + 10, W - 1, oy + 14); }
    if (e.d === 'u') { for (x = ox + 14; x <= ox + 17; x++) S(x, 0, TA); RS(ox + 12, 0, ox + 19, 3); }
    if (e.d === 'd') { for (x = ox + 14; x <= ox + 17; x++) S(x, H - 1, TG); RS(ox + 12, H - 6, ox + 19, H - 1); }
  });
  function plat(x0, x1, y, v) { for (var x = x0; x <= x1; x++) S(x, y, v || TL); RS(x0, y - 3, x1, y - 1); RS(x0, y, x1, y); }
  if (rm.big) bigRoom();
  function bigRoom() {
    var segs = rm.big === 'wide' ? 2 : 1, s2, x, y;
    if (rm.big === 'tall') {
      // a tall shaft: ledges zig-zag up to the top screen, with a landing beside each high exit
      var cols = [[4, 9], [11, 16], [18, 23], [11, 16]], k = 0;
      for (y = H - 5; y >= 4; y -= 4) { var c2 = cols[k % 4]; if (free(c2[0], y - 2, c2[1], y)) plat(c2[0], c2[1], y); k++; }
      rm.exits.forEach(function (e) {
        if (e.d === 'l' && e.i === 0) plat(1, 5, CH - 1); if (e.d === 'r' && e.i === 0) plat(W - 6, W - 2, CH - 1);
        if (e.d === 'u') { plat(9, 13, 8); plat(18, 22, 4); }
      });
      for (var sp = 0; sp < 2; sp++) { var sx = rn(5, W - 8); var okS = true; for (x = sx; x < sx + 2; x++) if (res[(H - 2) * W + x] || G(x, H - 2) !== TA) okS = false; if (okS && r() < 0.6) { for (x = sx; x < sx + 2; x++) S(x, H - 2, TS); RS(sx, H - 3, sx + 1, H - 2); } }
    } else {
      rm.exits.forEach(function (e) { if (e.d === 'u') { var ox = e.i * CW; plat(ox + 9, ox + 13, 12); plat(ox + 18, ox + 22, 8); plat(ox + 12, ox + 16, 4); } }); // a way up to each exit in the ceiling
      for (s2 = 0; s2 < segs; s2++) {
        var ox = s2 * CW;
        var nb = rn(1, 3); for (var bi = 0; bi < nb; bi++) { var bw = rn(2, 4), bh = rn(1, 2), bx = ox + rn(4, 27 - bw); if (free(bx, 15 - bh, bx + bw - 1, 14) && free(bx, 15 - bh - 2, bx + bw - 1, 15 - bh - 1)) { for (y = 15 - bh; y <= 14; y++) for (x = bx; x < bx + bw; x++) S(x, y, TW); RS(bx, 15 - bh - 2, bx + bw - 1, 14); } }
        var np = rn(2, 4); for (var pi = 0; pi < np; pi++) { var pw = rn(3, 6), py = rn(6, 11), px = ox + rn(3, 28 - pw); if (free(px - 1, py - 2, px + pw, py + 1)) plat(px, px + pw - 1, py); }
        var ns = rn(0, 2); for (var si = 0; si < ns; si++) { var sw = rn(2, 3), sx2 = ox + rn(5, 26 - sw), okS2 = true; for (x = sx2; x < sx2 + sw; x++) if (res[14 * W + x] || G(x, 14) !== TA || G(x, 15) !== TW) okS2 = false; if (okS2) { for (x = sx2; x < sx2 + sw; x++) S(x, 14, TS); RS(sx2, 13, sx2 + sw - 1, 14); } }
      }
      // a high walkway across the middle of a wide hall, with a chest on it sometimes
      if (r() < 0.6) { var wy = rn(7, 8), w0 = CW - 6, w1 = CW + 5; if (free(w0, wy - 2, w1, wy) && free(w0 - 5, wy + 2, w0 - 1, wy + 4)) { plat(w0, w1, wy); plat(w0 - 5, w0 - 1, wy + 4); if (r() < 0.5) ents.push({ k: 'chest', x: CW * T, y: wy * T }); } }
    }
  }
  if (ex.u) { plat(9, 13, 12); plat(18, 22, 8); plat(12, 16, 4); }
  var forceDark = 0, t = rm.type, nE = 0, cx0 = ex.d ? 23 : 16, cxp = cx0 * T;
  if (rm.big) { t = 'big'; nE = 3 + Math.floor(A.tier / 2) + (rm.big === 'wide' ? 2 : 1); }
  if (t === 'start') {
    ents.push({ k: 'door', x: cxp, y: 15 * T, w: 48, h: 64, boss: CASTLES[(WORLD && WORLD.castle) || curCastle()].final }); RS(cx0 - 5, 9, cx0 + 4, 14);
    ents.push({ k: 'deco', d: 'throneL', x: 6 * T, y: 15 * T }); ents.push({ k: 'deco', d: 'throneR', x: 26 * T, y: 15 * T });
  } else if (t === 'bossdoor') {
    ents.push({ k: 'door', x: cxp, y: 15 * T, w: 48, h: 64, boss: rm.boss || A.boss, lair: rm.area === 'lair' ? 1 : 0 }); RS(cx0 - 5, 9, cx0 + 4, 14);
  } else if (t === 'megadoor') { // the last door in the lair: Mega Blumhead
    ents.push({ k: 'door', x: cxp, y: 15 * T, w: 48, h: 64, boss: 'mega', lair: 1 }); RS(cx0 - 5, 9, cx0 + 4, 14);
  } else if (t === 'lairgate') { // where you land in the lair
    ents.push({ k: 'deco', d: 'lairsign', x: 16 * T, y: 3 * T }); ents.push({ k: 'shrine', x: 24 * T, y: 15 * T }); RS(21, 10, 27, 14); nE = 0;
  } else if (t === 'goorise') { // goo floods the room every few seconds: climb out of it
    var top = 5; ents.push({ k: 'goo', t: r() * 3, top: top, lv: 15 * T });
    [[3, 7, 11], [11, 15, 9], [19, 23, 11], [25, 28, 8], [6, 10, 7], [14, 18, 5], [21, 24, 4]].forEach(function (p) { if (free(p[0], p[2] - 2, p[1], p[2])) plat(p[0], p[1], p[2]); });
    nE = 2;
  } else if (t === 'eyewall') { // a huge eye in the back wall: a red line shows where its beam will go
    ents.push({ k: 'walleye', x: 16 * T, y: 3 * T + 4, t: r() * 2, by: 0 });
    [[4, 8, 12], [12, 15, 9], [18, 21, 12], [23, 27, 9], [8, 11, 6], [20, 23, 6]].forEach(function (p) { if (free(p[0], p[2] - 2, p[1], p[2])) plat(p[0], p[1], p[2]); });
    nE = 2;
  } else if (t === 'heart') { // a beating Blum heart: kill it to get the chest inside
    ents.push({ k: 'enemy', e: 'lheart', x: cxp, y: 15 * T, idx: 90 }); RS(cx0 - 3, 11, cx0 + 3, 14);
    plat(5, 9, 11); plat(22, 26, 11); nE = 1;
  } else if (t === 'merchant') {
    var who = MERCH[Math.floor(r() * MERCH.length)]; if (RUN && who === 'npc_' + RUN.cls) who = 'npc_jessiah'; // the heir you are playing does not also run a stall
    ents.push({ k: 'npc', x: cxp, y: 15 * T, who: who }); RS(cx0 - 4, 10, cx0 + 4, 14);
  } else if (t === 'powerup') {
    ents.push({ k: 'altar', x: cxp, y: 15 * T }); RS(cx0 - 4, 10, cx0 + 4, 14);
  } else if (t === 'challenge') {
    ents.push({ k: 'trigger', x0: 6 * T, x1: 26 * T });
    plat(5, 9, 10); plat(22, 26, 10); if (!ex.u) plat(13, 18, 7);
  } else if (t === 'trap') {
    for (x = 5; x <= 26; x++) if (!res[14 * W + x] && G(x, 15) === TW) S(x, 14, TS);
    var pxs = [[5, 8, 11], [11, 14, 10], [17, 20, 11], [23, 26, 10]];
    pxs.forEach(function (p) { if (free(p[0], p[2], p[1], p[2])) plat(p[0], p[1], p[2]); });
    ents.push({ k: 'turret', x: 1 * T + 6, y: rn(5, 8) * T + 8, dir: 1, cd: r() * 2 }); ents.push({ k: 'turret', x: (W - 1) * T - 6, y: rn(5, 8) * T + 8, dir: -1, cd: 1 + r() * 2 });
    var cp = [[14, 9], [16, 7]]; for (var ci = 0; ci < cp.length; ci++) if (free(cp[ci][0] - 1, cp[ci][1] - 2, cp[ci][0] + 1, cp[ci][1])) { plat(cp[ci][0] - 1, cp[ci][0] + 1, cp[ci][1]); ents.push({ k: 'chest', x: cp[ci][0] * T + 8, y: cp[ci][1] * T, big: 1 }); break; }
    if (ci === cp.length) ents.push({ k: 'chest', x: 3 * T, y: 15 * T, big: 1 });
  } else if (t === 'flume') {
    // the Load Flume: a long channel of cream (up to four screens) with boats drifting left to right. Ride them; falling in hurts.
    var nS = W / CW, wx1 = W - 4;
    ents.push({ k: 'water', x0: 4 * T, x1: wx1 * T, y: 13 * T + 6 });
    var nb2 = Math.max(3, Math.round((wx1 - 4) / 8.5)), gap = (wx1 - 4) * T / nb2;
    for (var lg = 0; lg < nb2; lg++) ents.push({ k: 'log', x: 4 * T + 34 + lg * gap, y: 13 * T + 15, w: 52, h: 11, vx: 52, sink: lg % 3 === 1 ? 1 : 0 }); /* every third boat is leaky and goes under now and then */
    ents.push({ k: 'deco', d: 'flumesign', x: 16 * T, y: 2 * T + 4 });
    for (var qy = 6; qy < H - 1; qy++) if (G(2, qy) === TA && G(2, qy + 1) === TW) { ents.push({ k: 'deco', d: 'tallsign', x: 3 * T + 4, y: (qy + 1) * T }); break; } /* Steve checks your height, by the queue rails */
    RS(3, 11, W - 4, 15);
    plat(5, 7, 12); plat(W - 8, W - 6, 12); /* low steps off the banks */
    for (var fs = 0; fs < nS; fs++) {
      var fo = fs * CW, hasU = (rm.exits || []).some(function (e) { return e.d === 'u' && e.i === fs; });
      if (hasU) { plat(fo + 9, fo + 13, 12); plat(fo + 18, fo + 22, 8); plat(fo + 12, fo + 16, 4); continue; } /* a way up to an exit in the ceiling */
      // otherwise a few perches over the cream: you cannot walk it, you have to ride
      var perch = [[fo + 8, fo + 10, 10], [fo + 15, fo + 17, 8], [fo + 22, fo + 24, 10]];
      perch.forEach(function (p, pi) { if (r() < 0.75 && free(p[0], p[2] - 2, p[1], p[2])) { plat(p[0], p[1], p[2]); if (pi === 1 && r() < 0.5) ents.push({ k: 'chest', x: (p[0] + 1) * T + 8, y: p[2] * T, big: fs === nS - 1 ? 1 : 0 }); } });
    }
    ents.push({ k: 'chest', x: (W - 3) * T, y: 15 * T, big: 1 }); /* the prize at the end of the ride */
    nE = 1 + nS;
  } else if (t === 'egate') { // the first screen of Endless: a sign, nothing to fight
    ents.push({ k: 'deco', d: 'esign', x: 16 * T, y: 4 * T }); nE = 0;
  } else if (t === 'moongate') {
    ents.push({ k: 'portal', x: cxp, y: 15 * T, back: 1 }); RS(cx0 - 4, 9, cx0 + 4, 14); nE = 0;
  } else if (t === 'saws') {
    // saw blades running back and forth on rails; a chest waits at the far end
    var far = ex.r && !ex.l ? 3 : 28;
    plat(5, 10, 11); plat(21, 26, 11); plat(13, 18, 8); /* every climb in here is 3 tiles or less */
    ents.push({ k: 'saw', x: 6 * T, x0: 6 * T, x1: 26 * T, y: 14 * T + 6, sp: 70 + 15 * A.tier, ph: 0 });
    ents.push({ k: 'saw', x: 5 * T, x0: 5 * T, x1: 26 * T, y: 9 * T - 2, sp: 50 + 10 * A.tier, ph: 0.5 });
    if (r() < 0.6) ents.push({ k: 'saw', x: 13 * T, x0: 13 * T, x1: 18 * T + 8, y: 7 * T - 2, sp: 40, ph: 0.25 });
    ents.push({ k: 'chest', x: 16 * T, y: 8 * T, big: 1 }); nE = 1;
  } else if (t === 'crumble') {
    // a floor of spikes, and above it a long run of ledges that give way under you. Do not stop.
    for (x = 5; x <= W - 6; x++) if (!res[14 * W + x] && G(x, 15) === TW) S(x, 14, TS);
    for (x = 4; x <= W - 5; x++) if (G(x, 11) === TA && !res[11 * W + x]) { S(x, 11, TV); ents.push({ k: 'drop', x: x * T + 8, y: 11 * T - 10 }); }
    RS(4, 8, W - 5, 11); plat(W - 5 < 27 ? 26 : 26, 28, 11);
    ents.push({ k: 'chest', x: 27 * T + 8, y: 11 * T, big: 1 }); nE = 1 + Math.floor(A.tier / 2);
  } else if (t === 'cell') {
    // someone is locked in a cell. Break them out and they give you something for it.
    ents.push({ k: 'cell', x: cxp, y: 15 * T, who: MERCH[Math.floor(r() * MERCH.length)] }); RS(cx0 - 4, 9, cx0 + 4, 14); nE = 2 + Math.floor(A.tier / 2);
  } else if (t === 'feast') {
    // a long table laid out. Eat one dish; the rest goes cold.
    ents.push({ k: 'feast', x: cxp, y: 15 * T }); RS(cx0 - 5, 11, cx0 + 5, 14); nE = 1;
  } else if (t === 'shrine') {
    // a blood fountain: pray once to heal
    ents.push({ k: 'shrine', x: cxp, y: 15 * T }); RS(cx0 - 4, 9, cx0 + 4, 14); nE = 1;
  } else if (t === 'gamble') {
    // a slot machine (Steve's prize wheel in Ejaculand): pay drops, pull, hope
    ents.push({ k: 'gamble', x: cxp, y: 15 * T, park: rm.area === 'city' }); RS(cx0 - 4, 8, cx0 + 4, 14); nE = 1;
  } else if (t === 'ambush') {
    // a lonely chest in the middle of the room. Opening it locks the doors.
    ents.push({ k: 'chest', x: cxp, y: 15 * T, big: 1, ambush: 1 }); RS(cx0 - 3, 11, cx0 + 3, 14);
    plat(5, 9, 10); plat(22, 26, 10); nE = 0;
  } else if (t === 'illusion') {
    var right = !ex.r || r() < 0.5, mx0 = right ? 23 : 1, mx1 = right ? 30 : 8;
    if (ex.u && !right) { mx0 = 1; mx1 = 8; }
    for (y = 3; y <= 8; y++) for (x = mx0; x <= mx1; x++) S(x, y, TW);
    var ax0 = right ? mx0 + 1 : mx0, ax1 = right ? mx1 : mx1 - 1;
    for (y = 5; y <= 7; y++) for (x = ax0; x <= ax1; x++) S(x, y, TF);
    var fw = right ? mx0 : mx1; for (y = 5; y <= 7; y++) S(fw, y, TF);
    RS(mx0 - 1, 3, mx1 + 1, 8);
    var ex0 = right ? mx0 - 5 : mx1 + 1, ex1 = right ? mx0 - 1 : mx1 + 5; for (x = ex0; x <= ex1; x++) if (G(x, 8) === TA) S(x, 8, TL);
    RS(ex0, 5, ex1, 8);
    var sx0 = right ? mx0 - 10 : mx1 + 6, sx1 = sx0 + 4; for (x = sx0; x <= sx1; x++) if (G(x, 11) === TA) S(x, 11, TL); RS(sx0, 8, sx1, 11);
    if (rm.portal) ents.push({ k: 'portal', x: ((ax0 + ax1) / 2 | 0) * T + 8, y: 8 * T });
    else ents.push({ k: 'chest', x: ((ax0 + ax1) / 2 | 0) * T + 8, y: 8 * T, big: 1, secret: 1 });
    for (x = ax0; x <= ax1; x++) ents.push({ k: 'drop', x: x * T + 8, y: 7 * T - 2 });
    for (var fv = 0; fv < 3; fv++) { var fx = rn(4, 24), fy = rn(9, 11); if (free(fx, fy, fx + 3, fy)) { for (x = fx; x <= fx + 3; x++) S(x, fy, TV); RS(fx, fy - 2, fx + 3, fy); } }
    nE = 1 + Math.floor(A.tier / 2);
  } else if (moreRoom(t)) { /* the newer rooms, below */
  } else if (castleRoom(t)) { /* the castles' own rooms, below */
  } else if (t !== 'big') nE = 2 + Math.floor(A.tier / 2) + (r() < 0.5 ? 1 : 0);
  function moreRoom(t) {
    var far = ex.r && !ex.l ? 3 : 28, i, walkers = A.pool.filter(function (p) { return ENEMIES[p[0]] && !isFlyer(ENEMIES[p[0]]); });
    function walker() { return walkers.length ? walkers[Math.floor(r() * walkers.length)][0] : 'crawler'; }
    function chestOn(x, y, big) { ents.push({ k: 'chest', x: x * T + 8, y: y * T, big: big ? 1 : 0 }); }
    if (t === 'gauntlet') { // two axes swing over the floor while a saw runs along it: run the gauntlet to the chest
      ents.push({ k: 'pend', x: 11 * T + 8, y: T + 4, len: 11 * T, ph: r() * 3 }); ents.push({ k: 'pend', x: 21 * T + 8, y: T + 4, len: 11 * T, ph: 1.6 + r() });
      ents.push({ k: 'saw', x: 6 * T, x0: 6 * T, x1: 26 * T, y: 14 * T + 6, sp: 55 + 10 * A.tier, ph: r() });
      RS(3, 1, W - 4, 13); plat(3, 5, 12); plat(26, 28, 12); plat(14, 18, 8);
      chestOn(far, 15, 1); nE = 1; return true;
    }
    if (t === 'climb') { // the chest is right up under the ceiling: ledges zig-zag up to it, with things flying round
      var cl = [[4, 9, 12], [12, 16, 9], [5, 10, 6], [13, 18, 4]], ok = 0;
      if (ex.u) cl = [[4, 9, 12], [22, 27, 9], [21, 25, 6], [25, 28, 4]];
      cl.forEach(function (p) { if (free(p[0], p[2] - 2, p[1], p[2])) { plat(p[0], p[1], p[2]); ok++; } });
      var top = cl[3]; if (ok === 4) chestOn(top[0] + 2, top[2], 1); else chestOn(far, 15, 1);
      ents.push({ k: 'drip', x: 22 * T + 8, y: T, cd: 2 }); nE = 2 + Math.floor(A.tier / 2); return true;
    }
    if (t === 'crypt') { // coffins along the floor and on the ledges, each one hiding one of this place's own
      [5, 11, 21, 27].forEach(function (cfx) { if (G(cfx, 15) === TW) ents.push({ k: 'coffin', x: cfx * T + 8, y: 15 * T, who: walker() }); });
      RS(3, 11, 29, 14); plat(7, 10, 11); plat(22, 25, 11); plat(14, 18, 8);
      ents.push({ k: 'coffin', x: 8 * T + 8, y: 11 * T, who: walker() }); ents.push({ k: 'coffin', x: 23 * T + 8, y: 11 * T, who: walker() });
      chestOn(16, 8, 1); nE = 0; return true;
    }
    if (t === 'briar') { // thorns burst up in a wave along the floor, both ways; the ledges are the safe spots
      for (i = 0; i < 8; i++) ents.push({ k: 'vine', x: (6 + i * 3) * T + 8, y: 15 * T, t: (i < 4 ? i : 7 - i) * 0.45 });
      RS(5, 10, 28, 14); plat(4, 6, 12); plat(10, 12, 11); plat(15, 17, 12); plat(20, 22, 11); plat(26, 28, 12); plat(13, 19, 8);
      chestOn(16, 8, 1); nE = 1; return true;
    }
    if (t === 'rods') { // lightning rods in a row: the sky hits them one after another
      [6, 11, 16, 21, 26].forEach(function (rx, k) { ents.push({ k: 'rod', x: rx * T + 8, y: 15 * T, t: k * 0.7 }); });
      RS(5, 10, 27, 14); plat(8, 9, 12); plat(13, 14, 12); plat(18, 19, 12); plat(23, 24, 12); plat(12, 20, 9);
      chestOn(16, 9, 1); nE = 2; return true;
    }
    if (t === 'factory') { // belts everywhere, all fighting you, over a hot hob in the middle
      ents.push({ k: 'belt', x: 3 * T, x0: 3 * T, x1: 13 * T, y: 15 * T, dir: -1 }); ents.push({ k: 'belt', x: 19 * T, x0: 19 * T, x1: 29 * T, y: 15 * T, dir: 1 });
      for (x = 13; x <= 18; x++) if (G(x, 15) === TW && !res[14 * W + x]) S(x, 14, TS);
      RS(3, 13, 29, 14); plat(5, 10, 12); plat(21, 26, 12); plat(11, 20, 9);
      ents.push({ k: 'belt', x: 11 * T, x0: 11 * T, x1: 20 * T, y: 9 * T, dir: r() < 0.5 ? 1 : -1 });
      chestOn(16, 9, 1); nE = 2; return true;
    }
    if (t === 'padpit') { // a floor of spikes. Bounce pads are the only way across, and the prize hangs high
      [9, 16, 23].forEach(function (px) { if (G(px, 15) === TW) ents.push({ k: 'pad', x: px * T + 8, y: 15 * T, jelly: rm.area === 'gfair' ? 1 : 0 }); });
      for (x = 5; x <= W - 6; x++) if (G(x, 15) === TW && !res[14 * W + x] && [8, 9, 10, 15, 16, 17, 22, 23, 24].indexOf(x) < 0) S(x, 14, TS);
      RS(5, 3, W - 6, 14); plat(4, 7, 11); plat(24, 27, 11); plat(9, 12, 8); plat(19, 22, 8); plat(14, 17, 5);
      chestOn(16, 5, 1); nE = 1; return true;
    }
    if (t === 'turrets') { // turrets in both walls at two heights; climb the middle to the chest
      ents.push({ k: 'turret', x: 1 * T + 6, y: 5 * T + 8, dir: 1, cd: r() * 2 }); ents.push({ k: 'turret', x: (W - 1) * T - 6, y: 5 * T + 8, dir: -1, cd: 1 + r() });
      ents.push({ k: 'turret', x: 1 * T + 6, y: 9 * T + 8, dir: 1, cd: 1.5 + r() }); ents.push({ k: 'turret', x: (W - 1) * T - 6, y: 9 * T + 8, dir: -1, cd: r() * 2 });
      RS(8, 3, 24, 14); plat(9, 12, 12); plat(20, 23, 12); plat(13, 19, 9); plat(14, 18, 6);
      for (x = 11; x <= 13; x++) if (G(x, 15) === TW) { S(x, 14, TW); } for (x = 19; x <= 21; x++) if (G(x, 15) === TW) S(x, 14, TW);
      chestOn(16, 6, 1); nE = 1; return true;
    }
    if (t === 'chandhall') { // a long hall of chandeliers: every one comes down as you pass under it
      var nc2 = 0; for (x = 5; x <= W - 6; x += 4) if (G(x, 0) === TW && free(x - 1, 1, x + 1, 5)) { ents.push({ k: 'chand', x: x * T + 8, y: T, st: 'hang' }); RS(x - 2, 1, x + 2, 5); nc2++; }
      plat(9, 12, 11); plat(20, 23, 11); chestOn(far, 15, 1); nE = 2 + Math.floor(A.tier / 2); return nc2 > 2;
    }
    if (t === 'stash') { // somebody's hoard: drops everywhere and three chests, and plenty of guards
      plat(4, 9, 11); plat(22, 27, 11); plat(12, 19, 8);
      chestOn(6, 11); chestOn(25, 11); chestOn(16, 8, 1);
      for (x = 6; x <= 26; x += 2) if (Math.abs(x - 16) > 3) ents.push({ k: 'drop', x: x * T + 8, y: 14 * T - 2 });
      nE = 4 + Math.floor(A.tier / 2); return true;
    }
    if (t === 'darkhall') { // pitch black. Something glitters in the middle of it
      forceDark = 1; plat(5, 9, 12); plat(22, 26, 12); plat(12, 19, 9);
      for (x = 13; x <= 18; x++) ents.push({ k: 'drop', x: x * T + 8, y: 9 * T - 10 }); chestOn(16, 9, 1); nE = 3 + Math.floor(A.tier / 2); return true;
    }
    return false;
  }
  function castleRoom(t) {
    var far = ex.r && !ex.l ? 3 : 28, i;
    if (t === 'pendulum') { // three great axes swing from the ceiling across the hall: time your run under them
      [[8, 0], [16, 1.1], [24, 2.2]].forEach(function (p) { ents.push({ k: 'pend', x: p[0] * T + 8, y: T + 4, len: 11 * T, ph: p[1] + r() }); });
      RS(3, 1, W - 4, 13); plat(3, 5, 12); plat(26, 28, 12);
      ents.push({ k: 'chest', x: far * T + 8, y: 15 * T, big: 1 }); nE = 1; return true;
    }
    if (t === 'storm') { // lightning rods on the floor: they crackle, then the sky hits them
      [7, 16, 25].forEach(function (rx, k) { ents.push({ k: 'rod', x: rx * T + 8, y: 15 * T, t: k * 1.4 + r() * 0.4 }); });
      RS(5, 10, 27, 14); plat(10, 13, 12); plat(19, 22, 12); plat(14, 18, 9);
      ents.push({ k: 'chest', x: 16 * T + 8, y: 9 * T, big: 1 }); nE = 2; return true;
    }
    if (t === 'coffins') { // a row of coffins. Each one bursts open when you walk up to it.
      var who = ['mummy', 'vampire', 'skeleton', 'wraith', 'mummy'];
      [5, 10, 22, 27].forEach(function (cfx) { ents.push({ k: 'coffin', x: cfx * T + 8, y: 15 * T, who: who[Math.floor(r() * who.length)] }); });
      RS(3, 11, 29, 14); plat(13, 18, 12); ents.push({ k: 'chest', x: 16 * T, y: 12 * T, big: 1 }); nE = 0; return true;
    }
    if (t === 'thorns') { // thorn vines burst out of the floor one after another, like a wave: stand on the ledges and wait for the gap
      for (i = 0; i < 7; i++) ents.push({ k: 'vine', x: (7 + i * 3) * T + 8, y: 15 * T, t: i * 0.32 });
      RS(5, 10, 27, 14); plat(3, 5, 12); plat(12, 14, 12); plat(20, 22, 12); plat(27, 29, 12);
      ents.push({ k: 'chest', x: far * T + 8, y: 12 * T, big: 1 }); nE = 1; return true;
    }
    if (t === 'conveyor') { // belts along the floor and the ledges, all running the wrong way, over a hot hob
      ents.push({ k: 'belt', x: 3 * T, x0: 3 * T, x1: 14 * T, y: 15 * T, dir: 1 }); ents.push({ k: 'belt', x: 18 * T, x0: 18 * T, x1: 29 * T, y: 15 * T, dir: -1 });
      for (x = 14; x <= 17; x++) if (G(x, 15) === TW) S(x, 14, TS);
      RS(3, 13, 29, 14); plat(6, 11, 12); plat(20, 25, 12); plat(12, 19, 9);
      ents.push({ k: 'belt', x: 6 * T, x0: 6 * T, x1: 12 * T, y: 12 * T, dir: -1 }); ents.push({ k: 'belt', x: 20 * T, x0: 20 * T, x1: 26 * T, y: 12 * T, dir: 1 });
      ents.push({ k: 'chest', x: 16 * T, y: 9 * T, big: 1 }); nE = 2; return true;
    }
    if (t === 'yarn') { // Sir Johnathan's toys: balls of yarn roll across the floor. Jump them or bounce off the top.
      ents.push({ k: 'yarnspot', x: 16 * T, y: 15 * T, t: 1.2 + r() });
      RS(3, 10, 28, 14); plat(4, 7, 12); plat(14, 18, 12); plat(25, 28, 12); plat(9, 12, 9); plat(20, 23, 9);
      ents.push({ k: 'chest', x: 16 * T, y: 12 * T, big: 1 }); nE = 1; return true;
    }
    if (t === 'vats') { // the cream vats overflow every few seconds: climb out of it
      ents.push({ k: 'goo', t: r() * 3, top: 5, lv: 15 * T, cream: 1 });
      [[3, 7, 11], [11, 15, 9], [19, 23, 11], [25, 28, 8], [6, 10, 7], [14, 18, 5], [21, 24, 4]].forEach(function (p) { if (free(p[0], p[2] - 2, p[1], p[2])) plat(p[0], p[1], p[2]); });
      ents.push({ k: 'chest', x: 16 * T, y: 15 * T, big: 1 }); RS(15, 13, 17, 14); nE = 2; return true; // grab it between floods
    }
    if (t === 'jellies') { // a field of wobbling jellies: bounce from one to the next up to the picnic hamper
      [6, 12, 20, 26].forEach(function (jx) { if (G(jx, 15) === TW) ents.push({ k: 'pad', jelly: 1, x: jx * T + 8, y: 15 * T }); });
      for (x = 8; x <= 24; x++) if (G(x, 15) === TW && [12, 20].indexOf(x) < 0 && Math.abs(x - 16) > 1) S(x, 14, TS);
      RS(3, 5, 29, 14); plat(14, 18, 12); plat(3, 5, 12); plat(27, 29, 12); plat(8, 11, 9); plat(21, 24, 9); plat(9, 12, 6); plat(20, 23, 6);
      ents.push({ k: 'chest', x: 10 * T + 8, y: 6 * T, big: 1 }); ents.push({ k: 'chest', x: 21 * T + 8, y: 6 * T }); nE = 1; return true;
    }
    return false;
  }
  // plain rooms come in several shapes, so the castle does not feel samey
  var style = 'classic';
  if (t === 'normal') { var sr = r(), STY = ['pit', 'stairs', 'pillars', 'tower', 'bridge', 'twin', 'mound', 'mezz', 'arch', 'islands', 'arches', 'steps2']; style = sr < 0.22 ? 'classic' : STY[Math.floor((sr - 0.22) / 0.78 * STY.length)] || 'classic'; }
  if (style !== 'classic' && !roomStyle(style)) style = 'classic';
  rm.style = style;
  function roomStyle(st) {
    var ok = false, i, bx, bh, h;
    if (st === 'pit') { // spikes in the middle of the floor, ledges across
      var nsp = 0; for (x = 11; x <= 20; x++) if (!res[14 * W + x] && G(x, 14) === TA && G(x, 15) === TW) { S(x, 14, TS); nsp++; }
      if (nsp < 4) return false; RS(10, 12, 21, 14);
      if (free(5, 9, 10, 11)) plat(6, 10, 11); if (free(21, 9, 26, 11)) plat(21, 25, 11); if (free(13, 6, 18, 8)) plat(14, 17, 8); return true;
    }
    if (st === 'stairs') { // a staircase of blocks up to a high ledge
      var dirS = r() < 0.5 ? 1 : -1;
      for (i = 0; i < 5; i++) { bx = dirS > 0 ? 6 + i * 4 : W - 10 - i * 4; h = i + 1; if (!free(bx, 15 - h - 2, bx + 3, 14)) break; for (y = 15 - h; y <= 14; y++) for (x = bx; x < bx + 4; x++) S(x, y, TW); RS(bx, 15 - h - 2, bx + 3, 14); ok = true; }
      if (i >= 3) { var lx = dirS > 0 ? Math.min(W - 8, 6 + i * 4) : Math.max(2, W - 10 - i * 4 - 2), ly = 15 - i - 3; if (free(lx, ly - 2, lx + 5, ly)) plat(lx, lx + 5, ly); }
      return ok && i >= 3;
    }
    if (st === 'pillars') { // tall stone pillars; their tops are the platforms
      [6, 12, 19, 25].forEach(function (px) { var ph = rn(2, 4); /* low enough to hop over */ if (free(px, 15 - ph - 2, px + 1, 14)) { for (y = 15 - ph; y <= 14; y++) { S(px, y, TW); S(px + 1, y, TW); } RS(px - 1, 15 - ph - 2, px + 2, 14); ok = true; } });
      if (ok && free(13, 7, 18, 9)) plat(14, 17, 9); return ok;
    }
    if (st === 'tower') { // a column in the middle with ledges climbing round it
      // the column is low enough to get over with a step ledge either side (every climb here is 3 tiles at most)
      if (!free(9, 7, 22, 14)) return false;
      for (y = 9; y <= 14; y++) for (x = 15; x <= 16; x++) S(x, y, TW); RS(13, 8, 18, 14);
      plat(10, 13, 12); plat(18, 21, 12); if (free(9, 4, 14, 6)) plat(10, 14, 6); return true;
    }
    if (st === 'twin') { // two squat towers with a ledge strung between their tops
      var tw = [[6, 8], [23, 25]]; for (i = 0; i < 2; i++) { if (!free(tw[i][0], 10, tw[i][1], 14)) return false; }
      tw.forEach(function (c) { for (y = 12; y <= 14; y++) for (x = c[0]; x <= c[1]; x++) S(x, y, TW); RS(c[0] - 1, 9, c[1] + 1, 14); });
      if (free(11, 8, 20, 10)) plat(11, 20, 9); return true;
    }
    if (st === 'mound') { // the floor heaps up into a hill in the middle
      if (!free(9, 11, 22, 14)) return false;
      for (x = 9; x <= 22; x++) S(x, 14, TW); for (x = 12; x <= 19; x++) S(x, 13, TW); for (x = 14; x <= 17; x++) S(x, 12, TW); RS(8, 9, 23, 14);
      if (free(3, 9, 7, 11)) plat(3, 7, 10); if (free(24, 9, 28, 11)) plat(24, 28, 10); return true;
    }
    if (st === 'mezz') { // a long gallery across the room at head height, with gaps to drop through
      var nm = 0; for (x = 4; x <= W - 5; x++) if ((x < 10 || x > 12) && (x < 19 || x > 21) && G(x, 11) === TA && !res[11 * W + x]) { S(x, 11, TL); nm++; }
      if (nm < 14) return false; RS(4, 8, W - 5, 11); if (free(13, 6, 18, 8)) plat(13, 18, 7); return true;
    }
    if (st === 'arch') { // ledges climbing up to a peak in the middle and down again
      var ar = [[3, 6, 12], [8, 11, 10], [13, 18, 8], [20, 23, 10], [25, 28, 12]], na = 0;
      ar.forEach(function (p) { if (free(p[0], p[2] - 2, p[1], p[2])) { plat(p[0], p[1], p[2]); na++; } }); return na >= 4;
    }
    if (st === 'islands') { // spikes all along the floor, with little stone islands to hop between
      var isl = [8, 13, 18, 23], nsi = 0;
      for (x = 5; x <= W - 6; x++) { var onI = isl.some(function (ix) { return x >= ix && x <= ix + 1; }); if (G(x, 15) !== TW || res[14 * W + x] || G(x, 14) !== TA) continue; S(x, 14, onI ? TW : TS); if (!onI) nsi++; }
      if (nsi < 10) return false; RS(5, 11, W - 6, 14); if (free(10, 8, 21, 10)) plat(11, 20, 10); return true;
    }
    if (st === 'arches') { // the ceiling hangs down in heavy arches; fight under them
      var ac = ex.u ? [[4, 8], [23, 27]] : [[4, 8], [13, 18], [23, 27]], nar = 0;
      ac.forEach(function (c) { if (free(c[0], 1, c[1], 6)) { for (y = 1; y <= 4; y++) for (x = c[0] + (y === 4 ? 1 : 0); x <= c[1] - (y === 4 ? 1 : 0); x++) S(x, y, TW); RS(c[0], 1, c[1], 6); nar++; } });
      if (nar < 2) return false; if (free(9, 8, 12, 10)) plat(9, 12, 9); if (free(19, 8, 22, 10)) plat(19, 22, 9); return true;
    }
    if (st === 'steps2') { // the floor steps down to a sunken middle and back up
      if (!free(3, 11, 9, 14) || !free(22, 11, 28, 14)) return false;
      for (x = 3; x <= 9; x++) { S(x, 14, TW); if (x <= 6) S(x, 13, TW); } for (x = 22; x <= 28; x++) { S(x, 14, TW); if (x >= 25) S(x, 13, TW); }
      RS(2, 10, 9, 14); RS(22, 10, 29, 14); if (free(13, 9, 18, 11)) plat(13, 18, 10); return true;
    }
    if (st === 'bridge') { // a long high walkway across the room, broken in the middle
      var nb2 = 0; for (x = 4; x <= W - 5; x++) if ((x < 14 || x > 17) && G(x, 9) === TA && !res[9 * W + x]) { S(x, 9, TL); nb2++; }
      if (nb2 < 12) return false; RS(4, 6, W - 5, 9);
      if (free(5, 11, 9, 13)) plat(5, 8, 12); if (free(W - 9, 11, W - 5, 13)) plat(W - 8, W - 5, 12);
      var ns3 = rn(1, 2); for (var si3 = 0; si3 < ns3; si3++) { var sx3 = rn(8, 22); if (free(sx3, 13, sx3 + 1, 14) && G(sx3, 15) === TW) { S(sx3, 14, TS); S(sx3 + 1, 14, TS); RS(sx3, 13, sx3 + 1, 14); } }
      return true;
    }
    return false;
  }
  // general features for rooms that fight
  if ((t === 'normal' && style === 'classic') || t === 'illusion' || t === 'challenge' || t === 'ambush') {
    var nb = t === 'challenge' || t === 'ambush' ? 1 : rn(0, 3);
    for (var bi = 0; bi < nb; bi++) { var bw = rn(2, 4), bh = rn(1, 2) + (r() < 0.15 ? 1 : 0), bx = rn(4, 27 - bw); if (free(bx, 15 - bh, bx + bw - 1, 14) && free(bx, 15 - bh - 2, bx + bw - 1, 15 - bh - 1)) { for (y = 15 - bh; y <= 14; y++) for (x = bx; x < bx + bw; x++) S(x, y, TW); RS(bx, 15 - bh - 2, bx + bw - 1, 14); } }
    var np = t === 'challenge' || t === 'ambush' ? 0 : rn(2, 4);
    for (var pi = 0; pi < np; pi++) { var pw = rn(3, 6), py = rn(6, 11), px = rn(3, 28 - pw); if (free(px - 1, py - 2, px + pw, py + 1)) plat(px, px + pw - 1, py); }
    if (t === 'normal') { var ns = rn(0, 2); for (var si = 0; si < ns; si++) { var sw = rn(2, 3), sx = rn(5, 26 - sw); var okS = true; for (x = sx; x < sx + sw; x++) if (res[14 * W + x] || G(x, 14) !== TA || G(x, 15) !== TW) okS = false; if (okS) { for (x = sx; x < sx + sw; x++) S(x, 14, TS); RS(sx, 13, sx + sw - 1, 14); } } }
  }
  // Ejaculand's front gate, with Steve the mascot waving you in
  if (rm.entry && rm.area === 'city') { ents.push({ k: 'deco', d: 'parkgate', x: 6 * T, y: 15 * T }); ents.push({ k: 'steve', x: 11 * T, y: 15 * T }); nE = 0; }
  // area quirks
  var fights = t === 'normal' || t === 'big', dark = false, wind = 0;
  if (fights && (rm.area === 'castle' || rm.area === 'bone' || rm.area === 'bkeep') && r() < 0.55) { // chandeliers that drop when you walk under them
    var nc = rn(1, rm.big === 'wide' ? 3 : 2), tries = 0;
    while (nc > 0 && tries++ < 20) { var chx = rn(4, W - 5); if (G(chx, 0) === TW && free(chx - 1, 1, chx + 1, 5)) { ents.push({ k: 'chand', x: chx * T + 8, y: T, st: 'hang' }); RS(chx - 2, 1, chx + 2, 5); nc--; } }
  }
  if ((rm.area === 'city' || rm.area === 'gfair') && t !== 'flume' && t !== 'jellies' && !rm.entry && r() < 0.6) { // bounce pads on the floor (jellies at the Picnic)
    var npd = rn(1, 2), tries2 = 0;
    while (npd > 0 && tries2++ < 30) { var pdx = rn(4, W - 5), fy = H - 2; if (G(pdx, fy + 1) === TW && free(pdx - 1, fy - 3, pdx + 1, fy)) { ents.push({ k: 'pad', x: pdx * T + 8, y: (fy + 1) * T, jelly: rm.area === 'gfair' ? 1 : 0 }); RS(pdx - 1, fy - 3, pdx + 1, fy); npd--; } }
  }
  if (rm.area === 'furnace' && t !== 'flume') { var nv = rn(1, 3), tv = 0; while (nv > 0 && tv++ < 30) { var vx = rn(5, W - 6); if (G(vx, H - 1) === TW && free(vx - 1, H - 4, vx + 1, H - 2)) { ents.push({ k: 'vent', x: vx * T + 8, y: (H - 1) * T, t: r() * 3.4 }); RS(vx - 1, H - 5, vx + 1, H - 2); nv--; } } }
  if ((rm.area === 'dungeon' || rm.area === 'sewer' || rm.area === 'bcrypt' || rm.area === 'gcellar') && t !== 'start') { // drips from the ceiling, and some rooms are pitch dark
    var ndr = rn(1, 3);
    for (var dq = 0; dq < ndr; dq++) { var drx = rn(3, W - 4); if (G(drx, 0) === TW && G(drx, 1) === TA) ents.push({ k: 'drip', x: drx * T + 8, y: T, cd: 1 + r() * 3 }); }
    dark = (rm.area === 'dungeon' || rm.area === 'bcrypt') && fights && r() < 0.5; /* the sewers stay lit so you can see the cream */
  }
  if (forceDark) dark = true;
  var DECO = { sewer: [['creampool', 3, 3]], bone: [['skulls', 2, 3], ['ribs', 1, 4]], furnace: [['crucible', 2, 2]] }[rm.area];
  if (DECO && t !== 'flume') DECO.forEach(function (dd) { // each endless area dresses its floors: cream puddles, skull piles and ribcages, crucibles of lava
    var n = rn(1, dd[1]), tr = 0, half = Math.ceil(dd[2] / 2);
    while (n > 0 && tr++ < 40) { var qx = rn(3, W - 4), qy = rn(2, H - 2); if (G(qx, qy) === TA && G(qx, qy + 1) === TW && G(qx - half, qy + 1) === TW && G(qx + half, qy + 1) === TW && !res[qy * W + qx] && !ents.some(function (o) { return o.k === 'adeco' && Math.abs(o.x - (qx * T + 8)) < 40 && Math.abs(o.y - (qy + 1) * T) < 8; })) { ents.push({ k: 'adeco', s: dd[0], x: qx * T + 8, y: (qy + 1) * T, fl: r() < 0.5 }); n--; } }
  });
  if ((rm.area === 'roof' || rm.area === 'bspire') && fights && r() < 0.6) wind = r() < 0.5 ? -1 : 1; // gusts across the rooftops
  // stand spots for enemies and drops
  var stands = [];
  for (x = 2; x < W - 2; x++) for (y = 2; y < H - 1; y++) { var b = G(x, y + 1); if (G(x, y) === TA && G(x, y - 1) === TA && (b === TW || b === TL) && !res[y * W + x]) stands.push([x, y]); }
  shuffle(stands, r);
  var pool = A.pool, tot = 0; pool.forEach(function (p) { tot += p[1]; });
  function pickE() { var v = r() * tot; for (var i = 0; i < pool.length; i++) { v -= pool[i][1]; if (v <= 0) return pool[i][0]; } return pool[0][0]; }
  for (var e = 0; e < nE; e++) {
    var ek = t === 'flume' ? (r() < 0.5 ? 'batP' : 'imp') : pickE(), ed = ENEMIES[ek];
    if (ek === 'gargoyle') ents.push({ k: 'enemy', e: ek, x: rn(5, W - 6) * T, y: T + 23, idx: e }); // clings under the ceiling
    else if (isFlyer(ed)) ents.push({ k: 'enemy', e: ek, x: rn(6, W - 7) * T, y: rn(3, H - 8) * T, idx: e });
    else { var sp = null; for (var q = 0; q < stands.length; q++) { var sx2 = stands[q][0]; if (sx2 > 6 && sx2 < W - 7 && Math.abs(sx2 - 16) > 2) { sp = stands.splice(q, 1)[0]; break; } } if (sp) ents.push({ k: 'enemy', e: ek, x: sp[0] * T + 8, y: (sp[1] + 1) * T, idx: e }); }
  }
  // drops: little rows on ledges, like Spermhog
  var di = 0;
  for (y = 3; y < H - 1; y++) for (x = 2; x < W - 2; x++) if (G(x, y) === TL && G(x - 1, y) !== TL && r() < 0.6) { var len = 0; while (G(x + len, y) === TL) len++; for (var k = 0; k < len; k += 2) ents.push({ k: 'drop', x: (x + k) * T + 8, y: y * T - 10, di: di++ }); }
  if (t === 'normal' && r() < 0.18 && stands.length) { var cs = stands.pop(); ents.push({ k: 'chest', x: cs[0] * T + 8, y: (cs[1] + 1) * T }); }
  // decorations by area
  // decorations, placed on purpose: hangings in mirrored pairs under the ceiling, candles standing on ledges and the floor
  function clear(x0, y0, x1, y1) { for (var yy = y0; yy <= y1; yy++) for (var xx = x0; xx <= x1; xx++) if (xx < 1 || xx > W - 2 || G(xx, yy) !== TA || res[yy * W + xx]) return false; return true; }
  function nearEnt(px, py, d) { return ents.some(function (en) { return en.k !== 'enemy' && en.x !== undefined && Math.abs(en.x - px) < d && Math.abs((en.y || 0) - py) < 40; }); }
  var city = rm.area === 'city', hang = city ? 'bulbs' : 'banner', hw = city ? 3 : 2, hh = city ? 2 : 4;
  var pairs = city ? [[9, W - 12], [4, W - 7]] : [[8, W - 10], [12, W - 14], [4, W - 6]]; // inner pairs first so the HUD corners stay clear
  var wantPairs = t === 'start' ? 1 : rn(1, 2), placed = 0;
  for (var pq = 0; pq < pairs.length && placed < wantPairs; pq++) {
    var a0 = pairs[pq][0], a1 = pairs[pq][1];
    if (G(a0, 0) === TW && G(a1, 0) === TW && clear(a0, 1, a0 + hw - 1, hh) && clear(a1, 1, a1 + hw - 1, hh)) {
      ents.push({ k: 'deco', d: hang, x: a0 * T + (city ? 2 : 6), y: city ? T + 3 : T + 2, hue: r() });
      ents.push({ k: 'deco', d: hang, x: a1 * T + (city ? 2 : 6), y: city ? T + 3 : T + 2, hue: r() });
      placed++;
    }
  }
  // ledge tops: candles at both ends of a bare ledge (castle side), or one neon sign on a post (Ejaculand)
  var ledges = [];
  for (y = 4; y < H - 2; y++) for (x = 1; x < W - 1; x++) if (G(x, y) === TL && G(x - 1, y) !== TL) { var x1 = x; while (G(x1 + 1, y) === TL) x1++; if (x1 - x >= 3 && clear(x, y - 2, x1, y - 1) && !ents.some(function (en) { return (en.k === 'drop' || en.k === 'chest') && en.y < y * T + 2 && en.y > y * T - 20 && en.x > x * T - 8 && en.x < (x1 + 1) * T + 8; })) ledges.push([x, x1, y]); }
  shuffle(ledges, r);
  if (city) { if (ledges.length && r() < 0.7) { var lg = ledges[0], mx = ((lg[0] + lg[1] + 1) / 2) * T; ents.push({ k: 'deco', d: 'neon', x: Math.round(mx - 17), y: lg[2] * T - 24, hue: r(), post: 1 }); } }
  else {
    var nl = Math.min(ledges.length, rn(1, 2));
    for (var li = 0; li < nl; li++) { var L0 = ledges[li]; ents.push({ k: 'deco', d: 'candle', x: L0[0] * T + 3, y: L0[2] * T - 18 }); ents.push({ k: 'deco', d: 'candle', x: L0[1] * T + 7, y: L0[2] * T - 18 }); }
    // a candle by each side wall on the floor, only where there is no way out on that side
    if (!ex.l && !ex.r && r() < 0.6 && clear(2, 13, 2, 14) && clear(W - 3, 13, W - 3, 14) && G(2, 15) === TW && G(W - 3, 15) === TW && !nearEnt(2 * T + 8, 15 * T, 24) && !nearEnt((W - 3) * T + 8, 15 * T, 24)) {
      ents.push({ k: 'deco', d: 'candle', x: 2 * T + 5, y: 15 * T - 18 }); ents.push({ k: 'deco', d: 'candle', x: (W - 3) * T + 5, y: 15 * T - 18 });
    }
  }
  ents.forEach(function (en, i) { en.i = i; });
  return { w: W, h: H, tiles: tl, ents: ents, cx0: cx0, spawnX: (ex.d || style === 'tower' ? 8 : (t === 'start' ? 10 : 16)) * T, dark: dark, wind: wind, storm: rm.area === 'roof' || rm.area === 'bspire' };
}

/* ---------- boss arenas (two screens wide). Reached through a boss door. ---------- */
function buildArena(boss, lair) {
  var W = CW * 2, H = CH, tl = new Uint8Array(W * H);
  function S(x, y, v) { if (x >= 0 && y >= 0 && x < W && y < H) tl[y * W + x] = v; }
  for (var x = 0; x < W; x++) { S(x, 0, TW); S(x, H - 1, TW); }
  for (var y = 0; y < H; y++) { S(0, y, TW); S(W - 1, y, TW); }
  for (y = 12; y <= 14; y++) S(0, y, TB);
  [[8, 13, 10], [50, 55, 10], [27, 36, 7], [17, 21, 4], [42, 46, 4]].forEach(function (p) { for (var x = p[0]; x <= p[1]; x++) S(x, p[2], TL); });
  return { w: W, h: H, tiles: tl, ents: [], arena: boss, lair: !!lair || boss === 'mega' };
}

/* the newer room types, and which places get which (each place still gets its own feel) */
function moreTypes(a) {
  var all = ['gauntlet', 'climb', 'stash', 'darkhall', 'turrets', 'padpit'];
  var by = { castle: ['crypt', 'chandhall', 'gauntlet'], roof: ['rods', 'climb', 'briar'], city: ['factory', 'padpit', 'padpit'], dungeon: ['crypt', 'briar', 'factory', 'darkhall'],
    bkeep: ['crypt', 'chandhall', 'gauntlet'], bspire: ['rods', 'climb'], bcrypt: ['crypt', 'darkhall'], bgarden: ['briar', 'crypt'],
    gkitchen: ['factory', 'stash'], gtower: ['climb', 'padpit'], gcellar: ['factory', 'darkhall'], gfair: ['padpit', 'briar'],
    sewer: ['factory', 'darkhall'], bone: ['crypt', 'chandhall'], furnace: ['factory', 'turrets'] }[a] || [];
  return all.concat(by);
}

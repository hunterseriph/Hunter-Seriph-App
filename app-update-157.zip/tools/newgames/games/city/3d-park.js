/* ---------- update 156: Ejaculand is a theme park, not a car park (he said it was massive with nothing in it).
   At load the park's flat yard is laid out: a grid of paths (the main avenue runs down from the gate to the pier),
   lawns round every plot, and a ride, stall or show in each plot. The old rides (ferris wheel, coaster, carousel,
   clock tower, flume, big top, drop tower) keep their plots; the rest get one of PARKKINDS, each built here as a
   landmark with its moving parts: teacups, the swing ride, the pirate ship, the helter skelter, dodgems, the ghost
   train, game stalls, a food court, Steve's statue, the cream fountain, a balloon cart, the hall of mirrors and
   Potbelly's Arcade (one of the four, PARKARCADE). Paths get lamps hung with bunting (`parkDeco`, drawn by the chunks). ---------- */
var PARKKINDS = ['teacups', 'swings', 'pirate', 'helter', 'dodgems', 'ghost', 'stalls', 'food', 'steve', 'fountain2', 'stalls', 'mirrors', 'balloons', 'food', 'teacups', 'swings', 'stalls'];
var PARKPATH = {}, PARKCELL = [];
(function parkLayout() {
  var id = DISTID.ejac; if (id === undefined) return; var i0 = 1e9, i1 = -1, j0 = 1e9, j1 = -1;
  for (var j = 0; j < MH; j++) for (var i = 0; i < MW; i++) { var t = j * MW + i; if (DM[t] === id && KM[t] === K_PAVE) { if (i < i0) i0 = i; if (i > i1) i1 = i; if (j < j0) j0 = j; if (j > j1) j1 = j; } }
  if (i1 < 0) return; var gate = POIS.filter(function (p) { return p.k === 'gate'; })[0], ax = gate ? Math.floor(gate.x / CT) : Math.floor((i0 + i1) / 2);
  // the old rides keep a paved yard round them, paths go round it
  var KEEP = { ferris: [32, 18], coaster: [40, 26], carousel: [14, 14], clock: [8, 8], flume: [46, 8, -6], bigtop: [17, 17], dropper: [8, 8] }, keep = [];
  POIS.forEach(function (p) { var q = KEEP[p.k]; if (!q || DM[Math.floor(p.z / CT) * MW + Math.floor(p.x / CT)] !== id) return; var cx = p.x + (q[2] || 0); keep.push([Math.floor((cx - q[0]) / CT), Math.floor((p.z - q[1]) / CT), Math.floor((cx + q[0]) / CT), Math.floor((p.z + q[1]) / CT)]); });
  function inKeep(i, j, m) { m = m || 0; for (var k = 0; k < keep.length; k++) { var K = keep[k]; if (i >= K[0] - m && i <= K[2] + m && j >= K[1] - m && j <= K[3] + m) return true; } return false; }
  var xs = [], zs = []; for (var x = ax; x > i0 + 6; x -= 12) xs.unshift(x); for (var x2 = ax + 12; x2 < i1 - 6; x2 += 12) xs.push(x2); for (var z = j0 + 3; z < j1 - 6; z += 11) zs.push(z); zs.push(j1 - 2);
  function isPath(i, j) { for (var a = 0; a < xs.length; a++) if (Math.abs(i - xs[a]) <= (xs[a] === ax ? 2 : 1)) return true; for (var b = 0; b < zs.length; b++) if (Math.abs(j - zs[b]) <= 1) return true; return i <= i0 + 1 || i >= i1 - 1 || j <= j0 + 1 || j >= j1 - 1; }
  for (var jj = j0; jj <= j1; jj++) for (var ii = i0; ii <= i1; ii++) { var t2 = jj * MW + ii; if (DM[t2] !== id || KM[t2] !== K_PAVE) continue; if (inKeep(ii, jj)) continue; if (isPath(ii, jj) || inKeep(ii, jj, 2)) PARKPATH[t2] = 1; else KM[t2] = K_PARK; }
  var bx = [i0 + 1].concat(xs).concat([i1 - 1]), bz = [j0 + 1].concat(zs).concat([j1 - 1]), n = 0;
  for (var b2 = 0; b2 < bz.length - 1; b2++) for (var a2 = 0; a2 < bx.length - 1; a2++) { var ci0 = bx[a2] + 2, ci1 = bx[a2 + 1] - 2, cj0 = bz[b2] + 2, cj1 = bz[b2 + 1] - 2; if (ci1 - ci0 < 5 || cj1 - cj0 < 4) continue;
    var hit = false; for (var jq = cj0; jq <= cj1 && !hit; jq++) for (var iq = ci0; iq <= ci1; iq++) if (inKeep(iq, jq, 1) || DM[jq * MW + iq] !== id) { hit = true; break; } if (hit) continue;
    var cx = (ci0 + ci1 + 1) / 2 * CT, cz = (cj0 + cj1 + 1) / 2 * CT, k = PARKKINDS[n % PARKKINDS.length]; n++; if (n === 4) k = 'arcadehall';
    for (var j3 = cj0 + 1; j3 <= cj1 - 1; j3++) for (var i3 = ci0 + 1; i3 <= ci1 - 1; i3++) { var t3 = j3 * MW + i3; if (KM[t3] === K_PARK) KM[t3] = K_PAVE; }
    var p = { k: k, x: cx, z: cz, h: groundY(cx, cz), w: (ci1 - ci0) * CT, d: (cj1 - cj0) * CT, seed: n }; POIS.push(p); PARKCELL.push(p); }
})();
function parkSign(txt, bg, fg) { return function (g) { g.fillStyle = '#12040a'; g.fillRect(0, 18, 64, 28); g.fillStyle = bg; g.fillRect(2, 20, 60, 24); g.fillStyle = fg; g.textAlign = 'center'; g.textBaseline = 'middle'; var s = 14; g.font = s + 'px "Pirata One", serif'; while (g.measureText(txt).width > 56 && s > 6) { s--; g.font = s + 'px "Pirata One", serif'; } g.fillText(txt, 32, 32.5); }; }
(function () { var S = { pk_teacups: ['MAD TEACUPS', '#ff7ab0', '#12040a'], pk_swings: ['SPUNK SWINGS', '#12040a', '#ffe36a'], pk_pirate: ['THE BLACK LOAD', '#12040a', '#ff2630'], pk_helter: ['HELTER SKELTER', '#ffe36a', '#c4121c'], pk_dodgems: ['DODGEMS', '#c4121c', '#f1e7d0'],
    pk_ghost: ['GHOST TRAIN', '#12040a', '#7aff6a'], pk_duck: ['HOOK A DUCK', '#4adfff', '#12040a'], pk_shy: ['COCONUT SHY', '#ffe36a', '#12040a'], pk_shoot: ['SHOOTING GALLERY', '#12040a', '#ff2630'], pk_food: ['CREAM DOGS', '#c4121c', '#ffe36a'], pk_mirrors: ['HALL OF MIRRORS', '#2a1a3a', '#ff7ab0'], pk_candy: ['CANDY FLOSS', '#ff9ab4', '#12040a'] };
  for (var k in S) HIPAINT[k] = parkSign(S[k][0], S[k][1], S[k][2]); })();
function parkStall(m, glow, x, y, z, a, sign, col) { var c = Math.cos(a), s = Math.sin(a); function L(u, v) { return [x + u * c + v * s, z - u * s + v * c]; }
  boxR(m, x, z, a, 1.6, 1.0, y, y + 1.0, col, 'plank'); var b = L(0, -0.9); boxR(m, b[0], b[1], a, 1.6, 0.1, y, y + 2.6, '#3a2a2a', 'plank');
  [-1.55, 1.55].forEach(function (u) { var p = L(u, 0.95); tub(m, [p[0], y, p[1]], [p[0], y + 2.6, p[1]], 0.06, 0.06, '#f1e7d0', 5); });
  var r0 = L(0, 0.2); for (var q = 0; q < 6; q++) { var u0 = -1.7 + q * 0.567, p0 = L(u0, -1.0), p1 = L(u0 + 0.567, -1.0), p2 = L(u0 + 0.567, 1.4), p3 = L(u0, 1.4); m.quad([p0[0], y + 2.9, p0[1]], [p1[0], y + 2.9, p1[1]], [p2[0], y + 2.4, p2[1]], [p3[0], y + 2.4, p3[1]], UV1, TL('white'), litc(q % 2 ? '#f1e7d0' : col, [s * 0.4, 0.9, c * 0.4]), [0, 1, 0]); }
  var sg = L(0, 1.42); standQ(glow, sg[0], sg[1], a, 3.2, y + 2.9, y + 3.6, TL(sign), 1.2, 0.4, [0, 0.69, 1, 0.69, 1, 0.31, 0, 0.31]);
  for (var t = 0; t < 5; t++) { var pz = L(-1.2 + t * 0.6, -0.75); ell(m, pz[0], y + 1.7, pz[1], 0.2, 0.24, 0.18, ['#c4121c', '#ffe36a', '#7aff6a', '#ff7ab0', '#4adfff'][t], 6, 4); ell(m, pz[0], y + 2.02, pz[1], 0.13, 0.13, 0.13, '#f1e7d0', 6, 4); } }
LMBUILD.teacups = function (o, p) { var y = p.h; tub(o.m, [p.x, y, p.z], [p.x, y + 0.5, p.z], 11, 11, '#ff7ab0', 18, { cap: 1 }); tub(o.m, [p.x, y + 0.5, p.z], [p.x, y + 0.55, p.z], 10.5, 10.5, '#f1e7d0', 18, { cap: 1 });
  var top = new R3.Mesh(); ring(top, 0, 0, 0, 6.5, 6, function (x, z, a, k) { tub(top, [x, 0.55, z], [x, 0.6, z], 1.9, 1.9, '#f1e7d0', 10, { cap: 1 }); tub(top, [x, 0.6, z], [x, 1.7, z], 1.1, 1.5, ['#c4121c', '#ffe36a', '#4adfff', '#7aff6a', '#ff7ab0', '#12040a'][k], 10, { cap0: 1 }); ell(top, x + 1.5, 1.2, z, 0.25, 0.4, 0.12, '#f1e7d0', 6, 4); });
  tub(top, [0, 0.55, 0], [0, 4, 0], 0.5, 0.3, '#ffe36a', 8); ell(top, 0, 4.4, 0, 2.2, 0.9, 2.2, '#c4121c', 10, 4);
  var tm = top.upload(); o.parts.push({ m: tm, f: function (t) { return MD(p.x, y, p.z, t * 0.5, 0, 0); } }); standQ(o.glow, p.x, p.z + 11.2, 0, 6, y + 1, y + 2.6, TL('pk_teacups'), 1.2, 0.4, [0, 0.69, 1, 0.69, 1, 0.31, 0, 0.31]);
  addPost(p.x, p.z, 10.5, y, y + 1); o.r = 40; o.lights = [{ x: p.x, y: y + 5, z: p.z, c: [1, 0.5, 0.8], r: 18 }]; };
LMBUILD.swings = function (o, p) { var y = p.h; tub(o.m, [p.x, y, p.z], [p.x, y + 0.4, p.z], 5, 5, '#12040a', 14, { cap: 1 }); tub(o.m, [p.x, y, p.z], [p.x, y + 13, p.z], 0.7, 0.5, '#ffe36a', 10);
  var top = new R3.Mesh(); tub(top, [0, 13, 0], [0, 15, 0], 7.5, 1, '#c4121c', 16, { cap0: 1 }); ell(top, 0, 15.2, 0, 1.2, 1, 1.2, '#ffe36a', 8, 4);
  ring(top, 0, 0, 0, 7, 12, function (x, z, a) { var ox = Math.cos(a) * 9, oz = Math.sin(a) * 9; tub(top, [x, 13, z], [ox, 5.5, oz], 0.03, 0.03, '#c8ccd0', 3); boxC(top, ox - 0.35, 5.0, oz - 0.35, ox + 0.35, 5.5, oz + 0.35, '#f1e7d0'); boxC(top, ox - 0.35, 5.5, oz - 0.38, ox + 0.35, 6.1, oz - 0.3, '#c4121c'); });
  var tm = top.upload(); o.parts.push({ m: tm, f: function (t) { return MD(p.x, y, p.z, t * 1.4, 0, 0); } }); standQ(o.glow, p.x, p.z + 6, 0, 5, y + 1.0, y + 2.4, TL('pk_swings'), 1.2, 0.4, [0, 0.69, 1, 0.69, 1, 0.31, 0, 0.31]);
  addPost(p.x, p.z, 1, y, y + 13); o.r = 50; o.lights = [{ x: p.x, y: y + 12, z: p.z, c: [1, 0.85, 0.4], r: 22 }]; };
LMBUILD.pirate = function (o, p) { var y = p.h; [-1, 1].forEach(function (s) { tub(o.m, [p.x - 5, y, p.z + s * 3], [p.x, y + 11, p.z + s * 2], 0.3, 0.3, '#3a2a2a', 6); tub(o.m, [p.x + 5, y, p.z + s * 3], [p.x, y + 11, p.z + s * 2], 0.3, 0.3, '#3a2a2a', 6); }); tub(o.m, [p.x, y + 11, p.z - 2.2], [p.x, y + 11, p.z + 2.2], 0.35, 0.35, '#c4121c', 8, { cap: 1, cap0: 1 });
  var sh = new R3.Mesh(); for (var k = 0; k < 9; k++) { var u = -7 + k * 1.75, d = 1.6 - Math.abs(u) / 7 * 0.6, hgt = 1.4 + Math.abs(u) / 7 * 1.4; boxC(sh, u, -9.5 - hgt * 0.4 + Math.abs(u) * 0.12, -d, u + 1.75, -9.5 + hgt * 0.6 + Math.abs(u) * 0.12, d, k % 2 ? '#3a1a10' : '#4a2414'); }
  boxC(sh, -7, -8.4, -1.7, 8.75, -8.2, 1.7, '#6a4a2a'); tub(sh, [0, -8.2, 0], [0, -2, 0], 0.12, 0.08, '#2a1a10', 5); standQ(sh, 0, 0, 0, 6, -6, -3, TL('pk_pirate'), 1.2, 0, [0, 0.69, 1, 0.69, 1, 0.31, 0, 0.31]); for (var b = 0; b < 2; b++) tub(sh, [0, 0, -0.1 + b * 0.2], [0, -8, -0.9 + b * 1.8], 0.12, 0.12, '#2a2a2e', 4);
  var sm = sh.upload(); o.parts.push({ m: sm, f: function (t) { return MD(p.x, y + 11, p.z, 0, 0, Math.sin(t * 0.9) * 1.0); } }); addBox(p.x - 6, p.z - 3, p.x + 6, p.z + 3, y, y + 3); o.r = 50; };
LMBUILD.helter = function (o, p) { var y = p.h; for (var k = 0; k < 8; k++) tub(o.m, [p.x, y + k * 2, p.z], [p.x, y + k * 2 + 2, p.z], 3.2 - k * 0.22, 3.0 - k * 0.22, k % 2 ? '#f1e7d0' : '#c4121c', 12, { cap: k === 7 }); tub(o.m, [p.x, y + 16, p.z], [p.x, y + 19, p.z], 1.8, 0, '#c4121c', 10, { cap0: 1 }); tub(o.m, [p.x, y + 19, p.z], [p.x, y + 21, p.z], 0.04, 0.04, '#12040a', 3);
  for (var s = 0; s < 40; s++) { var a = s / 40 * 6.283 * 2.6, h = y + 16 - s * 0.39, r = 3.6 - s * 0.02, x = p.x + Math.cos(a) * r, z = p.z + Math.sin(a) * r, a2 = (s + 1) / 40 * 6.283 * 2.6, x2 = p.x + Math.cos(a2) * r, z2 = p.z + Math.sin(a2) * r;
    o.m.quad([x, h, z], [x2, h - 0.39, z2], [x2 + Math.cos(a2) * 1.1, h - 0.39, z2 + Math.sin(a2) * 1.1], [x + Math.cos(a) * 1.1, h, z + Math.sin(a) * 1.1], UV1, TL('white'), litc(s % 2 ? '#ffe36a' : '#e8c840', [0, 1, 0]), [0, 1, 0]); }
  standQ(o.glow, p.x, p.z + 3.25, 0, 4, y + 2.4, y + 3.6, TL('pk_helter'), 1.2, 0.4, [0, 0.69, 1, 0.69, 1, 0.31, 0, 0.31]); addPost(p.x, p.z, 3.2, y, y + 18); o.r = 50; };
LMBUILD.dodgems = function (o, p) { var y = p.h, w = 11, d = 7; boxC(o.m, p.x - w, y, p.z - d, p.x + w, y + 0.3, p.z + d, '#2a2a2e'); [[-w, -d], [w, -d], [-w, d], [w, d], [0, -d], [0, d]].forEach(function (q) { tub(o.m, [p.x + q[0], y, p.z + q[1]], [p.x + q[0], y + 5, p.z + q[1]], 0.18, 0.18, '#c8a040', 6); });
  boxC(o.m, p.x - w - 0.5, y + 5, p.z - d - 0.5, p.x + w + 0.5, y + 5.4, p.z + d + 0.5, '#c4121c'); boxC(o.glow, p.x - w - 0.5, y + 5.4, p.z - d - 0.5, p.x + w + 0.5, y + 5.55, p.z + d + 0.5, '#ff7ab0'); for (var b = -w + 1; b < w; b += 1.6) { ell(o.glow, p.x + b, y + 4.9, p.z - d - 0.55, 0.15, 0.15, 0.15, '#ffe36a', 4, 3); ell(o.glow, p.x + b, y + 4.9, p.z + d + 0.55, 0.15, 0.15, 0.15, '#ffe36a', 4, 3); }
  standQ(o.glow, p.x, p.z + d + 0.6, 0, 7, y + 5.6, y + 7.4, TL('pk_dodgems'), 1.3, 0.5, [0, 0.69, 1, 0.69, 1, 0.31, 0, 0.31]);
  [0, 1, 2, 3, 4, 5].forEach(function (k) { var car = new R3.Mesh(), col = ['#c4121c', '#ffe36a', '#4adfff', '#7aff6a', '#ff7ab0', '#f1e7d0'][k]; boxC(car, -0.8, 0.3, -1.1, 0.8, 0.9, 1.1, col); tub(car, [0, 0.4, 0], [0, 0.4, 0], 1.2, 1.2, '#1a1a1e', 10); tub(car, [0, 0.9, -0.8], [0, 4.6, -0.8], 0.03, 0.03, '#c8ccd0', 3); var cm = car.upload();
    o.parts.push({ m: cm, f: function (t) { var u = t * 0.35 + k * 1.05, x = Math.sin(u * 1.3 + k) * (w - 2), z = Math.sin(u * 0.9 + k * 2) * (d - 2); return MD(p.x + x, y, p.z + z, u * 1.7 + k, 0, 0); } }); });
  addBox(p.x - w, p.z - d, p.x + w, p.z + d, y, y + 0.5); o.r = 50; o.lights = [{ x: p.x, y: y + 4, z: p.z, c: [1, 0.4, 0.7], r: 18 }]; };
LMBUILD.ghost = function (o, p) { var y = p.h, w = 9, d = 7; boxT(o.m, p.x - w, y, p.z - d, p.x + w, y + 9, p.z + d, { wall: 'w_darkstone', top: 'roof', u: 3, v: 3 }); tub(o.m, [p.x - w + 2, y + 9, p.z], [p.x - w + 2, y + 15, p.z], 2, 0, '#2a1a2a', 4, { cap0: 1 }); tub(o.m, [p.x + w - 2, y + 9, p.z], [p.x + w - 2, y + 13, p.z], 2, 0, '#2a1a2a', 4, { cap0: 1 });
  for (var k = 0; k < 6; k++) { var wx = p.x - w + 2 + k * 3; standQ(o.glow, wx, p.z + d + 0.03, 0, 1.4, y + 5, y + 7, TL('w_glass'), 0.6, 0.6); } standQ(o.m, p.x, p.z + d + 0.03, 0, 3, y, y + 3.4, TL('door'), 1); standQ(o.glow, p.x, p.z + d + 0.08, 0, 8, y + 3.8, y + 5.2, TL('pk_ghost'), 1.3, 0.6, [0, 0.69, 1, 0.69, 1, 0.31, 0, 0.31]);
  ell(o.m, p.x - 5, y + 10.4, p.z + d - 0.4, 0.8, 1, 0.8, '#f1e7d0', 8, 5); ell(o.glow, p.x - 5.3, y + 10.6, p.z + d + 0.35, 0.18, 0.18, 0.05, '#ff2630', 5, 3); ell(o.glow, p.x - 4.7, y + 10.6, p.z + d + 0.35, 0.18, 0.18, 0.05, '#ff2630', 5, 3);
  addBox(p.x - w, p.z - d, p.x + w, p.z + d, y, y + 9); o.r = 50; o.lights = [{ x: p.x, y: y + 6, z: p.z + d + 2, c: [0.4, 1, 0.5], r: 14 }]; };
LMBUILD.stalls = function (o, p) { var y = p.h, signs = ['pk_duck', 'pk_shy', 'pk_shoot', 'pk_candy'], cols = ['#c4121c', '#4adfff', '#12040a', '#ff7ab0']; for (var k = 0; k < 3; k++) { var q = (k + p.seed) % 4; parkStall(o.m, o.glow, p.x - 8 + k * 8, y, p.z, 0, signs[q], cols[q]); addBox(p.x - 9.6 + k * 8, p.z - 1, p.x - 6.4 + k * 8, p.z + 1, y, y + 2.6); }
  for (var b = 0; b < 4; b++) { var bx = p.x - 9 + b * 6; tub(o.m, [bx, y, p.z + 6], [bx, y + 0.45, p.z + 6], 0.5, 0.5, '#5a3a20', 8, { cap: 1 }); } o.r = 40; o.lights = [{ x: p.x, y: y + 3, z: p.z + 3, c: [1, 0.8, 0.5], r: 14 }]; };
LMBUILD.food = function (o, p) { var y = p.h; parkStall(o.m, o.glow, p.x - 6, y, p.z - 4, 0, 'pk_food', '#c4121c'); parkStall(o.m, o.glow, p.x + 6, y, p.z - 4, 0, 'pk_candy', '#ff7ab0'); addBox(p.x - 7.6, p.z - 5, p.x - 4.4, p.z - 3, y, y + 2.6); addBox(p.x + 4.4, p.z - 5, p.x + 7.6, p.z - 3, y, y + 2.6);
  for (var t = 0; t < 4; t++) { var tx = p.x - 7 + t * 4.7, tz = p.z + 4; boxC(o.m, tx - 0.9, y + 0.7, tz - 0.6, tx + 0.9, y + 0.78, tz + 0.6, '#6a4a2a'); boxC(o.m, tx - 0.9, y + 0.4, tz - 1.1, tx + 0.9, y + 0.46, tz - 0.8, '#6a4a2a'); boxC(o.m, tx - 0.9, y + 0.4, tz + 0.8, tx + 0.9, y + 0.46, tz + 1.1, '#6a4a2a'); tub(o.m, [tx, y, tz], [tx, y + 2.4, tz], 0.04, 0.04, '#c8ccd0', 4); tub(o.m, [tx, y + 2.4, tz], [tx, y + 2.9, tz], 1.5, 0.05, t % 2 ? '#c4121c' : '#f1e7d0', 8); addPost(tx, tz, 0.9, y, y + 0.8); } o.r = 40; };
LMBUILD.steve = function (o, p) { var y = p.h; boxT(o.m, p.x - 2.5, y, p.z - 2.5, p.x + 2.5, y + 1.6, p.z + 2.5, { wall: 'stone', top: 'stone', u: 1, v: 1 }); var s = 2.6; ell(o.m, p.x, y + 1.6 + s * 1.1, p.z, s, s * 1.1, s, '#12040a', 14, 9); tub(o.m, [p.x, y + 1.6 + s * 1.9, p.z], [p.x + 0.4, y + 1.6 + s * 3.0, p.z], s * 0.5, 0, '#12040a', 10);
  [-1, 1].forEach(function (q) { ell(o.glow, p.x + q * 0.9, y + 1.6 + s * 1.35, p.z + s * 0.9, 0.42, 0.5, 0.12, '#ff2630', 7, 4); }); for (var t = 0; t < 7; t++) { var a = -0.8 + t * 0.27; ell(o.m, p.x + Math.sin(a) * 1.5, y + 1.6 + s * 0.85 - Math.cos(a) * 0.3, p.z + s * 0.95, 0.2, 0.14, 0.08, '#f1e7d0', 5, 3); }
  ell(o.glow, p.x, y + 1.6 + s * 1.1, p.z, s * 1.02, s * 1.12, s * 1.02, '#c4121c', 14, 9); addBox(p.x - 2.5, p.z - 2.5, p.x + 2.5, p.z + 2.5, y, y + 8); o.r = 50; o.lights = [{ x: p.x, y: y + 4, z: p.z + 3, c: [1, 0.2, 0.25], r: 14 }];
  o.glowAlpha = 0.25; };
LMBUILD.fountain2 = function (o, p) { var y = p.h; tub(o.m, [p.x, y, p.z], [p.x, y + 0.8, p.z], 7, 7, '#5a5250', 18); o.m.quad([p.x - 6.8, y + 0.6, p.z - 6.8], [p.x - 6.8, y + 0.6, p.z + 6.8], [p.x + 6.8, y + 0.6, p.z + 6.8], [p.x + 6.8, y + 0.6, p.z - 6.8], UV1, TL('cream'), [0.6, 0.6, 0.6], [0, 1, 0], 0.2); tub(o.m, [p.x, y, p.z], [p.x, y + 3, p.z], 1, 0.6, '#5a5250', 10); tub(o.m, [p.x, y + 3, p.z], [p.x, y + 3.3, p.z], 2.6, 2.6, '#5a5250', 12, { cap: 1 });
  var jet = new R3.Mesh(); ring(jet, 0, 0, 0, 4.5, 8, function (x, z) { tub(jet, [x, 0.6, z], [x * 0.6, 3.4, z * 0.6], 0.12, 0.05, '#f6ecd0', 4); }); tub(jet, [0, 3.3, 0], [0, 6, 0], 0.25, 0.05, '#f6ecd0', 6); var jm = jet.upload(); o.parts.push({ m: jm, f: function (t) { return MD(p.x, y + Math.sin(t * 4) * 0.08, p.z, 0, 0, 0); } });
  addPost(p.x, p.z, 7, y, y + 0.8); o.r = 40; };
LMBUILD.balloons = function (o, p) { var y = p.h; for (var c = 0; c < 3; c++) { var cx = p.x - 8 + c * 8; boxC(o.m, cx - 1, y + 0.4, p.z - 0.6, cx + 1, y + 1.3, p.z + 0.6, '#c4121c'); tub(o.m, [cx - 0.8, y + 0.35, p.z - 0.65], [cx - 0.8, y + 0.35, p.z + 0.65], 0.35, 0.35, '#12040a', 8);
    for (var b = 0; b < 9; b++) { var a = b * 2.4, bx = cx + Math.cos(a) * (0.3 + b * 0.05), bz = p.z + Math.sin(a) * (0.3 + b * 0.05), by = y + 3.2 + (b % 3) * 0.5; tub(o.m, [cx, y + 1.3, p.z], [bx, by - 0.4, bz], 0.01, 0.01, '#f1e7d0', 3); ell(o.m, bx, by, bz, 0.35, 0.42, 0.35, ['#c4121c', '#ffe36a', '#ff7ab0', '#4adfff', '#12040a', '#7aff6a'][(b + c) % 6], 7, 5); } } o.r = 40; };
LMBUILD.mirrors = function (o, p) { var y = p.h, w = 8, d = 6; boxT(o.m, p.x - w, y, p.z - d, p.x + w, y + 7, p.z + d, { wall: 'w_redbrick', top: 'roof', u: 3, v: 2 }); for (var k = 0; k < 5; k++) standQ(o.glow, p.x - w + 2 + k * 3, p.z + d + 0.03, 0, 2, y + 0.4, y + 4.2, TL('w_glass'), 0.9, 0.5); standQ(o.glow, p.x, p.z + d + 0.08, 0, 9, y + 4.8, y + 6.4, TL('pk_mirrors'), 1.3, 0.6, [0, 0.69, 1, 0.69, 1, 0.31, 0, 0.31]);
  addBox(p.x - w, p.z - d, p.x + w, p.z + d, y, y + 7); o.r = 50; o.lights = [{ x: p.x, y: y + 5, z: p.z + d + 2, c: [1, 0.4, 0.8], r: 12 }]; };
LMBUILD.arcadehall = function (o, p) { var y = p.h, w = 9, d = 7; boxT(o.m, p.x - w, y, p.z - d, p.x + w, y + 8, p.z + d, { wall: 'w_redbrick', top: 'roof', u: 3, v: 2 }); var s = KIT.SPR && KIT.SPR.fac_arcade;
  if (s && KIT.sheet) { o.fr = new R3.Mesh(); var wd = 8.6; frontQuad(o.fr, s, p.x, p.z + d + 0.06, 0, wd, y, y + wd * s[3] / s[2]); o.fr = o.fr.upload(); }
  p.door = { x: p.x, z: p.z + d + 1.2 }; addBox(p.x - w, p.z - d, p.x + w, p.z + d, y, y + 8); o.r = 60; o.lights = [{ x: p.x, y: y + 4, z: p.z + d + 3, c: [0.4, 0.8, 1], r: 16 }]; };
/* the paths: lamps every few tiles with bunting strung between them, benches and bins, flower beds round the lawns,
   and railings round the edge of the park. Built into the chunk meshes, no draw calls of their own. */
function parkDress(M0, GLOW, x0, z0, CS, lamps, first) { if (!PARKCELL.length) return; var i0 = Math.floor(x0 / CT), j0 = Math.floor(z0 / CT), n = Math.round(CS / CT), BUNT = ['#c4121c', '#ffe36a', '#f1e7d0', '#ff7ab0', '#12040a'];
  for (var j = j0; j < Math.min(MH, j0 + n); j++) for (var i = i0; i < Math.min(MW, i0 + n); i++) { var t = j * MW + i; if (!PARKPATH[t]) continue;
    var cx = i * CT + 2, cz = j * CT + 2, y = groundY(cx, cz) + 0.15, lawn = [[1, 0], [-1, 0], [0, 1], [0, -1]].filter(function (q) { return KM[(j + q[1]) * MW + i + q[0]] === K_PARK; })[0];
    if (!lawn) continue; var ex = cx + lawn[0] * 1.6, ez = cz + lawn[1] * 1.6, along = lawn[0] ? [0, 1] : [1, 0], r = hash2(i, j, 41);
    if ((lawn[0] ? j : i) % 5 === 0) { var L = sfDraw(M0, 'lamp', ex, y, ez, Math.atan2(-lawn[0], -lawn[1]), GLOW); if (L) lamps.push(L); ell(GLOW, ex, y + 4.3, ez, 0.3, 0.3, 0.3, BUNT[(i + j) % 4], 5, 3); if (first) addPost(ex, ez, 0.16, y, y + 5);
      // bunting to the next lamp along
      var fx = ex + along[0] * 20, fz = ez + along[1] * 20; if (PARKPATH[Math.floor(fz / CT) * MW + Math.floor(fx / CT)]) for (var b = 0; b < 12; b++) { var u = (b + 0.5) / 12, bx = ex + (fx - ex) * u, bz = ez + (fz - ez) * u, by = y + 4.6 - Math.sin(u * Math.PI) * 0.9, c = BUNT[b % BUNT.length];
        M0.tri([bx - along[0] * 0.35, by, bz - along[1] * 0.35], [bx + along[0] * 0.35, by, bz + along[1] * 0.35], [bx, by - 0.55, bz], UV1, TL('white'), litc(c, [lawn[0], 0, lawn[1]]), [lawn[0], 0, lawn[1]]);
        M0.tri([bx + along[0] * 0.35, by, bz + along[1] * 0.35], [bx - along[0] * 0.35, by, bz - along[1] * 0.35], [bx, by - 0.55, bz], UV1, TL('white'), litc(c, [-lawn[0], 0, -lawn[1]]), [-lawn[0], 0, -lawn[1]]); } }
    else if (r < 0.22) { sfDraw(M0, 'bench', ex, y, ez, Math.atan2(-lawn[0], -lawn[1]), GLOW); if (first) addPost(ex, ez, 0.6, y, y + 1); }
    else if (r < 0.3) { sfDraw(M0, 'bin', ex, y, ez, 0, GLOW); if (first) addPost(ex, ez, 0.3, y, y + 1); }
    // a flower bed along the lawn's edge
    var fx2 = cx + lawn[0] * 2.6, fz2 = cz + lawn[1] * 2.6, gy = groundY(fx2, fz2); boxC(M0, fx2 - (along[0] * 2 + 0.3), gy, fz2 - (along[1] * 2 + 0.3), fx2 + (along[0] * 2 + 0.3), gy + 0.25, fz2 + (along[1] * 2 + 0.3), '#4a3020');
    for (var f2 = 0; f2 < 4; f2++) { var px = fx2 + along[0] * (-1.5 + f2), pz = fz2 + along[1] * (-1.5 + f2); ell(M0, px, gy + 0.4, pz, 0.32, 0.25, 0.32, ['#c4121c', '#ffe36a', '#ff7ab0', '#f1e7d0'][(f2 + i + j) % 4], 5, 3); } }
}
/* update 156 (his ask: still things in the middle of the road): any landmark standing within 5 m of a road's edge
   is pushed back off it before it is built (dock cranes and an island hut stood on the road). */
(function offRoad() { var SKIP = { gate: 1, bridge: 1, runway: 1, terminal: 1, boats: 1, tower2: 1, coaster: 1, flume: 1 };
  POIS.forEach(function (p) { if (SKIP[p.k] || PARKCELL.indexOf(p) >= 0) return; for (var n = 0; n < 6; n++) { var r = nearestRoad(p.x, p.z, 20); if (!r) return; var need = r.E.w / 2 + 6; if (r.d >= need) return;
    var nx = r.d > 0.3 ? (p.x - r.x) / r.d : r.dz, nz = r.d > 0.3 ? (p.z - r.z) / r.d : -r.dx; p.x = r.x + nx * (need + 0.5); p.z = r.z + nz * (need + 0.5); p.h = groundY(p.x, p.z); } }); })();
/* update 156 (his ask: weird spaces between buildings should be alleyways): the yards and gaps between buildings
   (lot tiles no building stands on) get alley clutter: dumpsters, bin bags, crates and pallets, a steaming grate,
   a fire escape ladder's foot, strings of bulbs across in the busy districts. */
function alleyDress(M0, GLOW, x0, z0, CS, first) { // update 157: only real alleys (a building close on both sides) get clutter; open lots get parking bays
  var i0 = Math.floor(x0 / CT), j0 = Math.floor(z0 / CT), n = Math.round(CS / CT);
  function inB(x, z, m) { return near(BGRID, x, z, 3 + m).some(function (b) { return x > b.x0 - m && x < b.x1 + m && z > b.z0 - m && z < b.z1 + m; }); }
  function wall(x, z, dx, dz) { for (var d = 0.5; d <= 7; d += 0.5) if (inB(x + dx * d, z + dz * d, 0)) return d; return 0; }
  for (var j = j0; j < Math.min(MH, j0 + n); j++) for (var i = i0; i < Math.min(MW, i0 + n); i++) { var t = j * MW + i; if (KM[t] !== K_LOT) continue;
    var cx = i * CT + 2, cz = j * CT + 2; if (inB(cx, cz, 0.3)) continue; var y = groundY(cx, cz), st = DIST[DM[t]].style;
    var wx0 = wall(cx, cz, -1, 0), wx1 = wall(cx, cz, 1, 0), wz0 = wall(cx, cz, 0, -1), wz1 = wall(cx, cz, 0, 1), alleyX = wx0 && wx1, alleyZ = wz0 && wz1;
    if (!alleyX && !alleyZ) { // an open lot: white parking bays painted on it
      if (!nearestRoad(cx, cz, 3)) { var ax = hash2(Math.floor(i / 8), Math.floor(j / 8), 9) < 0.5; for (var q = 0; q < 2; q++) { var o = -1 + q * 2.6; if (ax) M0.quad([cx + o - 0.06, y + 0.03, cz - 1.9], [cx + o - 0.06, y + 0.03, cz + 1.9], [cx + o + 0.06, y + 0.03, cz + 1.9], [cx + o + 0.06, y + 0.03, cz - 1.9], UV1, TL('white'), [0.5, 0.5, 0.48], [0, 1, 0]);
        else M0.quad([cx - 1.9, y + 0.03, cz + o - 0.06], [cx - 1.9, y + 0.03, cz + o + 0.06], [cx + 1.9, y + 0.03, cz + o + 0.06], [cx + 1.9, y + 0.03, cz + o - 0.06], UV1, TL('white'), [0.5, 0.5, 0.48], [0, 1, 0]); } }
      continue; }
    var r1 = hash2(i, j, 51); if (r1 > 0.35) continue; if (nearestRoad(cx, cz, 4)) continue;
    // clutter stands against one wall of the alley
    var a = alleyX ? (hash2(i, j, 57) < 0.5 ? Math.PI / 2 : -Math.PI / 2) : (hash2(i, j, 57) < 0.5 ? 0 : Math.PI), wd = alleyX ? (a > 0 ? wx1 : wx0) : (a === 0 ? wz1 : wz0), px = cx + Math.sin(a) * Math.max(0, wd - 0.8), pz = cz + Math.cos(a) * Math.max(0, wd - 0.8), py = groundY(px, pz), kind = Math.floor(hash2(i, j, 55) * 5);
    if (kind === 0) { boxR(M0, px, pz, a, 0.95, 0.6, py, py + 1.25, st === 'redlight' ? '#3a1a1e' : '#2e4a34'); boxR(M0, px, pz, a, 1.0, 0.65, py + 1.25, py + 1.35, '#1a1a1e'); if (first) addPost(px, pz, 0.7, py, py + 1.4); }
    else if (kind === 1) { for (var b = 0; b < 4; b++) ell(M0, px + Math.cos(b * 1.7) * 0.45, py + 0.3, pz + Math.sin(b * 1.7) * 0.45, 0.36, 0.33, 0.34, b % 2 ? '#141416' : '#1e1e22', 6, 4); }
    else if (kind === 2) { boxR(M0, px, pz, a, 0.5, 0.5, py, py + 0.9, '#7a5a34', 'plank'); boxR(M0, px, pz, a, 0.4, 0.4, py + 0.9, py + 1.6, '#8a6a3a', 'plank'); if (first) addPost(px, pz, 0.5, py, py + 1.6); }
    else if (kind === 3) { for (var p2 = 0; p2 < 3; p2++) boxR(M0, px, pz, a, 0.6, 0.5, py + p2 * 0.15, py + p2 * 0.15 + 0.1, '#8a6a40', 'plank'); }
    else { boxR(M0, px, pz, a, 0.32, 0.3, py, py + 0.95, '#2a2a2e'); boxR(M0, px, pz, a, 0.34, 0.32, py + 0.95, py + 1.0, '#1a1a1e'); if (first) addPost(px, pz, 0.35, py, py + 1); }
    // a string of bulbs right across the alley, hooked to both walls
    if (/redlight|cafe|downtown/.test(st) && hash2(i, j, 56) < 0.4) { var ex0, ez0, ex1, ez1; if (alleyX) { ex0 = cx - wx0; ex1 = cx + wx1; ez0 = ez1 = cz; } else { ez0 = cz - wz0; ez1 = cz + wz1; ex0 = ex1 = cx; }
      var hy = y + 4.2; tub(M0, [ex0, hy, ez0], [ex1, hy - 0.05, ez1], 0.012, 0.012, '#1a1a1e', 3); boxC(M0, ex0 - 0.08, hy - 0.08, ez0 - 0.08, ex0 + 0.08, hy + 0.08, ez0 + 0.08, '#1a1a1e'); boxC(M0, ex1 - 0.08, hy - 0.08, ez1 - 0.08, ex1 + 0.08, hy + 0.08, ez1 + 0.08, '#1a1a1e');
      var nb = Math.max(3, Math.round(Math.hypot(ex1 - ex0, ez1 - ez0) / 0.9)); for (var q2 = 1; q2 < nb; q2++) { var u2 = q2 / nb, bx = ex0 + (ex1 - ex0) * u2, bz = ez0 + (ez1 - ez0) * u2, by = hy - Math.sin(u2 * Math.PI) * 0.35; ell(GLOW, bx, by - 0.08, bz, 0.07, 0.09, 0.07, ['#ffe36a', '#ff7ab0', '#4adfff'][q2 % 3], 4, 3); } } }
}

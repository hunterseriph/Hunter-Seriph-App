/* =====================================================================================================
   TEXTURES FOR OUTSIDE: the woods (grass, dirt, bark, leaves, bushes), the road, and Clubhouse Row's red light
   district (black brick, windows lit red, pavements, neon signs, the moon, fire and smoke).
   ===================================================================================================== */
PAINT.grass = function (p) { p.fill('#1a2a16'); p.speck(['#24381c', '#12200e', '#2e4422', '#3a2a18'], 300); for (var i = 0; i < 26; i++) { var x = Math.floor(p.rnd() * 32), y = Math.floor(p.rnd() * 32); p.rect(x, y, 1, 2, '#3a5a2a'); } };
PAINT.dirt = function (p) { p.fill('#3a2a1c'); p.speck(['#2a1e14', '#4a3624', '#5a4430', '#1e1610'], 320); };
PAINT.bark = function (p) { p.fill('#2a1e18'); for (var x = 0; x < 32; x += 3) { var c = shade('#2a1e18', 0.7 + p.rnd() * 0.6); p.rect(x, 0, 2, 32, c); } p.speck(['#1a120e', '#3a2c22'], 120); for (var k = 0; k < 6; k++) p.rect(Math.floor(p.rnd() * 32), Math.floor(p.rnd() * 32), 3, 1, '#120c08'); };
PAINT.leaves = function (p) { p.fill('#0e1a10'); for (var i = 0; i < 60; i++) { var x = Math.floor(p.rnd() * 32), y = Math.floor(p.rnd() * 32); p.rect(x, y, 3, 2, shade('#1e3420', 0.6 + p.rnd() * 0.7)); } p.speck(['#2a4428', '#08100a'], 120); };
PAINT.rockt = function (p) { p.fill('#3a3836'); p.speck(['#2a2826', '#4a4846', '#5a5654'], 300); };
PAINT.canvas = function (p) { p.fill('#4a3a26'); for (var y = 0; y < 32; y += 4) p.rect(0, y, 32, 1, '#3a2c1c'); p.speck(['#5a4a32', '#6a0a10'], 60); };
PAINT.asphalt = function (p) { p.fill('#1c1a1c'); p.speck(['#141214', '#262426', '#2e2a2e', '#3a1418'], 360); };
PAINT.pave = function (p) { p.fill('#2a2628'); for (var y = 0; y < 32; y += 8) for (var x = 0; x < 32; x += 8) { p.rect(x, y, 8, 1, '#141214'); p.rect(x, y, 1, 8, '#141214'); } p.speck(['#3a3436', '#201c1e'], 200); };
PAINT.citywall = pBricks('#2a1416', '#0c0606', 4, 8);
PAINT.windows = function (p) { p.fill('#1a0e10'); for (var y = 2; y < 32; y += 16) for (var x = 2; x < 32; x += 16) { var lit = p.rnd(); p.rect(x, y, 11, 11, '#0a0406'); if (lit < 0.5) { p.rect(x + 1, y + 1, 9, 9, lit < 0.25 ? '#c4121c' : '#6a1018'); p.rect(x + 1, y + 1, 9, 2, '#ff6a5a'); } p.rect(x + 5, y, 1, 11, '#0a0406'); } };
PAINT.roof = function (p) { p.fill('#141012'); p.speck(['#1e1a1c', '#0c0a0a'], 160); };
PAINT.road = function (p) { p.fill('#1c1a1c'); p.speck(['#141214', '#262426', '#2e2a2e'], 300); p.rect(15, 0, 2, 12, '#c8a040'); p.rect(15, 20, 2, 12, '#c8a040'); };
PAINT.roadedge = function (p) { p.fill('#1c1a1c'); p.speck(['#141214', '#262426'], 200); p.rect(28, 0, 2, 32, '#d8d0c0'); };
PAINT.carpaint = function (p) { p.fill('#ffffff'); p.speck(['#e8e8e8'], 60); };
PAINT.metal = function (p) { p.fill('#4a4a4e'); p.speck(['#3a3a3e', '#5a5a5e', '#6a3a1a'], 200); };
function neon(txt, col, sz, font) { return function (g) { g.textAlign = 'center'; g.textBaseline = 'middle'; g.font = (font || 'bold ') + sz + 'px "Archivo Narrow", sans-serif'; g.lineWidth = 6; g.strokeStyle = 'rgba(255,40,60,0.35)'; var L = txt.split('\n'); L.forEach(function (s, i) { var y = 32 + (i - (L.length - 1) / 2) * sz; g.strokeText(s, 32, y); g.fillStyle = col; g.fillText(s, 32, y); }); }; }
HIPAINT.n_girls = neon('GIRLS\nGIRLS', '#ff4a6a', 18); HIPAINT.n_xxx = neon('XXX', '#ff2630', 28); HIPAINT.n_live = neon('LIVE\nSHOW', '#ff6a9a', 18); HIPAINT.n_peep = neon('PEEP', '#ff4a8a', 22); HIPAINT.n_open = neon('OPEN\n24/7', '#ff3a3a', 18); HIPAINT.n_cum = neon('CUM\nIN', '#ff2630', 20);
HIPAINT.n_heart = function (g) { g.strokeStyle = 'rgba(255,40,60,0.35)'; g.lineWidth = 8; g.fillStyle = '#ff2630'; g.beginPath(); g.moveTo(32, 54); g.bezierCurveTo(4, 34, 10, 6, 32, 20); g.bezierCurveTo(54, 6, 60, 34, 32, 54); g.stroke(); g.fill(); g.fillStyle = '#ff9aa8'; g.beginPath(); g.arc(22, 24, 4, 0, 6.28); g.fill(); };
HIPAINT.n_lips = function (g) { g.fillStyle = '#ff2630'; g.beginPath(); g.moveTo(6, 32); g.quadraticCurveTo(20, 14, 32, 24); g.quadraticCurveTo(44, 14, 58, 32); g.quadraticCurveTo(32, 54, 6, 32); g.fill(); g.strokeStyle = '#5a0a10'; g.lineWidth = 3; g.beginPath(); g.moveTo(10, 32); g.quadraticCurveTo(32, 38, 54, 32); g.stroke(); };
HIPAINT.bush = function (g, r) { for (var i = 0; i < 40; i++) { g.fillStyle = ['#0e1a10', '#16261a', '#1e3420', '#0a120a'][i % 4]; g.beginPath(); g.ellipse(6 + r() * 52, 14 + r() * 50, 6 + r() * 8, 4 + r() * 6, r() * 3, 0, 6.28); g.fill(); } };
HIPAINT.moon = function (g) { var gr = g.createRadialGradient(32, 32, 10, 32, 32, 32); gr.addColorStop(0, 'rgba(255,60,60,0.9)'); gr.addColorStop(0.62, 'rgba(196,18,28,0.85)'); gr.addColorStop(0.66, 'rgba(120,10,16,0.35)'); gr.addColorStop(1, 'rgba(60,0,8,0)'); g.fillStyle = gr; g.fillRect(0, 0, 64, 64); g.fillStyle = 'rgba(90,0,8,0.5)'; g.beginPath(); g.arc(26, 26, 5, 0, 6.28); g.arc(40, 36, 4, 0, 6.28); g.arc(30, 42, 3, 0, 6.28); g.fill(); };
HIPAINT.flame = function (g) { var gr = g.createRadialGradient(32, 46, 2, 32, 40, 30); gr.addColorStop(0, 'rgba(255,240,160,1)'); gr.addColorStop(0.35, 'rgba(255,140,30,0.95)'); gr.addColorStop(0.7, 'rgba(200,30,10,0.6)'); gr.addColorStop(1, 'rgba(120,0,0,0)'); g.fillStyle = gr; g.beginPath(); g.moveTo(10, 60); g.quadraticCurveTo(6, 30, 24, 18); g.quadraticCurveTo(28, 30, 32, 4); g.quadraticCurveTo(40, 26, 44, 16); g.quadraticCurveTo(60, 34, 54, 60); g.fill(); };
HIPAINT.smoke = function (g) { var gr = g.createRadialGradient(32, 32, 2, 32, 32, 30); gr.addColorStop(0, 'rgba(40,36,36,0.8)'); gr.addColorStop(1, 'rgba(20,18,18,0)'); g.fillStyle = gr; g.fillRect(0, 0, 64, 64); };
HIPAINT.poo = function (g) { g.fillStyle = '#5a3010'; g.beginPath(); g.ellipse(32, 40, 26, 14, 0, 0, 6.28); g.fill(); g.fillStyle = '#7a4418'; g.beginPath(); g.ellipse(30, 36, 18, 9, 0, 0, 6.28); g.fill(); g.fillStyle = '#9a6030'; g.beginPath(); g.ellipse(24, 32, 6, 3, 0, 0, 6.28); g.fill(); g.strokeStyle = 'rgba(120,200,60,0.8)'; g.lineWidth = 2; for (var i = 0; i < 3; i++) { g.beginPath(); g.arc(18 + i * 14, 14 + (i % 2) * 6, 4, 0, 6.28); g.stroke(); } };
HIPAINT.stink = function (g) { g.strokeStyle = 'rgba(140,210,70,0.9)'; g.lineWidth = 3; for (var i = 0; i < 3; i++) { g.beginPath(); g.moveTo(16 + i * 16, 60); g.bezierCurveTo(6 + i * 16, 40, 26 + i * 16, 30, 14 + i * 16, 6); g.stroke(); } };
HIPAINT.shopglow = function (g) { g.fillStyle = '#2a0608'; g.fillRect(0, 0, 64, 64); g.fillStyle = '#c4121c'; g.fillRect(4, 8, 56, 48); g.fillStyle = '#ff6a5a'; g.fillRect(4, 8, 56, 6); g.fillStyle = '#12040a'; g.fillRect(30, 8, 4, 48); for (var i = 0; i < 4; i++) { g.fillStyle = 'rgba(20,4,8,0.6)'; g.fillRect(8 + i * 13, 30 + (i % 2) * 6, 8, 20); } };
HIPAINT.windscreen = function (g) { g.fillStyle = 'rgba(20,30,40,0.9)'; g.fillRect(0, 0, 64, 64); g.fillStyle = 'rgba(200,220,240,0.25)'; g.beginPath(); g.moveTo(8, 60); g.lineTo(26, 4); g.lineTo(34, 4); g.lineTo(16, 60); g.fill(); };
HIPAINT.headlight = function (g) { var gr = g.createRadialGradient(32, 32, 0, 32, 32, 32); gr.addColorStop(0, 'rgba(255,250,220,1)'); gr.addColorStop(0.4, 'rgba(255,230,160,0.6)'); gr.addColorStop(1, 'rgba(255,200,120,0)'); g.fillStyle = gr; g.fillRect(0, 0, 64, 64); };
/* the dead park: boarded stalls, faded stripes, rusted iron, the cream of the Load Flume, coaster rails, the haunted house */
PAINT.boards = function (p) { p.fill('#120a08'); for (var y = 0; y < 32; y += 6) { var c = shade('#3a281e', 0.6 + p.rnd() * 0.5), o = Math.floor(p.rnd() * 4); p.rect(o, y, 32 - o - Math.floor(p.rnd() * 4), 5, c); p.rect(o, y + 4, 32, 1, '#1a100c'); p.px(o + 2, y + 2, '#6a6a6a'); p.px(28, y + 2, '#6a6a6a'); } for (var i = 0; i < 32; i++) p.px(i, 31 - i, '#4a3426'); p.speck(['#1a100c', '#5a2a1a', '#3a0a0a'], 80); };
PAINT.stripes = function (p) { for (var x = 0; x < 32; x += 8) { p.rect(x, 0, 4, 32, '#7a1a1c'); p.rect(x + 4, 0, 4, 32, '#a89878'); } p.speck(['#3a2a20', '#5a0a10', '#2a1a14'], 160); };
PAINT.ironbar = function (p) { p.clear(); for (var x = 1; x < 32; x += 6) p.rect(x, 0, 2, 32, '#2a1a1a'); p.rect(0, 2, 32, 2, '#3a2222'); p.rect(0, 26, 32, 2, '#3a2222'); for (var x2 = 1; x2 < 32; x2 += 6) p.rect(x2 - 1, 0, 4, 2, '#4a2a2a'); };
PAINT.cream = function (p) { p.fill('#d8c8a0'); for (var i = 0; i < 14; i++) { var y = Math.floor(p.rnd() * 32); p.rect(Math.floor(p.rnd() * 24), y, 6 + Math.floor(p.rnd() * 8), 1, '#f0e4c4'); } p.speck(['#c0b08a', '#e8dcb8'], 90); };
PAINT.rail = function (p) { p.fill('#1a1416'); for (var y = 0; y < 32; y += 6) p.rect(0, y, 32, 3, '#3a2a20'); p.rect(4, 0, 3, 32, '#7a7a80'); p.rect(25, 0, 3, 32, '#7a7a80'); p.rect(5, 0, 1, 32, '#b0b0b8'); p.rect(26, 0, 1, 32, '#b0b0b8'); };
PAINT.lattice = function (p) { p.clear(); for (var i = 0; i < 32; i++) { p.px(i, i, '#5a1018'); p.px(31 - i, i, '#5a1018'); p.px(i, (i + 1) % 32, '#3a0a10'); } p.rect(0, 0, 32, 2, '#6a1420'); p.rect(0, 30, 32, 2, '#6a1420'); p.rect(0, 0, 2, 32, '#6a1420'); p.rect(30, 0, 2, 32, '#6a1420'); };
PAINT.hauntw = function (p) { p.fill('#1e1420'); for (var y = 0; y < 32; y += 16) for (var x = 0; x < 32; x += 16) { p.rect(x + 2, y + 2, 12, 12, '#2a1c2c'); p.rect(x + 2, y + 2, 12, 1, '#3a2a3a'); } p.speck(['#120a14', '#3a1020', '#2a1a10'], 120); };
PAINT.grave = function (p) { p.fill('#3a3a3c'); p.speck(['#2a2a2c', '#4a4a4c', '#2a3a2a'], 220); p.rect(10, 8, 12, 2, '#1a1a1c'); p.rect(15, 4, 2, 12, '#1a1a1c'); };
PAINT.polka = function (p) { p.fill('#c4121c'); for (var y = 2; y < 32; y += 8) for (var x = (y % 16 ? 2 : 6); x < 32; x += 8) p.rect(x, y, 3, 3, '#f1e7d0'); };
PAINT.clownskin = function (p) { p.fill('#f4f0e8'); p.speck(['#e8e0d4', '#fffaf4'], 60); };
PAINT.wigred = function (p) { p.fill('#c42a12'); for (var i = 0; i < 40; i++) p.rect(Math.floor(p.rnd() * 32), Math.floor(p.rnd() * 32), 1, 3, p.rnd() < 0.5 ? '#ff5a1a' : '#8a1a0a'); };
HIPAINT.n_ejac = neon('EJACULAND', '#ff2630', 13); HIPAINT.n_closed = neon('CLOSED', '#ff4a4a', 16); HIPAINT.n_flume = neon('LOAD\nFLUME', '#ffe36a', 18); HIPAINT.n_haunt = neon('HAUNTED\nHOUSE', '#7aff6a', 14); HIPAINT.n_coaster = neon('CRIMSON\nCOASTER', '#ff2630', 13);
HIPAINT.n_loaded = neon('MUST BE\nTHIS\nLOADED', '#ffe36a', 12); HIPAINT.n_fun = neon('FUN FOR\nALL', '#ff6a9a', 14);
HIPAINT.ghost = function (g) { g.fillStyle = 'rgba(230,230,240,0.85)'; g.beginPath(); g.moveTo(12, 60); g.quadraticCurveTo(8, 6, 32, 6); g.quadraticCurveTo(56, 6, 52, 60); for (var i = 0; i < 4; i++) g.quadraticCurveTo(48 - i * 10, 50, 44 - i * 10, 60); g.fill(); g.fillStyle = '#0a0408'; g.beginPath(); g.ellipse(24, 26, 5, 8, 0, 0, 6.28); g.ellipse(40, 26, 5, 8, 0, 0, 6.28); g.ellipse(32, 42, 4, 6, 0, 0, 6.28); g.fill(); };
HIPAINT.creamhand = function (g) { g.fillStyle = '#e8dcb8'; g.strokeStyle = '#5a4a30'; g.lineWidth = 2; g.beginPath(); g.moveTo(24, 64); g.lineTo(24, 30); for (var i = 0; i < 4; i++) { g.lineTo(22 + i * 6, 8 + Math.abs(i - 1.5) * 4); g.lineTo(27 + i * 6, 8 + Math.abs(i - 1.5) * 4); g.lineTo(27 + i * 6, 30); } g.lineTo(40, 64); g.closePath(); g.fill(); g.stroke(); };
HIPAINT.mirror = function (g) { var gr = g.createLinearGradient(0, 0, 64, 64); gr.addColorStop(0, '#3a3a48'); gr.addColorStop(0.5, '#8a8aa0'); gr.addColorStop(1, '#2a2a38'); g.fillStyle = '#4a3020'; g.fillRect(0, 0, 64, 64); g.fillStyle = gr; g.fillRect(6, 6, 52, 52); };
HIPAINT.f_tbclown = function (g) { g.fillStyle = '#f4f0e8'; g.fillRect(0, 0, 64, 64); g.scale(0.5, 0.5);
  fLine(g, [[14, 44], [114, 58]], 4, '#1a1010'); fEll(g, 46, 60, 15, 13, '#1a1010', K0, 2); // his eye patch, still on under the paint
  fShape(g, [[70, 40], [82, 26], [94, 40], [82, 80]], '#2a50c0'); fEye(g, 82, 60, 12, 14, '#c4121c', 0, '#ffe0e0'); // a blue diamond painted round his one eye
  fEll(g, 64, 78, 12, 11, '#e01010', K0, 3); fEll(g, 60, 74, 4, 3, '#ff8a8a');
  fShape(g, [[22, 88], [64, 128, 106, 88], [64, 104, 22, 88]], '#c4121c', K0, 3); g.fillStyle = '#fffaf0'; for (var t = 0; t < 8; t++) g.fillRect(36 + t * 7, 94 + Math.abs(t - 3.5) * 1.5, 5, 7); };
HIPAINT.n_steve = neon('STEVE\nSAYS HI', '#ff2630', 14);
HIPAINT.f_lab = function (g) { g.fillStyle = '#57300f'; g.fillRect(0, 0, 64, 64); g.strokeStyle = '#4a2408'; g.lineWidth = 2; g.beginPath(); g.arc(32, 64, 40, 3.6, 5.8); g.stroke();
  [[22, 28], [42, 28]].forEach(function (e) { g.fillStyle = '#fffaf0'; g.strokeStyle = '#12040a'; g.lineWidth = 2; g.beginPath(); g.ellipse(e[0], e[1], 8, 10, 0, 0, 6.28); g.fill(); g.stroke(); g.fillStyle = '#12040a'; g.beginPath(); g.ellipse(e[0] + 2, e[1] + 1, 4, 5, 0, 0, 6.28); g.fill(); g.fillStyle = '#ffffff'; g.fillRect(e[0] + 2, e[1] - 3, 2, 2); });
  g.fillStyle = '#3a0a0a'; g.strokeStyle = '#12040a'; g.lineWidth = 2; g.beginPath(); g.moveTo(18, 44); g.quadraticCurveTo(32, 58, 46, 44); g.quadraticCurveTo(32, 50, 18, 44); g.fill(); g.stroke(); g.fillStyle = '#fffaf0'; g.fillRect(24, 46, 16, 3); };
/* the basement's junk, and Cum City's other parts: the cemetery (stone, crypts, hedges), the cumstruction site
   (hoardings, plywood, portacabins, girders), the cafe streets (cobbles, awnings) */
PAINT.glassg = function (p) { p.fill('#1e4a2a'); p.speck(['#2a6a3a', '#123020', '#5aa06a'], 80); p.rect(6, 2, 2, 26, '#7ac08a'); };
PAINT.plastic = function (p) { p.fill('#b8401a'); p.speck(['#d8602a', '#8a2a10'], 60); };
PAINT.bone = function (p) { p.fill('#d8ccb0'); p.speck(['#b8ac90', '#ece2c8', '#8a7a60'], 120); };
PAINT.candle = function (p) { p.fill('#e8dcc0'); p.speck(['#d0c4a8', '#f4ecd8'], 60); for (var i = 0; i < 4; i++) p.rect(4 + i * 7, 0, 2, 6 + i * 2, '#f8f0dc'); };
PAINT.paper = function (p) { p.fill('#c8c0a8'); for (var y = 6; y < 30; y += 4) p.rect(4, y, 18 + Math.floor(p.rnd() * 8), 1, '#5a5448'); p.speck(['#a89a80', '#6a0a10'], 30); };
PAINT.pinkgoo = function (p) { p.fill('#ff4a8a'); p.speck(['#ff8ab0', '#c42a6a', '#ffd0e0'], 120); };
PAINT.cobble = function (p) { p.fill('#141012'); for (var y = 0; y < 32; y += 6) for (var x = (y / 6) % 2 ? -3 : 0; x < 32; x += 7) p.rect(x + 1, y + 1, 5, 4, shade('#3a3034', 0.7 + p.rnd() * 0.5)); p.speck(['#4a4044', '#0c0a0a'], 80); };
PAINT.stonewall = pBricks('#4a4a50', '#1e1e22', 6, 10);
PAINT.crypt = pBricks('#5a5a5e', '#2a2a2e', 8, 16);
PAINT.stonef = pTiles('#3e3e42', '#1a1a1e', 2, 6);
PAINT.marble = function (p) { p.fill('#b8b8b4'); for (var i = 0; i < 6; i++) { var x = Math.floor(p.rnd() * 32), y = 0; for (var k = 0; k < 32; k++) { p.px(x, y, '#7a7a78'); x += Math.round(p.rnd() * 2 - 1); y++; } } p.speck(['#a0a09c', '#d0d0cc', '#5a6a5a'], 120); };
PAINT.hedge = function (p) { p.fill('#0e180e'); for (var i = 0; i < 70; i++) p.rect(Math.floor(p.rnd() * 32), Math.floor(p.rnd() * 32), 2, 2, shade('#1e3420', 0.5 + p.rnd() * 0.8)); };
PAINT.hoarding = function (p) { p.fill('#3a2e22'); for (var x = 0; x < 32; x += 8) { p.rect(x, 0, 8, 32, shade('#5a4632', 0.7 + p.rnd() * 0.4)); p.rect(x, 0, 1, 32, '#1e160e'); } p.rect(0, 12, 32, 6, '#c4121c'); p.rect(0, 13, 32, 1, '#ff6a5a'); p.speck(['#1e160e', '#6a5a40'], 60); };
PAINT.plywood = function (p) { p.fill('#8a6a3a'); for (var y = 0; y < 32; y += 2) if (p.rnd() < 0.5) p.rect(0, y, 32, 1, shade('#8a6a3a', 0.8 + p.rnd() * 0.3)); p.speck(['#6a4a28', '#a8885a'], 70); };
PAINT.cabin = function (p) { p.fill('#4a5a4e'); for (var x = 0; x < 32; x += 4) p.rect(x, 0, 1, 32, '#2a3a2e'); p.speck(['#3a4a3e', '#6a7a6e', '#6a3a1a'], 90); };
PAINT.girder = function (p) { p.fill('#8a2a12'); p.rect(0, 0, 32, 4, '#5a1a0a'); p.rect(0, 28, 32, 4, '#5a1a0a'); for (var x = 2; x < 32; x += 8) p.rect(x, 10, 3, 3, '#3a0a04'); p.speck(['#a83a1a', '#4a1408'], 90); };
PAINT.hazard = function (p) { for (var x = -32; x < 32; x += 8) for (var y = 0; y < 32; y++) p.rect(x + y, y, 4, 1, '#d8a020'); p.speck(['#1a1410'], 60); };
PAINT.scaffold = function (p) { p.clear(); p.rect(0, 0, 32, 2, '#7a7a80'); p.rect(0, 15, 32, 2, '#7a7a80'); p.rect(0, 0, 2, 32, '#7a7a80'); p.rect(30, 0, 2, 32, '#7a7a80'); for (var i = 0; i < 30; i++) p.px(1 + i, 1 + i, '#5a5a60'); };
PAINT.awning = function (p) { for (var x = 0; x < 32; x += 8) { p.rect(x, 0, 4, 32, '#7a0a10'); p.rect(x + 4, 0, 4, 32, '#e8dcc0'); } p.speck(['#3a2a20', '#5a0a10'], 60); };
PAINT.dress = function (p) { p.fill('#d8d4c8'); for (var y = 0; y < 32; y += 4) p.rect(0, y, 32, 1, '#b8b4a8'); p.speck(['#a89a80', '#6a0a10', '#4a3a2a', '#f0ece0'], 140); };
PAINT.fur = function (p) { p.fill('#5a3e24'); for (var i = 0; i < 80; i++) p.rect(Math.floor(p.rnd() * 32), Math.floor(p.rnd() * 32), 1, 3, p.rnd() < 0.5 ? '#3a2814' : '#7a5a38'); p.speck(['#6a0a10'], 30); };
PAINT.pinkfrill = function (p) { p.fill('#ff7ab0'); for (var y = 0; y < 32; y += 6) for (var x = 0; x < 32; x += 4) p.rect(x, y, 3, 2, '#ffd0e4'); p.speck(['#c44a80', '#6a0a10'], 50); };
PAINT.nappy = function (p) { p.fill('#e8e0c8'); p.speck(['#c8b890', '#a89060', '#d8d0b0'], 150); for (var i = 0; i < 4; i++) p.rect(Math.floor(p.rnd() * 28), Math.floor(p.rnd() * 28), 4, 3, '#8a7040'); };
PAINT.puke = function (p) { p.fill('#8aa040'); p.speck(['#c0d060', '#5a7020', '#ff4a8a', '#ffe36a'], 200); };
PAINT.tvscreen = function (p) { p.fill('#5a5a60'); p.speck(['#2a2a30', '#9a9aa0', '#d0d0d8', '#1a1a20'], 500); };
PAINT.strongsuit = function (p) { for (var y = 0; y < 32; y += 6) { p.rect(0, y, 32, 3, '#c4121c'); p.rect(0, y + 3, 32, 3, '#f1e7d0'); } };
PAINT.leotard = function (p) { p.fill('#2a50c0'); for (var y = 0; y < 32; y += 8) for (var x = (y % 16 ? 0 : 4); x < 32; x += 8) p.rect(x, y, 2, 2, '#ffe36a'); };
HIPAINT.n_cafe = neon('CAFE', '#ffb04a', 24); HIPAINT.n_cuppa = neon('HOT\nCUMPUCCINO', '#ffd06a', 12); HIPAINT.n_eat = neon('EAT', '#ff6a3a', 28); HIPAINT.n_pizza = neon('PIZZA\nSLICES', '#ffe36a', 15); HIPAINT.n_chilli = neon('CHILLI', '#ff3a1a', 17);
HIPAINT.n_rip = neon('R.I.P.', '#cfe0ff', 20, 'bold '); HIPAINT.n_dig = neon('CUM\nSTRUCTION', '#ffb020', 13);
HIPAINT.splat = function (g, r) { g.fillStyle = '#f1e7d0'; for (var i = 0; i < 14; i++) { g.beginPath(); g.ellipse(32 + (r() - 0.5) * 30, 32 + (r() - 0.5) * 30, 6 + r() * 12, 5 + r() * 10, r() * 3, 0, 6.28); g.fill(); } g.fillStyle = '#d8c8a0'; for (var k = 0; k < 6; k++) { g.beginPath(); g.ellipse(32 + (r() - 0.5) * 24, 34 + (r() - 0.5) * 24, 4, 3, 0, 0, 6.28); g.fill(); } };
HIPAINT.ring = function (g) { g.strokeStyle = 'rgba(255,40,40,1)'; g.lineWidth = 5; g.beginPath(); g.arc(32, 32, 28, 0, 6.28); g.stroke(); g.strokeStyle = 'rgba(255,40,40,0.4)'; g.lineWidth = 3; g.beginPath(); g.arc(32, 32, 20, 0, 6.28); g.stroke(); };
PAINT.windowsw = function (p) { p.fill('#1a120c'); for (var y = 2; y < 32; y += 16) for (var x = 2; x < 32; x += 16) { var lit = p.rnd(); p.rect(x, y, 11, 11, '#0a0604'); if (lit < 0.55) { p.rect(x + 1, y + 1, 9, 9, lit < 0.3 ? '#d88a2a' : '#8a5018'); p.rect(x + 1, y + 1, 9, 2, '#ffd08a'); } p.rect(x + 5, y, 1, 11, '#0a0604'); } };
HIPAINT.shopgloww = function (g) { g.fillStyle = '#2a1406'; g.fillRect(0, 0, 64, 64); g.fillStyle = '#d88a2a'; g.fillRect(4, 8, 56, 48); g.fillStyle = '#ffd08a'; g.fillRect(4, 8, 56, 6); g.fillStyle = '#12040a'; g.fillRect(30, 8, 4, 48); for (var i = 0; i < 4; i++) { g.fillStyle = 'rgba(30,12,4,0.6)'; g.fillRect(8 + i * 13, 34, 8, 4); g.fillRect(10 + i * 13, 38, 4, 16); } };
HIPAINT.f_lab.big = true; // update 128: his face at 128 px too
/* update 131: the bar radio's front: a cloth speaker grille, a lit dial with a red needle, two knobs */
PAINT.radiofront = function (p) { p.fill('#3a2416'); p.rect(1, 1, 30, 30, '#5a3820'); p.rect(2, 2, 28, 1, '#7a5030');
  p.rect(3, 4, 16, 18, '#1e140c'); for (var y = 5; y < 22; y += 2) p.rect(3, y, 16, 1, '#2e2016'); for (var x = 4; x < 19; x += 3) p.rect(x, 4, 1, 18, '#120a06'); // the grille
  p.rect(21, 4, 8, 12, '#e8c070'); p.rect(21, 4, 8, 1, '#fff0b0'); for (var k = 0; k < 4; k++) p.rect(22, 6 + k * 3, 6, 1, '#8a6a30'); p.rect(25, 5, 1, 10, '#c4121c'); // the dial, lit
  p.rect(21, 19, 3, 3, '#12040a'); p.rect(26, 19, 3, 3, '#12040a'); p.px(22, 19, '#a89a8a'); p.px(27, 19, '#a89a8a'); p.rect(3, 25, 26, 4, '#2e1a0e'); };
/* update 131: real roads for Cum City (his ask: "the city needs to feel more like a city, with roads") */
function pRoad(p) { p.fill('#19171a'); p.speck(['#121013', '#232024', '#2b282c', '#0e0c0e', '#2a1416'], 420); for (var k = 0; k < 3; k++) { var y = Math.floor(p.rnd() * 32), x = Math.floor(p.rnd() * 20); p.rect(x, y, 6 + Math.floor(p.rnd() * 8), 1, '#0b0a0b'); } }
PAINT.road = function (p) { pRoad(p); };
PAINT.roadh = function (p) { pRoad(p); p.rect(6, 15, 20, 2, '#cfc6ae'); p.speck(['#19171a'], 4); };
PAINT.roadv = function (p) { pRoad(p); p.rect(15, 6, 2, 20, '#cfc6ae'); };
PAINT.zebrah = function (p) { pRoad(p); for (var y = 2; y < 32; y += 8) p.rect(0, y, 32, 4, '#d8d0b8'); p.speck(['#8a8478', '#19171a'], 60); };
PAINT.zebrav = function (p) { pRoad(p); for (var x = 2; x < 32; x += 8) p.rect(x, 0, 4, 32, '#d8d0b8'); p.speck(['#8a8478', '#19171a'], 60); };
PAINT.roadx = function (p) { pRoad(p); p.speck(['#3a1418'], 30); };
PAINT.kerb = function (p) { p.fill('#5a5452'); for (var x = 0; x < 32; x += 10) p.rect(x, 0, 1, 32, '#2a2626'); p.rect(0, 0, 32, 2, '#7a7270'); p.speck(['#4a4442', '#6a6260'], 90); };
PAINT.roadblock = function (p) { p.fill('#6a6460'); p.speck(['#5a5452', '#7a7470'], 160); for (var x = -32; x < 32; x += 8) for (var y = 8; y < 22; y++) { p.rect(x + y, y, 4, 1, '#c4121c'); p.rect(x + y + 4, y, 4, 1, '#e8e0d0'); } p.rect(0, 7, 32, 1, '#2a2626'); p.rect(0, 22, 32, 1, '#2a2626'); p.rect(0, 0, 32, 2, '#8a8480'); };

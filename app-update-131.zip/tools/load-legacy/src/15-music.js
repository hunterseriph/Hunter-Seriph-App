/* =====================================================================================================
   MUSIC: Load Legacy's own soundtrack. Written out note by note (melodies, chords, basslines and drums),
   played by a small 16-bit style synth: pulse-wave leads with vibrato, a pipe organ, a calliope for
   Ejaculand, a punchy bass and a noise drum kit. Melody tokens are eighth notes: a note like 'c#5',
   '-' to hold, '.' for a rest. Chords are one per bar.
   music.play(id) / music.stop(seconds) as before. Ids: title, town, castle, roof, park, dungeon, boss, blum, super.
   ===================================================================================================== */
var music = (function () {
  var A = null, bus = null, dl = null, tg = null, send = null, cur = null, want = null, song = null, nextT = 0, stepI = 0, nb = null, waves = {};
  var SONGS = {
    title: { bpm: 72, beats: 4, vol: 0.9, wet: 0.5, lead: 'organlead', bass: 'drone', acc: 'organ', drums: null,
      chords: 'Dm Bb Gm A Dm F C A',
      mel: 'd5 - - - a5 - - - | bb5 - a5 - g5 - f5 - | g5 - - - bb5 - d6 - | c#6 - - - e5 - - - | f5 - - - a5 - d6 - | c6 - - - a5 - f5 - | g5 - e5 - c5 - e5 g5 | a5 - - - - - - -' },
    town: { bpm: 112, beats: 4, vol: 0.85, wet: 0.3, lead: 'pulse', bass: 'walk', acc: 'arp8', drums: 'shuffle',
      chords: 'F C Dm Bb F C Bb C',
      mel: 'c5 - a4 c5 f5 - e5 f5 | g5 - e5 - c5 - - - | d5 - f5 a5 g5 f5 e5 d5 | f5 - - - d5 - - - | c5 - a4 c5 f5 - a5 - | g5 f5 e5 f5 g5 - c6 - | bb5 - a5 g5 f5 - d5 - | e5 - g5 - c5 - - -',
      counter: 'a4 - - - c5 - - - | e4 - - - g4 - - - | f4 - - - a4 - - - | d4 - - - f4 - - - | a4 - - - c5 - - - | e4 - - - g4 - - - | d4 - - - f4 - - - | g4 - - - e4 - - -' },
    castle: { bpm: 132, beats: 4, vol: 0.9, wet: 0.28, lead: 'pulse', bass: 'drive', acc: 'arp16', drums: 'rock',
      chords: 'Am Am F G Am Am Dm E F G Em Am Dm E Am E',
      mel: 'a4 - c5 e5 a5 - g5 e5 | f5 e5 d5 e5 c5 - b4 - | a4 - c5 f5 a5 - g5 f5 | g5 f5 e5 d5 b4 - g4 - | a4 - c5 e5 a5 - b5 c6 | b5 a5 g5 a5 e5 - - - | f5 - e5 d5 a5 - f5 d5 | e5 - g#5 - b5 - e5 - | ' +
           'c6 - - b5 a5 - f5 - | d6 - - c6 b5 - g5 - | b5 - g5 - e5 - g5 b5 | c6 - b5 a5 e5 - - - | d5 f5 a5 d6 c6 a5 f5 a5 | b5 g#5 e5 g#5 b5 - - - | a5 - e5 - c5 - e5 - | g#5 - b5 - e6 - - -' },
    roof: { bpm: 144, beats: 4, vol: 0.85, wet: 0.42, lead: 'pulse', bass: 'gallop', acc: 'arp16', drums: 'fast',
      chords: 'Em F Em D Em F G F',
      mel: 'e5 - - f5 g5 - b5 - | a5 - g5 f5 e5 - - - | e5 - b4 - e5 f5 g5 a5 | f#5 - a5 - d6 - c6 - | b5 - - - e6 - d6 - | c6 - a5 - f5 - a5 c6 | d6 - b5 - g5 - b5 d6 | c6 - b5 - a5 - g5 f5' },
    park: { bpm: 156, beats: 3, vol: 0.85, wet: 0.35, lead: 'calliope', bass: 'waltz', acc: 'stabs', drums: 'waltz',
      chords: 'Cm Cm G G Cm Cm Fm G Ab Ab Fm Fm Cm G Cm G',
      mel: 'g5 - - c6 - eb6 | d6 - c6 b5 - c6 | d6 - - g5 - - | f5 - eb5 d5 - b4 | c5 - eb5 g5 - c6 | eb6 - d6 c6 - g5 | ab5 - g5 f5 - ab5 | g5 - - - - - | ' +
           'c6 - - eb6 - c6 | ab5 - - c6 - ab5 | f5 - ab5 c6 - f6 | eb6 - d6 c6 - ab5 | g5 - c6 eb6 - g6 | f6 - eb6 d6 - b5 | c6 - g5 eb5 - g5 | b5 - - d6 - -' },
    dungeon: { bpm: 84, beats: 4, vol: 1, wet: 0.6, lead: 'soft', bass: 'drone', acc: 'bell', drums: 'slow',
      chords: 'Bm Bm C Bm G F# Bm F#',
      mel: 'f#4 - - - - - b4 - | d5 - - c#5 - - b4 - | c5 - - - e5 - - - | d5 - c#5 - b4 - - - | d5 - - - g5 - f#5 - | e5 - - - a#4 - c#5 - | b4 - - - - - - - | . . . . . . . .' },
    boss: { bpm: 164, beats: 4, vol: 0.9, wet: 0.22, lead: 'pulse', bass: 'pulse16', acc: 'arp16', drums: 'boss',
      chords: 'F#m F#m D E F#m F#m G C#',
      mel: 'f#5 f#5 . f#5 a5 . f#5 c#6 | b5 a5 g#5 a5 f#5 - - - | f#5 f#5 . f#5 a5 . d6 c#6 | b5 - g#5 - e5 - b4 - | c#6 - c#6 d6 c#6 b5 a5 f#5 | a5 - g#5 - f#5 - c#5 - | d6 - b5 - g5 - d6 - | c#6 - f5 - g#5 - c#6 -' },
    blum: { bpm: 150, beats: 4, vol: 0.9, wet: 0.3, lead: 'pulse', bass: 'drive', acc: 'organ', drums: 'boss',
      chords: 'Dm Bb Gm A Dm Bb Eb A Gm Dm Bb A Dm Gm A Dm',
      mel: 'd5 - f5 - a5 - d6 - | c#6 d6 c#6 bb5 a5 - f5 - | g5 - bb5 - d6 - g6 - | f6 - e6 - c#6 - a5 - | d6 - - a5 f5 - d5 - | bb5 - - f5 d5 - bb4 - | eb5 - g5 - bb5 - eb6 - | c#6 - - - e6 - - - | ' +
           'd6 - bb5 - g5 - d5 - | f5 - a5 - d6 - f6 - | e6 d6 c#6 d6 bb5 - f5 - | a5 - c#6 - e6 - a6 - | f6 - e6 d6 a5 - d6 - | bb5 - g5 - d5 - g5 - | e5 - a5 - c#6 - e6 - | d6 - - - - - - -' }
  };
  // Pulsar's tracks: he changes up the tunes when you visit his stall
  SONGS.pulsar1 = { bpm: 88, beats: 4, vol: 0.85, wet: 0.5, lead: 'soft', bass: 'walk', acc: 'arp8', drums: 'shuffle', chords: 'F Am Bb C F Am Gm C',
    mel: 'a5 - - g5 a5 - c6 - | e5 - - - - - . . | f5 - g5 - a5 - c6 - | bb5 - a5 - g5 - . . | a5 - - g5 a5 - c6 - | e6 - d6 - c6 - a5 - | g5 - f5 - d5 - f5 - | e5 - - - - - . .' };
  SONGS.pulsar2 = { bpm: 116, beats: 4, vol: 0.85, wet: 0.45, lead: 'pulse', bass: 'drive', acc: 'arp16', drums: 'rock', chords: 'Am F C G Am F C E',
    mel: 'e5 - a5 - c6 - b5 a5 | c6 - - - a5 - - - | g5 - e5 - g5 - c6 - | b5 - - - g5 - - - | e5 - a5 - c6 - e6 - | f6 - e6 - c6 - a5 - | g5 - c6 - e6 - g6 - | g#5 - b5 - e6 - - -' };
  SONGS.pulsar3 = { bpm: 76, beats: 4, vol: 1, wet: 0.7, lead: 'soft', bass: 'walk', acc: 'bell', drums: 'slow', chords: 'Dm Dm Gm A Dm Bb Gm A',
    mel: 'd5 - - - f5 - a5 - | . . c6 - a5 - - - | bb5 - - - g5 - d5 - | e5 - - - c#5 - - - | d5 - f5 - a5 - d6 - | . . bb5 - f5 - - - | g5 - bb5 - d6 - g5 - | a5 - - - - - . .' };
  /* the newer areas and every boss's own theme. 'fm' leads and the slap bass are FM synth, like a Mega Drive */
  SONGS.sewer = { bpm: 104, beats: 4, vol: 0.9, wet: 0.55, lead: 'fm', fmbass: 1, bass: 'walk', acc: 'bell', drums: 'shuffle', chords: 'Em Em Am B Em C Am B',
    mel: 'e4 - g4 a4 b4 - a4 g4 | e4 - - - . . b3 - | a4 - c5 - e5 - d5 c5 | b4 - - - d#5 - - - | e5 - d5 b4 g4 - e4 - | c5 - b4 - g4 - e4 - | a4 - - c5 b4 a4 g4 a4 | b4 - - - - - . .' };
  SONGS.bone = { bpm: 168, beats: 3, vol: 0.85, wet: 0.35, lead: 'xylo', bass: 'waltz', acc: 'stabs', drums: 'waltz', chords: 'Am Am E E Am Am Dm E Am C G E Am Dm E Am',
    mel: 'a5 - c6 - e6 - | d6 c6 b5 - a5 - | g#5 - b5 - e6 - | d6 - - - - - | a5 - c6 - e6 - | a6 - g6 - e6 - | f6 - e6 d6 c6 - | b5 - - - - - | c6 - e6 - a6 - | g6 - e6 - c6 - | b5 - d6 - g6 - | g#6 - - - e6 - | a6 - e6 - c6 - | d6 - f6 - a6 - | g#6 - e6 - b5 - | a5 - - - - -' };
  SONGS.furnace = { bpm: 150, beats: 4, vol: 0.9, wet: 0.25, lead: 'fm', fmbass: 1, bass: 'pulse16', acc: 'arp16', drums: 'industrial', chords: 'Dm Dm Bb C Dm Dm G A',
    mel: 'd5 . d5 . f5 . d5 a5 | g5 f5 e5 f5 d5 - - - | bb5 - a5 - g5 - f5 - | e5 - g5 - c6 - - - | d6 . d6 . c6 . a5 f5 | g5 a5 f5 g5 d5 - - - | b5 - g5 - d5 - b4 - | c#5 - e5 - a5 - - -' };
  SONGS.moonarea = { bpm: 88, beats: 4, vol: 0.95, wet: 0.65, lead: 'organlead', bass: 'drone', acc: 'bell', drums: 'slow', chords: 'C#m A F#m G# C#m A F#m G#',
    mel: 'c#5 - - - g#5 - - - | a5 - g#5 - e5 - - - | f#5 - - - a5 - c#6 - | b5 - - - g#5 - - - | e5 - - - c#6 - - - | b5 - a5 - g#5 - e5 - | f#5 - a5 - c#6 - e6 - | d#6 - - - g#5 - - -' };
  SONGS.bbeast = { bpm: 140, beats: 4, vol: 0.9, wet: 0.25, lead: 'fm', fmbass: 1, bass: 'gallop', acc: 'stabs', drums: 'boss', chords: 'Em C D B Em C Am B',
    mel: 'e5 - e5 - g5 - f#5 e5 | c5 - - - e5 - - - | d5 - f#5 - a5 - g5 f#5 | d#5 - - - b4 - - - | e5 g5 b5 e6 d6 b5 g5 e5 | c6 - b5 - g5 - e5 - | a5 - c6 - e6 - d6 c6 | b5 - - - d#6 - - -' };
  SONGS.bdemon = { bpm: 176, beats: 4, vol: 0.88, wet: 0.22, lead: 'pulse', harm: 1, bass: 'pulse16', acc: 'arp16', drums: 'fast', chords: 'Gm Gm Eb D Gm Gm C# D',
    mel: 'g5 a5 bb5 g5 d6 - c#6 d6 | bb5 a5 g5 a5 d5 - - - | eb5 g5 bb5 eb6 d6 - c6 bb5 | a5 - f#5 - d5 - - - | g5 - d6 - g6 - f6 - | eb6 d6 c6 bb5 a5 - g5 - | g#5 - c#6 - f6 - e6 - | d6 - c6 - a5 - f#5 -' };
  SONGS.bsperm = { bpm: 128, beats: 4, vol: 0.9, wet: 0.2, lead: 'fm', fmbass: 1, bass: 'drive', acc: 'arp16', drums: 'industrial', chords: 'Am Am G G F F E E',
    mel: 'a4 . a4 . a4 . c5 . | a4 . a4 . g4 . e4 . | g4 . g4 . g4 . b4 . | g4 . g4 . d5 . b4 . | f4 . a4 . c5 . f5 . | e5 . c5 . a4 . f4 . | e4 . g#4 . b4 . e5 . | g#5 - - - e5 - b4 -' };
  SONGS.bpig = { bpm: 152, beats: 4, vol: 0.88, wet: 0.25, lead: 'pulse', bass: 'walk', acc: 'arp8', drums: 'shuffle', chords: 'G G C D G Em C D',
    mel: 'd5 - g5 - b5 - a5 g5 | e5 - d5 - b4 - g4 - | c5 - e5 - g5 - e5 c5 | d5 - f#5 - a5 - - - | b5 - a5 g5 d5 - g5 - | e5 - g5 - b5 - e6 - | c6 - b5 a5 g5 - e5 - | d5 - f#5 - g5 - - -' };
  SONGS.bmoon = { bpm: 120, beats: 4, vol: 0.92, wet: 0.45, lead: 'organlead', harm: 1, bass: 'drive', acc: 'organ', drums: 'boss', chords: 'C#m C#m A B C#m G#m A G#',
    mel: 'c#5 - e5 - g#5 - c#6 - | b5 - a5 - g#5 - e5 - | a5 - c#6 - e6 - d#6 c#6 | d#6 - - - f#5 - b5 - | c#6 - - - e6 - - - | d#6 - b5 - g#5 - d#5 - | e5 - a5 - c#6 - e6 - | g#6 - - - c6 - d#6 -' };
  SONGS.brat = { bpm: 136, beats: 4, vol: 0.9, wet: 0.4, lead: 'xylo', bass: 'drone', acc: 'bell', drums: 'tribal', chords: 'Bm Bm G F# Bm Bm Em F#',
    mel: 'b4 - d5 - f#5 - b5 - | a5 - f#5 - d5 - c#5 - | d5 - g5 - b5 - d6 - | c#6 - - - a#5 - - - | b5 - b5 - b5 - a5 b5 | f#5 - d5 - b4 - - - | e5 - g5 - b5 - e6 - | c#6 - a#5 - f#5 - - -' };
  SONGS.bboner = { bpm: 120, beats: 4, vol: 0.9, wet: 0.35, lead: 'xylo', bass: 'walk', acc: 'stabs', drums: 'shuffle', chords: 'Dm Dm A A Dm Dm Gm A',
    mel: 'd5 - f5 a5 d6 - a5 - | f5 - d5 - a4 - - - | c#5 - e5 a5 c#6 - a5 - | e5 - c#5 - a4 - - - | d5 f5 a5 d6 f6 - d6 - | a5 - f5 - d5 - - - | g5 - bb5 - d6 - bb5 g5 | a5 - c#6 - e6 - - -' };
  SONGS.bhot = { bpm: 160, beats: 4, vol: 0.9, wet: 0.2, lead: 'fm', harm: 1, fmbass: 1, bass: 'pulse16', acc: 'arp16', drums: 'industrial', chords: 'Fm Fm Db Eb Fm Fm Bbm C',
    mel: 'f5 . f5 ab5 . c6 . f6 | eb6 . db6 . c6 - ab5 - | db6 - c6 - bb5 - ab5 - | g5 - bb5 - eb6 - - - | f6 . f6 . eb6 . c6 ab5 | bb5 c6 ab5 bb5 f5 - - - | bb5 - db6 - f6 - bb6 - | e6 - - - c6 - - -' };
  SONGS.lair = { bpm: 96, beats: 4, vol: 0.95, wet: 0.6, lead: 'organlead', harm: 1, bass: 'drone', acc: 'organ', drums: 'tribal', chords: 'Em Em C B Em G F# B Am Em C B Em C D# B',
    mel: 'e5 - - - b5 - - - | c6 - b5 - g5 - e5 - | c6 - - - e6 - - - | d#6 - - - b5 - - - | e6 - d6 - b5 - g5 - | d6 - - - b5 - g5 - | f#5 - a#5 - c#6 - f#6 - | d#6 - - - - - . . | ' +
         'a5 - c6 - e6 - a6 - | g6 - e6 - b5 - g5 - | e6 - - - c6 - a5 - | f#5 - a5 - b5 - d#6 - | e6 - - - g6 - e6 - | c6 - e6 - g6 - c7 - | b6 - g6 - d#6 - f#6 - | e6 - - - - - - -' };
  SONGS.bmega = { bpm: 172, beats: 4, vol: 0.92, wet: 0.24, lead: 'fm', harm: 1, fmbass: 1, bass: 'pulse16', acc: 'organ', drums: 'industrial', chords: 'Cm Cm Ab Bb Cm Cm Db G Fm Cm Ab G Cm Ab Bb Cm',
    mel: 'c5 . c5 eb5 . g5 . c6 | bb5 . ab5 . g5 - eb5 - | ab5 - c6 - eb6 - c6 ab5 | bb5 - d6 - f6 - d6 bb5 | c6 . c6 . eb6 . g6 - | f6 eb6 d6 eb6 c6 - - - | db6 - f6 - ab6 - f6 db6 | b5 - d6 - g6 - - - | ' +
         'ab5 - c6 - f6 - ab6 - | g6 - eb6 - c6 - g5 - | ab5 - c6 - eb6 - ab6 - | g6 - f6 - d6 - b5 - | c6 - eb6 - g6 - c7 - | ab6 - g6 - eb6 - c6 - | bb5 - d6 - f6 - bb6 - | c7 - - - - - - -' };
  SONGS.super = (function () { var s = {}; for (var k in SONGS.blum) s[k] = SONGS.blum[k]; s.bpm = 166; s.shift = 1; s.harm = 1; return s; })();
  // drum kits: one bar each, 16th notes (12 for a waltz). k kick, s snare, h hat, o open hat, t tom, '.' nothing
  var KITS = {
    rock: ['k.h.s.h.k.k.s.h.', 'k.h.s.h.k.khs.hh'],
    shuffle: ['k..h..s..h.kk..h', 'k..h..s..h.ks.hh'],
    fast: ['khhhshhhkhkhshhh', 'khhhshhhkhkhshto'],
    slow: ['k.......s.......', 'k.......s...t.t.'],
    boss: ['kkhkskhkkkhkskhk', 'kkhkskhkkkhkstto'],
    waltz: ['k...h...h...', 'k...h.h.h...'],
    industrial: ['k.hsk.hkk.hsk.hs', 'k.hsk.hkk.hstsst'],
    tribal: ['t.t.k.t.t.tk.t..', 't.t.k.t.ttk.tkt.']
  };
  var NOTE = { c: 0, d: 2, e: 4, f: 5, g: 7, a: 9, b: 11 };
  function midi(tok) { var m = /^([a-g])(#|b)?(-?\d)$/.exec(tok); if (!m) return null; return 12 * (+m[3] + 1) + NOTE[m[1]] + (m[2] === '#' ? 1 : m[2] === 'b' ? -1 : 0); }
  function chord(sym) {
    var m = /^([A-G])(#|b)?(m|dim)?$/.exec(sym), r = NOTE[m[1].toLowerCase()] + (m[2] === '#' ? 1 : m[2] === 'b' ? -1 : 0);
    var q = m[3] === 'm' ? [0, 3, 7] : m[3] === 'dim' ? [0, 3, 6] : [0, 4, 7]; return { r: r, q: q };
  }
  function mf(n) { return 440 * Math.pow(2, (n - 69) / 12); }
  function line(src, spb, shift) { // melody text -> [{s: step, n: midi, d: steps}]
    var toks = src.replace(/\|/g, ' ').trim().split(/\s+/), out = [], last = null;
    toks.forEach(function (t, i) { if (t === '-') { if (last) last.d += spb; } else if (t === '.') last = null; else { var n = midi(t); if (n !== null) { last = { s: i * spb, n: n + shift, d: spb }; out.push(last); } } });
    return { notes: out, len: toks.length * spb };
  }
  function compile(sp) {
    var bar = sp.beats * 4, shift = sp.shift || 0, ch = sp.chords.split(/\s+/).map(chord), L = line(sp.mel, 2, shift);
    var len = Math.max(L.len, ch.length * bar), ev = []; for (var i = 0; i < len; i++) ev.push([]);
    L.notes.forEach(function (n) { ev[n.s % len].push({ k: 'lead', n: n.n, d: n.d }); if (sp.harm) ev[n.s % len].push({ k: 'harm', n: n.n - 12, d: n.d }); });
    if (sp.counter) line(sp.counter, 2, shift).notes.forEach(function (n) { ev[n.s % len].push({ k: 'counter', n: n.n, d: n.d }); });
    var R = 1;
    for (var b = 0; b < len / bar; b++) {
      var c = ch[b % ch.length], root = 36 + ((c.r + shift) % 12 + 12) % 12, base = b * bar, tones = c.q.map(function (x) { return root + 24 + x; });
      if (root < 40) root += 12; // keep the bass out of the mud
      var bs = sp.bass, s;
      if (bs === 'drive') for (s = 0; s < bar; s += 2) ev[base + s].push({ k: 'bass', n: root + (s % 8 === 6 ? 12 : 0), d: 1.6 });
      else if (bs === 'gallop') for (s = 0; s < bar; s++) { if (s % 4 !== 1) ev[base + s].push({ k: 'bass', n: root, d: 0.9 }); }
      else if (bs === 'pulse16') for (s = 0; s < bar; s++) ev[base + s].push({ k: 'bass', n: root + (s % 8 === 7 ? 12 : 0), d: 0.85 });
      else if (bs === 'walk') [0, 4, 8, 12].forEach(function (s2, i) { ev[base + s2].push({ k: 'bass', n: root + [0, 7, 12, 7][i], d: 3.4 }); });
      else if (bs === 'drone') { ev[base].push({ k: 'bass', n: root, d: bar }); }
      else if (bs === 'waltz') { ev[base].push({ k: 'bass', n: root, d: 3.5 }); ev[base + 8].push({ k: 'bass', n: root + 7, d: 2 }); }
      var ac = sp.acc;
      if (ac === 'arp16') for (s = 0; s < bar; s++) ev[base + s].push({ k: 'arp', n: tones[[0, 1, 2, 1][s % 4]] + (s % 8 >= 4 ? 12 : 0), d: 0.9 });
      else if (ac === 'arp8') for (s = 0; s < bar; s += 2) ev[base + s].push({ k: 'arp', n: tones[[0, 1, 2, 1][(s / 2) % 4]] + 12, d: 1.8 });
      else if (ac === 'organ') ev[base].push({ k: 'organ', ns: tones.map(function (t) { return t - 12; }), d: bar });
      else if (ac === 'stabs') { [4, 8].forEach(function (s2) { ev[base + s2].push({ k: 'stab', ns: tones, d: 2.5 }); }); }
      else if (ac === 'bell') { R = (R * 9301 + 49297) % 233280; if (R % 3 !== 0) ev[base + 6].push({ k: 'bell', n: tones[R % 3] + 12, d: 6 }); R = (R * 9301 + 49297) % 233280; if (R % 2) ev[base + 14].push({ k: 'bell', n: tones[R % 3] + 24, d: 6 }); }
      if (sp.drums) { var kit = KITS[sp.drums], pat = kit[(b % 4 === 3) ? 1 : 0]; for (s = 0; s < bar; s++) { var dch = pat[s % pat.length]; if (dch !== '.') ev[base + s].push({ k: 'drum', t: dch }); } }
      if (sp.acc === 'organ' && sp.bass === 'drone') ev[base].push({ k: 'organ', ns: [root + 12], d: bar });
    }
    return { sp: sp, ev: ev, len: len };
  }
  /* ---------- instruments ---------- */
  function pulse(duty) {
    if (waves[duty]) return waves[duty];
    var n = 32, re = new Float32Array(n), im = new Float32Array(n);
    for (var i = 1; i < n; i++) { re[i] = 0; im[i] = (2 / (i * Math.PI)) * Math.sin(i * Math.PI * duty); }
    return (waves[duty] = A.createPeriodicWave(re, im));
  }
  function env(g, t, a, peak, dur, rel) { g.gain.setValueAtTime(0.0001, t); g.gain.linearRampToValueAtTime(peak, t + a); g.gain.setValueAtTime(peak, t + Math.max(a, dur - rel)); g.gain.exponentialRampToValueAtTime(0.0001, t + dur + 0.01); }
  function osc(type, f, t, dur, vol, o) {
    o = o || {}; var os = A.createOscillator(), g = A.createGain(), out = g;
    if (type === 'p25' || type === 'p12') os.setPeriodicWave(pulse(type === 'p25' ? 0.25 : 0.125)); else os.type = type;
    os.frequency.value = f; if (o.det) os.detune.value = o.det;
    if (o.vib) { var lf = A.createOscillator(), lg = A.createGain(); lf.frequency.value = o.vibF || 5.5; lg.gain.setValueAtTime(0, t); lg.gain.linearRampToValueAtTime(o.vib, t + Math.min(0.25, dur * 0.6)); lf.connect(lg); lg.connect(os.detune); lf.start(t); lf.stop(t + dur + 0.1); }
    if (o.lp) { var fl = A.createBiquadFilter(); fl.type = 'lowpass'; fl.frequency.value = o.lp; os.connect(fl); fl.connect(g); } else os.connect(g);
    env(g, t, o.atk || 0.008, vol, dur, o.rel || Math.min(0.12, dur * 0.4));
    out.connect(o.dest || tg); os.start(t); os.stop(t + dur + 0.08);
  }
  // two-operator FM: a modulator bends the carrier's pitch; its depth falls away after the attack, like a YM2612 patch
  function fm(f, t, dur, vol, ratio, idx, vib, fall) {
    var c = A.createOscillator(), m = A.createOscillator(), mg = A.createGain(), g = A.createGain();
    c.frequency.value = f; m.frequency.value = f * ratio;
    mg.gain.setValueAtTime(f * idx, t); mg.gain.exponentialRampToValueAtTime(Math.max(1, f * idx * 0.18), t + (fall || Math.min(0.35, dur)));
    m.connect(mg); mg.connect(c.frequency); c.connect(g);
    if (vib) { var lf = A.createOscillator(), lg = A.createGain(); lf.frequency.value = 5.8; lg.gain.setValueAtTime(0, t); lg.gain.linearRampToValueAtTime(vib, t + Math.min(0.3, dur * 0.6)); lf.connect(lg); lg.connect(c.detune); lf.start(t); lf.stop(t + dur + 0.1); }
    env(g, t, 0.004, vol, dur, Math.min(0.1, dur * 0.4)); g.connect(tg); c.start(t); m.start(t); c.stop(t + dur + 0.08); m.stop(t + dur + 0.08);
  }
  function play1(e, t, sd) {
    var d = e.d * sd, kind = song.sp.lead;
    if (e.k === 'lead' || e.k === 'harm') {
      var v = e.k === 'harm' ? 0.6 : 1, f = mf(e.n);
      if (kind === 'pulse') { osc('p25', f, t, d * 0.95, 0.05 * v, { vib: 9, det: -4 }); osc('p12', f, t, d * 0.95, 0.03 * v, { det: 5, vib: 7 }); }
      else if (kind === 'calliope') { osc('sine', f, t, d * 0.9, 0.07 * v, { vib: 22, vibF: 7.5, atk: 0.02 }); osc('triangle', f * 2, t, d * 0.9, 0.025 * v, { vib: 20, vibF: 7.5 }); }
      else if (kind === 'fm') { fm(f, t, d * 0.95, 0.06 * v, 1, 2.4, 9); fm(f * 2, t, d * 0.6, 0.012 * v, 3, 1.2, 0); }
      else if (kind === 'xylo') { osc('sine', f, t, Math.min(d, 0.4), 0.075 * v, { atk: 0.002, rel: 0.32 }); osc('sine', f * 3.93, t, 0.07, 0.022 * v, { atk: 0.002, rel: 0.06 }); }
      else if (kind === 'organlead') { [1, 2, 4].forEach(function (h, i) { osc('sine', f * h, t, d, [0.05, 0.025, 0.012][i] * v, { atk: 0.04, vib: 5 }); }); }
      else { osc('triangle', f, t, d, 0.07 * v, { atk: 0.05, vib: 12, rel: 0.3 }); osc('sine', f * 2, t, d, 0.015 * v, { atk: 0.06 }); }
    } else if (e.k === 'counter') osc('triangle', mf(e.n), t, d * 0.9, 0.045, { atk: 0.02, vib: 6 });
    else if (e.k === 'bass') { if (song.sp.fmbass) fm(mf(e.n), t, d * 0.9, 0.12, 1, 3.5, 0, 0.08); else { osc('triangle', mf(e.n), t, d, 0.11, { atk: 0.005 }); osc('p25', mf(e.n), t, d * 0.9, 0.025, { lp: 700 }); } }
    else if (e.k === 'arp') osc('p12', mf(e.n), t, d, 0.016, { lp: 3200 });
    else if (e.k === 'organ') e.ns.forEach(function (n) { [1, 2, 3].forEach(function (h, i) { osc('sine', mf(n) * h, t, d, [0.022, 0.012, 0.006][i], { atk: 0.12, rel: 0.4 }); }); });
    else if (e.k === 'stab') e.ns.forEach(function (n) { osc('sine', mf(n), t, d, 0.03, { atk: 0.01, vib: 18, vibF: 7.5 }); osc('square', mf(n), t, d * 0.5, 0.008, { lp: 1800 }); });
    else if (e.k === 'bell') { osc('sine', mf(e.n), t, d, 0.05, { atk: 0.003, rel: d * 0.9 }); osc('sine', mf(e.n) * 2.76, t, d * 0.4, 0.012, { atk: 0.003, rel: d * 0.35 }); }
    else if (e.k === 'drum') drum(e.t, t);
  }
  function drum(k, t) {
    if (k === 'k' || k === 't') {
      var os = A.createOscillator(), g = A.createGain(), f0 = k === 'k' ? 160 : 220, f1 = k === 'k' ? 42 : 90;
      os.frequency.setValueAtTime(f0, t); os.frequency.exponentialRampToValueAtTime(f1, t + 0.14); g.gain.setValueAtTime(k === 'k' ? 0.22 : 0.1, t); g.gain.exponentialRampToValueAtTime(0.0001, t + 0.18);
      os.connect(g); g.connect(tg); os.start(t); os.stop(t + 0.2); return;
    }
    var s = A.createBufferSource(), f = A.createBiquadFilter(), g2 = A.createGain(), len = k === 's' ? 0.16 : k === 'o' ? 0.22 : 0.045;
    s.buffer = nb; f.type = k === 's' ? 'bandpass' : 'highpass'; f.frequency.value = k === 's' ? 1700 : 8000; if (k === 's') f.Q.value = 0.8;
    g2.gain.setValueAtTime(k === 's' ? 0.1 : k === 'o' ? 0.035 : 0.028, t); g2.gain.exponentialRampToValueAtTime(0.0001, t + len);
    s.connect(f); f.connect(g2); g2.connect(tg); s.start(t, Math.random() * 0.4); s.stop(t + len + 0.02);
    if (k === 's') { var o2 = A.createOscillator(), g3 = A.createGain(); o2.frequency.value = 190; g3.gain.setValueAtTime(0.05, t); g3.gain.exponentialRampToValueAtTime(0.0001, t + 0.08); o2.connect(g3); g3.connect(tg); o2.start(t); o2.stop(t + 0.1); }
  }
  /* ---------- transport ---------- */
  var cache = {};
  function setup(a) {
    A = a.ctx; nb = a.nb;
    var comp = A.createDynamicsCompressor(); bus = A.createGain(); bus.gain.value = 0.6 * OPT.mus; bus.connect(comp); comp.connect(a.master);
    dl = A.createDelay(1.5); dl.delayTime.value = 0.33; var fb = A.createGain(); fb.gain.value = 0.38; var lp = A.createBiquadFilter();
    lp.type = 'lowpass'; lp.frequency.value = 2200; dl.connect(lp); lp.connect(fb); fb.connect(dl); lp.connect(bus);
  }
  function tick() {
    if (!A) { var a = sfx.audio && sfx.audio(); if (!a) return; setup(a); if (want) { var w = want; want = null; cur = null; play(w); } }
    if (!song || !tg || sfx.muted || A.state !== 'running') return;
    var sd = 60 / song.sp.bpm / 4;
    if (nextT < A.currentTime - 0.4) { nextT = A.currentTime + 0.05; T0 = nextT - stepI * sd; }
    while (nextT < A.currentTime + 0.3) { var evs = song.ev[stepI % song.len]; for (var i = 0; i < evs.length; i++) play1(evs[i], nextT, sd); nextT += sd; stepI++; }
  }
  var ALIAS = { b0: 'castle', b2: 'roof', b8: 'park', b6: 'dungeon', b7: 'town', b3: 'blum', b4: 'boss' };
  function play(id) {
    id = ALIAS[id] || id; if (!SONGS[id]) return;
    if (!A) { want = id; return; }
    if (cur === id) return;
    fadeOut(0.7);
    if (!cache[id]) cache[id] = compile(SONGS[id]);
    cur = id; song = cache[id];
    tg = A.createGain(); tg.gain.setValueAtTime(0.0001, A.currentTime); tg.gain.linearRampToValueAtTime(song.sp.vol || 1, A.currentTime + 0.8);
    if (song.sp.radio) { radioChain(tg); send = A.createGain(); send.gain.value = 0; } // an old radio: no hall reverb, everything through the little speaker
    else { tg.connect(bus); send = A.createGain(); send.gain.value = song.sp.wet; tg.connect(send); send.connect(dl); }
    stepI = 0; nextT = A.currentTime + 0.12; T0 = nextT;
  }
  /* update 131: a song played out of an old radio (Psycho Nightmare's bar). Thin (only the middle of the sound gets through
     the tiny speaker), a little overdriven, a wobble in the tuning, and static hiss with crackles under it. radioLevel(v)
     turns the whole radio up or down (how near you are to it). */
  var RAD = null, T0 = 0;
  /* update 131 (Pulsar's Octobeats): where the song is right now, in sixteenth-note steps from its first note (output latency allowed for) */
  function pos() { if (!A || !song) return -1; var lat = (A.outputLatency || 0) + (A.baseLatency || 0); return (A.currentTime - lat - T0) / (60 / song.sp.bpm / 4); }
  function radioChain(src) {
    if (RAD) { try { RAD.hp.disconnect(); RAD.noise.stop(); } catch (e) {} RAD = null; }
    var hp = A.createBiquadFilter(), lp = A.createBiquadFilter(), pk = A.createBiquadFilter(), ws = A.createWaveShaper(), out = A.createGain(), cur = new Float32Array(256);
    hp.type = 'highpass'; hp.frequency.value = 420; hp.Q.value = 0.9; lp.type = 'lowpass'; lp.frequency.value = 2400; lp.Q.value = 1.4; pk.type = 'peaking'; pk.frequency.value = 1150; pk.gain.value = 7; pk.Q.value = 1.1;
    for (var i = 0; i < 256; i++) { var x = i / 128 - 1; cur[i] = Math.tanh(x * 2.6) * 0.8; } ws.curve = cur;
    src.connect(hp); hp.connect(pk); pk.connect(lp); lp.connect(ws); ws.connect(out); out.gain.value = RAD_LEVEL; out.connect(bus);
    var len = A.sampleRate * 3, buf = A.createBuffer(1, len, A.sampleRate), d = buf.getChannelData(0), crackle = 0; // static: hiss, plus pops and crackle bursts
    for (var j = 0; j < len; j++) { var h = (Math.random() * 2 - 1) * 0.07; if (Math.random() < 0.0009) crackle = 0.6 + Math.random() * 0.4; crackle *= 0.985; d[j] = h + (Math.random() < 0.08 ? (Math.random() * 2 - 1) * crackle : 0) + (Math.random() < 0.00012 ? (Math.random() < 0.5 ? -0.9 : 0.9) : 0); }
    var ns = A.createBufferSource(), nf = A.createBiquadFilter(), ng = A.createGain(); ns.buffer = buf; ns.loop = true; nf.type = 'bandpass'; nf.frequency.value = 1800; nf.Q.value = 0.6; ng.gain.value = 0.32;
    ns.connect(nf); nf.connect(ng); ng.connect(ws); ns.start();
    var wob = A.createOscillator(), wg = A.createGain(); wob.frequency.value = 0.35; wg.gain.value = 140; wob.connect(wg); wg.connect(lp.frequency); wob.start(); // the tuning drifts
    RAD = { hp: hp, out: out, noise: ns, wob: wob, src: src };
  }
  var RAD_LEVEL = 1;
  function radioLevel(v) { RAD_LEVEL = v; if (RAD && A) RAD.out.gain.setTargetAtTime(v, A.currentTime, 0.15); }
  function fadeOut(sec) {
    if (RAD && RAD.src === tg) { var rr = RAD; RAD = null; setTimeout(function () { try { rr.noise.stop(); rr.wob.stop(); rr.out.disconnect(); } catch (e) {} }, sec * 1000 + 200); rr.out.gain.setTargetAtTime(0.0001, A.currentTime, sec / 3); }
    if (!tg) return; var g = tg, sn = send, now = A.currentTime;
    g.gain.cancelScheduledValues(now); g.gain.setValueAtTime(Math.max(0.0001, g.gain.value), now); g.gain.linearRampToValueAtTime(0.0001, now + sec);
    setTimeout(function () { try { g.disconnect(); sn.disconnect(); } catch (e) {} }, sec * 1000 + 3000);
    tg = null; send = null;
  }
  function stop(sec) { want = null; if (A) fadeOut(sec || 1); cur = null; song = null; }
  setInterval(tick, 40);
  return { play: play, stop: stop, radioLevel: radioLevel, setVol: function () { if (bus) bus.gain.value = 0.6 * OPT.mus; }, get current() { return cur; }, pos: pos, get song() { return song; }, get ctx() { return A; }, get steps() { return stepI; }, songs: SONGS, compile: compile };
})();

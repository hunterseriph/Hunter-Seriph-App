/* =====================================================================================================
   SPECIAL STAGES and the seven CUM CHALICES: Sonic 3 & Knuckles' Blue Sphere, done properly (his ask). A gothic
   gateway hides on a side route in every act (not a ring: he said it looked too much like Sonic); walk in with 50
   drops. Cumhead runs on his own across a gently curved checkered world. LEFT / RIGHT = one turn per press, made at
   the next square; A jumps two squares. Every cream sphere you run over turns RED behind you, so you cannot cross
   your own path; run round the edge of a group of cream spheres and the whole group and its loop turn into drops.
   Clear every cream sphere for the chalice; touch red and you are out. Bumpers knock you backwards (UP to run
   forwards again), gold springs throw you over four squares. It speeds up every 30 seconds.
   ===================================================================================================== */
var SS = null, SSN = 32;
var CHALNAME = ['THE BLOOD CHALICE', 'THE GOLD CHALICE', 'THE CREAM CHALICE', 'THE VOID CHALICE', 'THE TEAR CHALICE', 'THE ROT CHALICE', 'THE BLACK CHALICE'];
var CHALCOL = ['#ff2630', '#ffc840', '#f1e0b0', '#a040e0', '#3a8ac8', '#30c060', '#6a6070'];
var SSDIR = [[0, -1], [1, 0], [0, 1], [-1, 0]];
/* SEVEN WORLDS, drawn by hand like Sonic 3's (his ask: lots more red spheres that lead you on a path, not things all
   over the place). Each is one quarter, 16 x 16, mirrored left-right and top-bottom into the 32 x 32 world, so it is
   symmetric like the real ones. Cumhead starts in the middle facing up.
   b cream sphere, r red sphere, y gold spring, u bumper, o drop, . floor */
var SSQ = [
  [ // THE BLOOD CHALICE: four red rooms with a door, a block of spheres in each, a long row across the middle
    '................', '.rrrrrrrr.......', '.r......r.......', '.r.bbbb.r.......', '.r.bbbb.r...o...', '.r.bbbb.r..ooo..', '.r.bbbb.r...o...', '.r......r.......',
    '.rrr..rrr.......', '................', '................', '....bbbbbbbbb...', '...............b', '...............b', '...............b', '................'],
  [ // THE GOLD CHALICE: corridors walled with red, run them end to end
    '................', 'rrrrrrrrrrrr....', 'bbbbbbbbbbbb....', 'rrrrrrrrrrrr....', '................', '...rrrrrrrrr....', '...bbbbbbbbb.o..', '...rrrrrrrrr.o..',
    '................', '..r..r..r..r....', '..b..b..b..b....', '..b..b..b..b....', '..r..r..r..r...b', '...............b', '...............b', '................'],
  [ // THE CREAM CHALICE: ladders: up and down the columns, the red rungs stop you cutting across
    '................', '..b.b.b.b.b.....', '..b.b.b.b.b.....', '..brbrbrbrb.....', '..b.b.b.b.b.....', '..b.b.b.b.b.....', '..brbrbrbrb.....', '..b.b.b.b.b..o..',
    '..b.b.b.b.b.ooo.', '..............o.', '................', 'rrrr....rrrr....', 'bbbb....bbbb....', 'rrrr....rrrr...b', '...............b', '................'],
  [ // THE VOID CHALICE: a ring round a red heart, rows between red teeth, a box with red corners
    '................', '.bbbbbb.........', '.b....b.........', '.b.rr.b.........', '.b.rr.b...r.r.r.', '.b....b....b.b.b', '.bbbbbb...r.r.r.', '...........b.b.b',
    '..........r.r.r.', '................', '..rbbbbbr.......', '..b.....b.......', '..b.....b.......', '..b.....b......b', '..rbbbbbr......b', '................'],
  [ // THE TEAR CHALICE: a red keep: in through the gate, round the ring of spheres, a bumper in the middle
    'rrrrrrrrrrrrr...', 'r...........r...', 'r.bbbbbbbbb.r...', 'r.b.......b.r...', 'r.b.rrrrr.b.r...', 'r.b.r...r.b.r...', 'r.b.r.u.r.b.r...', 'r.b.r...r.b.r...',
    'r.b.rr.rr.b.r...', 'r.b.......b.r...', 'r.bbbbbbbbb.r..o', 'r...........r..o', 'rrrrrr.rrrrrr...', '...............b', '...............b', '................'],
  [ // THE ROT CHALICE: red lanes, bumpers in the open, four solid blocks to run round
    '................', '..u..........u..', '................', '...rrrrrrrrr....', '....bbbbbbb.....', '...rrrrrrrrr....', '................', '..bbbb...bbbb...',
    '..bbbb...bbbb...', '..bbbb...bbbb...', '..bbbb...bbbb...', '................', '.r.r.r.r.r.r.r..', '...............b', '.y.............b', '................'],
  [ // THE BLACK CHALICE: everything: a red fence, a ring, a red room with a block inside, springs over the walls
    'r.r.r.r.r.r.r.r.', '................', 'r.bbbbbbbbbbb.r.', '..b.........b...', 'r.b.rrrrrrr.b.r.', '..b.r.....r.b...', 'r.b.r.bbb.r.b.r.', '..b.r.bbb.r.b...',
    'r.b.r.bbb.r.b.r.', '..b.r.....r.b...', 'r.b.rrr.rrr.b.r.', '..bbbbb.bbbbb...', 'r.............r.', '..y............b', 'r..............b', '................']];
function ssWorld(lv) {
  var q = SSQ[Math.min(6, lv)], m = [], nb = 0;
  for (var y = 0; y < SSN; y++) { m.push([]); var qy = y < 16 ? y : 31 - y; for (var x = 0; x < SSN; x++) { var qx = x < 16 ? x : 31 - x, ch = q[qy].charAt(qx) || '.'; m[y].push(ch); if (ch === 'b') nb++; } }
  return { m: m, nb: nb };
}
function ssAt(S, x, y) { return S.m[((y % SSN) + SSN) % SSN][((x % SSN) + SSN) % SSN]; }
function ssPut(S, x, y, ch) { S.m[((y % SSN) + SSN) % SSN][((x % SSN) + SSN) % SSN] = ch; }
function startSpecial(portal) {
  var lv = 0; while (SV.chal[lv] && lv < 6) lv++;
  var w = ssWorld(lv);
  SS = { lv: lv, m: w.m, left: w.nb, total: w.nb, x: 16, y: 16, p: 0, d: 0, rev: false, cam: 0, spd: 3.0 + lv * 0.12, t: 0, drops: 0, state: 'in', st: 0, turn: 0, air: 0, airT: 0, portal: portal, anim: 0, flash: 0 };
  G.ssBack = { mode: G.mode }; G.mode = 'special'; G.super = 0; music.play('hogspecial'); sfx.play('warp'); KIT.closeMenu && KIT.menuOpen() && KIT.closeMenu();
}
/* a sphere just turned red behind him: if it closed a loop round a group of cream spheres, the group and its loop
   become drops (Blue Sphere's rings). The loop has to be his own trail, all the way round, corners too */
function ssLoop(S, px, py) {
  var got = 0, seen = {};
  for (var k = 0; k < 8; k++) {
    var sx = px + [0, 1, 1, 1, 0, -1, -1, -1][k], sy = py + [-1, -1, 0, 1, 1, 1, 0, -1][k];
    if (ssAt(S, sx, sy) !== 'b' || seen[((sy + SSN) % SSN) * SSN + ((sx + SSN) % SSN)]) continue;
    var reg = [], st = [[sx, sy]], mark = {}, leak = false;
    while (st.length && !leak) { var c = st.pop(), cx = ((c[0] % SSN) + SSN) % SSN, cy = ((c[1] % SSN) + SSN) % SSN, key = cy * SSN + cx; if (mark[key]) continue; mark[key] = 1; seen[key] = 1; reg.push([cx, cy]); if (reg.length > 120) { leak = true; break; }
      for (var j = 0; j < 8; j++) { var nx = cx + [0, 1, 1, 1, 0, -1, -1, -1][j], ny = cy + [-1, -1, 0, 1, 1, 1, 0, -1][j], ch = ssAt(S, nx, ny); if (ch === 'b') { if (j % 2 === 0) st.push([nx, ny]); else if (!mark[(((ny % SSN) + SSN) % SSN) * SSN + (((nx % SSN) + SSN) % SSN)]) st.push([nx, ny]); } else if (ch !== 'R') leak = true; } }
    if (leak) continue;
    reg.forEach(function (c) { for (var j = 0; j < 8; j++) { var nx = c[0] + [0, 1, 1, 1, 0, -1, -1, -1][j], ny = c[1] + [-1, -1, 0, 1, 1, 1, 0, -1][j]; if (ssAt(S, nx, ny) === 'R') ssPut(S, nx, ny, 'o'); } ssPut(S, c[0], c[1], 'o'); });
    S.left -= reg.length; got += reg.length;
  }
  if (got) { S.flash = 0.5; sfx.play('chalice'); G.score += got * 50; }
}
function ssArrive(S) {
  var ch = ssAt(S, S.x, S.y);
  if (ch === 'r' || ch === 'R') { S.state = 'fail'; S.st = 0; sfx.play('die'); music.play('hogclear'); return; }
  if (ch === 'b') { ssPut(S, S.x, S.y, 'R'); S.left--; sfx.play('drop'); G.score += 10; ssLoop(S, S.x, S.y); if (S.left <= 0) { S.state = 'win'; S.st = 0; SV.chal[S.lv] = 1; persist(); sfx.play('chalice'); music.stop(0.2); } return; }
  if (ch === 'o') { ssPut(S, S.x, S.y, '.'); S.drops++; G.drops++; sfx.play('drop'); if (S.drops === 50) { G.lives++; sfx.play('life'); } return; }
  if (ch === 'u') { S.rev = !S.rev; sfx.play('bump'); return; } // knocked back: he runs backwards until you press up
  if (ch === 'y') { S.air = S.airT = 4.2 / S.spd; sfx.play('spring'); }
}
function stepSpecial(dt) {
  var S = SS; S.t += dt; S.st += dt; if (S.flash > 0) S.flash -= dt;
  if (S.state === 'in') { if (S.st > 1.4) { S.state = 'play'; S.st = 0; } return; }
  if (S.state === 'win' || S.state === 'fail') { if (S.st > 4 || (S.st > 1.2 && (KIT.pressed('a') || KIT.pressed('start')))) endSpecial(); return; }
  // ONE turn per press, made at the next square (holding a direction no longer turns him again and again)
  if (KIT.pressed('left')) S.turn = -1; else if (KIT.pressed('right')) S.turn = 1;
  if (S.rev && KIT.pressed('up')) { var D0 = SSDIR[S.d]; S.x -= D0[0]; S.y -= D0[1]; S.p = 1 - S.p; S.rev = false; }
  if (KIT.pressed('a') && S.air <= 0) { S.air = S.airT = 1.9 / S.spd; sfx.play('jump'); }
  var spd = S.spd = Math.min(4.8, 3.0 + S.lv * 0.12 + Math.floor(S.t / 30) * 0.3); S.anim += spd * dt;
  S.p += spd * dt;
  if (S.air > 0) { S.air -= dt; if (S.air <= 0) S.air = 0; }
  while (S.p >= 1 && S.state === 'play') {
    S.p -= 1; var D = SSDIR[S.d], m = S.rev ? -1 : 1; S.x = (S.x + D[0] * m + SSN) % SSN; S.y = (S.y + D[1] * m + SSN) % SSN;
    if (S.air <= 0) ssArrive(S);
    if (S.turn && S.air <= 0 && S.state === 'play') { S.d = (S.d + (S.turn > 0 ? 1 : 3)) % 4; S.turn = 0; }
  }
  // the view turns smoothly to his new way
  var want = S.d * Math.PI / 2; while (want - S.cam > Math.PI) want -= Math.PI * 2; while (S.cam - want > Math.PI) want += Math.PI * 2;
  S.cam += (want - S.cam) * Math.min(1, dt * 12);
}
/* drawing: a real little planet, like Blue Sphere. Every square, sphere and drop goes through ONE projection (ssP), so
   nothing slides about: the squares are laid on a ball of radius SSR, the camera sits behind and above Cumhead, and the
   far side and the sides both curve away over the horizon */
var SSR = 20, SSCH = 4.8, SSCD = 3.6, SSPITCH = 0.55; // a gentle planet (he said the first was far too curved), camera up behind him, horizon a third of the way down like Blue Sphere
var SSK0 = (function () { var vy0 = -SSCH, vz0 = SSCD, cp = Math.cos(SSPITCH), sp = Math.sin(SSPITCH); return { k: (vy0 * cp + vz0 * sp) / (vz0 * cp - vy0 * sp), s: 1 / (vz0 * cp - vy0 * sp) }; })(); // where his feet land on screen
function ssP(l, f, up, W, H) { // l: squares to his right, f: squares ahead, up: height above the ground (squares)
  var al = l / SSR, af = f / SSR, ca = Math.cos(al), r = SSR + (up || 0);
  var nx = Math.sin(al), ny = ca * Math.cos(af), nz = ca * Math.sin(af); // the ground's normal there (also its direction from the centre)
  var x = nx * r, y = ny * r - SSR, z = nz * r; // Cumhead stands at (0,0,0) on top
  var vx = x, vy0 = y - SSCH, vz0 = z + SSCD, cp = Math.cos(SSPITCH), sp = Math.sin(SSPITCH), vz = vz0 * cp - vy0 * sp, vy = vy0 * cp + vz0 * sp; // from the camera, tipped down
  if (vz < 0.25) return null;
  var bx = nx * SSR, by = ny * SSR - SSR, bz = nz * SSR; if (nx * (-bx) + ny * (SSCH - by) + nz * (-SSCD - bz) < 0) return null; // round the back of the ball: hidden
  var F = Math.min(W * 0.1, H * 0.17) / SSK0.s; // a square under his feet is a tenth of the screen wide
  return { x: W / 2 + vx * F / vz, y: H * 0.8 - (vy / vz - SSK0.k) * F, s: F / vz, d: vz };
}
function drawSpecial() {
  var g = KIT.ctx, W = KIT.W, H = KIT.H, S = SS, cam = S.cam, ca = Math.cos(cam), sa = Math.sin(cam);
  // sky: hard bands of red night; the stars and the moon turn with him
  var bands = ['#060104', '#0a0206', '#10030a', '#18050c', '#22070e', '#2c0a10', '#360c12'];
  for (var b = 0; b < bands.length; b++) R(bands[b], 0, b * H * 0.08, W, H * 0.08 + 1);
  R('#360c12', 0, H * 0.56, W, H * 0.44);
  for (var i = 0; i < 46; i++) { var sx = ((i * 97 - cam * 160) % W + W) % W; R(i % 5 ? '#6a3a40' : '#f1e7d0', sx, (i * 37) % (H * 0.42), 1, 1); }
  var mx = ((W * 0.75 - cam * 160) % (W + 120) + W + 120) % (W + 120) - 60; g.fillStyle = '#c4121c'; g.beginPath(); g.arc(mx, H * 0.16, 16, 0, 6.3); g.fill(); g.fillStyle = '#ff2630'; g.beginPath(); g.arc(mx - 3, H * 0.16 - 3, 11, 0, 6.3); g.fill();
  var DD = SSDIR[S.d], mv = S.rev ? -1 : 1, px = S.x + DD[0] * mv * S.p, py = S.y + DD[1] * mv * S.p, tiles = [], things = [];
  function local(wx, wy) { var dx = wx - px, dy = wy - py; return { l: dx * ca + dy * sa, f: dx * sa - dy * ca }; } // f: ahead along the way he faces
  var N = 16;
  for (var ty = Math.floor(py) - N; ty <= Math.floor(py) + N + 1; ty++) for (var tx = Math.floor(px) - N; tx <= Math.floor(px) + N + 1; tx++) {
    var cc = local(tx, ty); if (cc.f < -3.2 || Math.abs(cc.l) > 13 || cc.f > 17) continue;
    var cs = [local(tx - 0.5, ty - 0.5), local(tx + 0.5, ty - 0.5), local(tx + 0.5, ty + 0.5), local(tx - 0.5, ty + 0.5)].map(function (c) { return ssP(c.l, c.f, 0, W, H); });
    if (cs.some(function (p) { return !p; })) continue;
    var d = cs[0].d + cs[1].d + cs[2].d + cs[3].d, far = Math.min(1, Math.max(0, (Math.hypot(cc.l, cc.f) - 3) / 13));
    tiles.push({ d: d, q: cs, dark: ((tx + ty) % 2 + 2) % 2, far: far });
    var ch = ssAt(S, tx, ty); if (ch !== '.') things.push({ ch: ch, l: cc.l, f: cc.f, far: far });
  }
  tiles.sort(function (a, b) { return b.d - a.d; });
  var LIGHT = ['#c4121c', '#a00e18', '#7a0a12', '#560810'], DARK = ['#3a0a10', '#2e080c', '#22060a', '#180408'];
  tiles.forEach(function (t) { var q = t.q, k = Math.min(3, Math.floor(t.far * 4)); g.fillStyle = t.dark ? DARK[k] : LIGHT[k]; g.beginPath(); g.moveTo(q[0].x, q[0].y); for (var n = 1; n < 4; n++) g.lineTo(q[n].x, q[n].y); g.closePath(); g.fill(); });
  // spheres, bumpers, springs and drops, each standing on its own square, far ones first
  things.forEach(function (o) { o.p = ssP(o.l, o.f, 0, W, H); }); things = things.filter(function (o) { return o.p; }).sort(function (a, b) { return b.p.d - a.p.d; });
  function drawThing(o) {
    var ch = o.ch, base = o.p;
    var rr = ch === 'o' ? 0.17 : 0.34, P = ssP(o.l, o.f, rr, W, H); if (!P) return; var r = Math.max(1.5, rr * P.s);
    g.fillStyle = 'rgba(0,0,0,0.45)'; g.beginPath(); g.ellipse(base.x, base.y, r * 0.95, r * 0.32, 0, 0, 6.3); g.fill(); // its shadow on the square
    if (ch === 'o') { // a cream drop, point up
      g.fillStyle = '#12040a'; g.beginPath(); g.arc(P.x, P.y, r + 1, 0, 6.3); g.fill(); g.beginPath(); g.moveTo(P.x - r * 0.7, P.y - r * 0.5); g.lineTo(P.x, P.y - r * 2.1); g.lineTo(P.x + r * 0.7, P.y - r * 0.5); g.fill();
      g.fillStyle = '#f1e7d0'; g.beginPath(); g.arc(P.x, P.y, r, 0, 6.3); g.fill(); g.beginPath(); g.moveTo(P.x - r * 0.6, P.y - r * 0.5); g.lineTo(P.x, P.y - r * 1.85); g.lineTo(P.x + r * 0.6, P.y - r * 0.5); g.fill();
      g.fillStyle = '#ffffff'; g.beginPath(); g.arc(P.x - r * 0.35, P.y - r * 0.3, r * 0.28, 0, 6.3); g.fill(); return;
    }
    var col = ch === 'R' ? ['#ffb0b8', '#ff2630', '#c4121c', '#5a0810'] : ch === 'b' ? ['#fffbe8', '#f1e0b0', '#c8a868', '#7a5a30'] : ch === 'r' ? ['#ffb0b8', '#ff2630', '#c4121c', '#5a0810'] : ch === 'u' ? ['#ffffff', '#d8d0e0', '#a098b0', '#4a4058'] : ['#fff6b0', '#ffe36a', '#d8a030', '#7a5010'];
    g.fillStyle = '#12040a'; g.beginPath(); g.arc(P.x, P.y, r + Math.max(1, r * 0.08), 0, 6.3); g.fill();
    // hard Mega Drive shading: dark rim, body, lit side, highlight
    g.fillStyle = col[3]; g.beginPath(); g.arc(P.x, P.y, r, 0, 6.3); g.fill();
    g.fillStyle = col[2]; g.beginPath(); g.arc(P.x - r * 0.08, P.y - r * 0.08, r * 0.88, 0, 6.3); g.fill();
    g.fillStyle = col[1]; g.beginPath(); g.arc(P.x - r * 0.2, P.y - r * 0.2, r * 0.66, 0, 6.3); g.fill();
    g.fillStyle = col[0]; g.beginPath(); g.arc(P.x - r * 0.38, P.y - r * 0.38, r * 0.24, 0, 6.3); g.fill();
    if (ch === 'u') { g.fillStyle = '#c4121c'; g.beginPath(); g.arc(P.x, P.y, r * 0.42, 0, 6.3); g.fill(); g.fillStyle = '#ffffff'; g.fillRect(P.x - r * 0.24, P.y - r * 0.06, r * 0.48, r * 0.12); } // a bumper
    if (ch === 'y') { g.strokeStyle = '#7a5010'; g.lineWidth = Math.max(1, r * 0.12); for (var sp = -1; sp <= 1; sp++) { g.beginPath(); g.moveTo(P.x - r * 0.6, P.y + sp * r * 0.3); g.lineTo(P.x + r * 0.6, P.y + sp * r * 0.3); g.stroke(); } } // a spring
  }
  things.forEach(drawThing); // every sphere, far ones first; Cumhead goes on top of them all, like Sonic does
  // Cumhead from behind, hopping when he jumps
  var jy = S.air > 0 ? Math.sin((1 - S.air / S.airT) * Math.PI) * (S.airT * S.spd > 3 ? 46 : 26) : 0;
  var base = ssP(0, 0, 0, W, H), sz = KIT.size('chb_u0'), csc = Math.max(1, (1.35 * base.s) / Math.max(1, sz.h)); g.fillStyle = 'rgba(0,0,0,0.45)'; g.beginPath(); g.ellipse(base.x, base.y, base.s * 0.3, base.s * 0.1, 0, 0, 6.3); g.fill();
  if (S.state !== 'fail' || Math.floor(S.st * 12) % 2) spr('chb_u' + (Math.floor(S.anim * 2.5) % 4), base.x, base.y - jy * base.s / 60, { sc: csc });
  // the count, Blue Sphere style: spheres left and drops
  KIT.panel(8, 6, 150, 26); g.fillStyle = '#e8d8a8'; g.beginPath(); g.arc(24, 19, 6, 0, 6.3); g.fill(); text(String(S.left), 36, 13, { size: 8 }); spr('hog_drop', 92, 28, {}); text(String(S.drops), 104, 13, { size: 8, col: '#ffe36a' });
  for (var c7 = 0; c7 < 7; c7++) spr('hog_chal' + c7, 20 + c7 * 20, 56, { alpha: SV.chal[c7] ? 1 : 0.22 });
  if (S.state === 'in') { var a = Math.min(1, S.st * 3); g.fillStyle = 'rgba(255,255,255,' + (1 - a).toFixed(2) + ')'; g.fillRect(0, 0, W, H); }
  if (S.state === 'in' || (S.state === 'play' && S.st < 2.5)) { text('GET ' + S.total + ' CREAM SPHERES', W / 2, H * 0.3, { size: 14, align: 'center', col: '#f1e7d0', font: 'title', outline: true }); text('AVOID THE RED ONES', W / 2, H * 0.3 + 22, { size: 8, align: 'center', col: '#ff2630', outline: true }); }
  if (S.state === 'win' || S.state === 'fail') {
    R('rgba(7,4,5,0.75)', 0, 0, W, H); var win = S.state === 'win';
    text(win ? 'CUMHEAD GOT' : 'NO CHALICE', W / 2, H * 0.24, { size: 20, align: 'center', col: '#f1e7d0', font: 'title', outline: true });
    text(win ? CHALNAME[S.lv] : 'THIS TIME', W / 2, H * 0.24 + 30, { size: 20, align: 'center', col: win ? CHALCOL[S.lv] : '#ff2630', font: 'title', outline: true });
    for (var j = 0; j < 7; j++) spr('hog_chal' + j, W / 2 + (j - 3) * 30, H * 0.66 + (win && j === S.lv ? Math.sin(S.t * 6) * 3 : 0), { sc: 1.3, alpha: SV.chal[j] ? 1 : 0.2 });
    if (win && chalCount() >= 7) text('ALL SEVEN! 50 DROPS, JUMP, HOLD UP + B: SUPER CUMHEAD', W / 2, H * 0.84, { size: 7, align: 'center', col: '#ffe36a', outline: true });
  }
}
var FXS = [];
function endSpecial() {
  var S = SS; SS = null; G.mode = 'play'; music.play(LV.zone.song); FXS = [];
  PL.vx = PL.vy = PL.gsp = 0; PL.inv = 1.2; PL.state = 'normal';
}

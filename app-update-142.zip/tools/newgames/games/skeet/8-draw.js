/* =====================================================================================================
   DRAWING: the fight (sorted by depth, shadows under everyone, hit sparks, swooshes, the weapon in your hand), the
   Street Fighter style HUD (your face, health with a damage trail, the super meter, the boss bar across the top),
   combo counter, call-outs, the super cut-in, and every screen.
   ===================================================================================================== */
function T(s, x, y, o) { KIT.text(s, x, y, o); }
/* which drawing of a fighter: moves step through their own frames by their timing (wind-up, hit, recovery) */
function moveFrame(e, L) {
  var m = e.mv, t = e.mvT; if (L.length === 1) return L[0];
  if (m.rise) return L[e.vh > 60 || !e.mf.rose ? 0 : 1];
  if (L.length === 2) return L[t < m.st ? 0 : 1];
  if (m.ac > 0.3 && t >= m.st) return L[t < m.st + m.ac ? 1 : 2]; // long active moves (dashes, flying kicks) hold the hit pose
  return L[t < m.st ? 0 : t < m.st + Math.max(m.ac, 0.06) ? 1 : 2];
}
function heroFrame(e) {
  var H = e.hero, A = H.A, st = e.st, m = e.mv;
  if (G.sup && G.sup.by === e && G.sup.t < 1.6) return A.super[0];
  if (st === 'down' || st === 'dead' || st === 'ko') return A.lie[0];
  if (st === 'air' || st === 'thrown') return A.fall[0];
  if (st === 'win') return A.win[Math.floor(e.t * 3) % 2];
  if (st === 'hurt' || st === 'grabbed') { if (e.stun > 0.8 && G.duel) return A.dizzy[Math.floor(G.t * 3) % 2]; return A.hurt[e.hurtK || 0]; }
  if (st === 'block' || st === 'guard' || e.guardHeld) return e.crouch ? A.cblock[0] : A.block[0];
  if (st === 'getup') return A.getup[0];
  if (m) return moveFrame(e, A[m.an] || A.jab);
  if (st === 'grab') return A.grab[0];
  if (e.h > 0 || st === 'jump') { var J = A.jump; return e.h < 4 && e.vh > 0 ? J[0] : e.vh > -60 ? J[1] : J[2]; }
  if (st === 'prejump') return A.jump[0];
  if (e.crouch) return A.crouch[0];
  if (st === 'run') return A.run[Math.floor(e.anim * 13) % 6];
  if (st === 'walk') { var i = Math.floor(e.anim * H.walkF) % 8; if (e.back) i = 7 - i; return A.walk[i]; }
  return A.idle[Math.floor((G.t + (e.id || 0) * 0.37) * H.idleF / 2) % 4];
}
function foeFrame(e) {
  var fr = e.fr, st = e.st;
  if (e.st === 'freedom' && fr.free) return fr.free + (e.t > 0.6 ? 'run' + (Math.floor(e.anim * 10) % 4) : 'idle0');
  if (st === 'wind') return fr.wind; if (st === 'atk' || st === 'holding') return fr.atk; if (st === 'leap') return fr.jump || fr.atk;
  if (st === 'hurt' || st === 'air' || st === 'grabbed' || st === 'thrown' || st === 'down' || st === 'dead' || st === 'getup') return fr.hurt || fr.wind;
  if (st === 'walk') return fr.walk[Math.floor(e.anim * 8) % 4];
  return fr.walk[0];
}
function bossFrame(e) {
  var d = e.def, s = e.spr;
  if (e.bid === 'titan' && e.hp <= 0) return 'h_titan_adult_hurt';
  if (e.st === 'move' && d.atk && e.pose === 'atk') return d.atk; if ((e.st === 'hurt' || e.st === 'air' || e.st === 'down') && d.hurt) return d.hurt;
  if (s.length > 2) return e.st === 'walk' || (e.st === 'move' && e.vx) ? s[1 + Math.floor(e.anim * 8) % 4] : s[0];
  return s[Math.floor(G.t * (e.st === 'move' ? 6 : 3)) % s.length];
}
function shadow(x, z, w, h) { var g = KIT.ctx, a = Math.max(0.15, 0.5 - h / 300); g.fillStyle = 'rgba(0,0,0,' + a.toFixed(2) + ')'; g.beginPath(); g.ellipse(Math.round(x), Math.round(FLOOR + z), w * 0.6 * (1 - Math.min(0.5, h / 200)), 3, 0, 0, 6.3); g.fill(); }
function drawFighter(e) {
  var x = e.x - G.cam, y = sy(e) - e.h, g = KIT.ctx, name, sc = e.sc || 1, flip, rot = 0;
  if (e.hero) { name = heroFrame(e); flip = e.face < 0; if (e.mv && e.mv.spin && e.mv.rise) flip = Math.floor(G.t * 16) % 2 ? !flip : flip; if (e.st === 'air' || e.st === 'thrown') rot = (flip ? 1 : -1) * Math.min(0.9, e.t * 3) * (e.vh > 0 ? 1 : 0.6); }
  else if (e.boss || e.assist) { name = e.assist ? e.spr[Math.floor(G.t * 3) % e.spr.length] : bossFrame(e); flip = e.face < 0; }
  else { name = foeFrame(e); flip = e.face < 0; }
  if (flip && typeof name === 'string' && /^f_(cow)?pig_\d$/.test(name) && KIT.has(name + 'L')) { name += 'L'; flip = false; } // the Piggy brothers' BROTHERS LOAD shirts never read backwards. update 131: the Cowboy Load assist only has his two frames (no foe frames: the duel crashed and only the sound ran)
  // lying down: foes without a lying frame are tipped over
  var lying = (e.st === 'down' || e.st === 'dead') && !e.hero && !(e.boss && e.bid === 'titan');
  if (lying) rot = (flip ? 1 : -1) * Math.PI / 2;
  if ((e.st === 'air' || e.st === 'thrown') && !e.hero && !e.boss) rot = (flip ? 1 : -1) * Math.min(Math.PI / 2, e.t * 5);
  if (e.st === 'dead' && Math.floor(e.t * 14) % 2) return; // blink out
  if (e.hero && e.inv > 0.05 && e.st !== 'getup' && !G.duel && Math.floor(G.t * 20) % 2 && !G.sup) return;
  var o = { flip: flip, sc: sc, flash: e.flash > 0, alpha: e.alpha !== undefined && e.alpha < 1 ? e.alpha : undefined, rot: rot || undefined };
  if (e.shade) KIT.ctx.filter = e.shade; // Blumhead's goo in a mirror match
  if (rot && e.hero) KIT.spr(name, x, y - 12, { flip: flip, rot: rot, anchor: 'c', flash: o.flash });
  else if (rot) { var sz = KIT.size(name); KIT.spr(name, x, y - sz.w * sc * 0.5 + sz.h * sc * 0.1, { flip: flip, sc: sc, rot: rot, anchor: 'c', flash: o.flash }); }
  else { // update 130: bodies give. A hit flattens them for a moment, a landing squashes, a jump stretches, and anyone standing or walking breathes
    var q = 0; if (e.flash > 0) q = -0.1; else if (e.st === 'air' || (e.hero && e.h > 2)) q = Math.max(-0.05, Math.min(0.07, (e.vh || 0) / 2600)); else if (!e.hero && !lying && e.hp > 0) q = Math.sin(G.t * (e.boss ? 2.2 : 3.2) + e.x * 0.05 + (e.z || 0) * 0.3) * (e.boss ? 0.014 : 0.02);
    if (e.h <= 0 && e.landT === undefined) e.landT = 0; if (e.h > 4) e.wasAir = 1; else if (e.wasAir) { e.wasAir = 0; e.landT = 0.12; } if (e.landT > 0) { e.landT -= 1 / 60; q = -0.09 * (e.landT / 0.12); }
    if (q) { o.sx = 1 - q * 0.8; o.sy = 1 + q; }
    KIT.spr(name, x, y, o); }
  if (e.shade) KIT.ctx.filter = 'none';
  // the goo on a brainwashed one: drips and two glowing eyes of light
  if (e.washed && e.hp > 0 && Math.random() < 0.08) G.fx.push({ k: 'drip', x: e.x + rnd(-6, 6), z: e.z, h: e.h + e.ht * rnd(0.4, 0.9), t: 0, life: 0.5 });
  if (e.bubbled > 0 && e.st === 'hurt') { g.strokeStyle = '#9adfff'; g.lineWidth = 2; g.beginPath(); g.arc(x, y - e.ht / 2, e.ht * 0.6, 0, 6.3); g.stroke(); R('#ffffff', x - e.ht * 0.3, y - e.ht * 0.8, 3, 3); }
  if (e.silly > 0) for (var i = 0; i < 3; i++) R(i % 2 ? '#ff9ad0' : '#ffffff', x + Math.cos(G.t * 6 + i * 2) * 12, y - e.ht - 4 + Math.sin(G.t * 6 + i * 2) * 3, 2, 2);
  if (e.stun > 0.9 && e.st === 'hurt' && e.boss) for (var j = 0; j < 3; j++) KIT.spr('fx_star', x + Math.cos(G.t * 5 + j * 2.1) * 16, y - e.ht * sc - 2 + Math.sin(G.t * 5 + j * 2.1) * 3, {});
  if (e.team === 'p') drawHeld(e, x, y);
  if (e.team === 'p' && e.fire > 0 && Math.random() < 0.5) G.fx.push({ k: 'spr', spr: 's_fire', x: e.x + rnd(-8, 8), z: e.z, h: e.h + rnd(10, 40), vh: 40, t: 0, life: 0.3, sc: 0.6 });
  if (e.team === 'p' && e.shieldT > 0) { g.strokeStyle = 'rgba(154,255,90,0.6)'; g.lineWidth = 2; g.beginPath(); g.ellipse(x, y - e.ht / 2, 18, e.ht * 0.6, 0, 0, 6.3); g.stroke(); }
  // a swoosh while a move is out
  var m = e.mv; if (m && m.arc && e.mvT >= m.st && e.mvT < m.st + m.ac + 0.05 && m.box) { var b = m.box, k = (e.mvT - m.st) / (m.ac + 0.05); g.strokeStyle = m.arc; g.lineWidth = 3; g.beginPath(); var cx = x + e.face * (b[0] + b[1]) / 2 * 0.7, cy = y - (b[2] + b[3]) / 2, r = (b[1] - b[0]) * 0.55; if (e.face > 0) g.arc(cx, cy, r, -1.6 + k * 0.6, -1.6 + k * 0.6 + 2.2); else g.arc(cx, cy, r, Math.PI + 1.6 - k * 0.6 - 2.2, Math.PI + 1.6 - k * 0.6); g.stroke(); g.lineWidth = 1; }
}
function drawHeld(e, x, y) {
  if (!e.weapon || e.st === 'down' || e.st === 'dead') return; var w = WEAPONS[e.weapon.id], m = e.mv, swing = 0;
  // held by the grip in his front hand, the business end pointing the way he faces (he said they were all turned round:
  // they were drawn by their middle, so half of each weapon stuck out behind him)
  if (m && m.weap) { var k = clamp(e.mvT / (m.st + m.ac), 0, 1); swing = -2.0 + k * 2.5; } else swing = -0.75 + Math.sin(G.t * 3) * 0.05;
  KIT.spr(e.weapon.id, x + e.face * 6, y - e.ht * 0.48, { flip: e.face < 0, rot: swing * e.face, anchor: 'l' });
}
function drawWorld() {
  drawBack();
  var g = KIT.ctx;
  G.puddles.forEach(function (q) { g.fillStyle = q.col; g.beginPath(); g.ellipse(q.x - G.cam, FLOOR + q.z, q.r, 4, 0, 0, 6.3); g.fill();
    if (q.fire) for (var fi = 0; fi < 5; fi++) { var fx = q.x - G.cam - q.r * 0.8 + fi * q.r * 0.4, fh = 7 + Math.abs(Math.sin(G.t * 9 + fi * 1.7)) * 8 * Math.min(1, (q.life - q.t) / 1.5); g.fillStyle = fi % 2 ? '#ff7a1a' : '#ffd23a'; g.beginPath(); g.moveTo(fx - 3, FLOOR + q.z); g.lineTo(fx, FLOOR + q.z - fh); g.lineTo(fx + 3, FLOOR + q.z); g.fill(); } });
  (G.waves || []).forEach(function (w) { g.strokeStyle = '#ffe36a'; g.lineWidth = 3; g.beginPath(); g.ellipse(w.x - G.cam, FLOOR + w.z, w.r, w.r / 2.6, 0, 0, 6.3); g.stroke(); g.strokeStyle = '#ff9a30'; g.lineWidth = 1; g.beginPath(); g.ellipse(w.x - G.cam, FLOOR + w.z, w.r - 4, (w.r - 4) / 2.6, 0, 0, 6.3); g.stroke(); });
  G.fx.forEach(function (f) { if (f.k === 'mark') { var a = Math.floor(f.t * 12) % 2; g.strokeStyle = a ? '#ff2630' : '#ffe36a'; g.lineWidth = 2; g.beginPath(); g.ellipse(f.x - G.cam, FLOOR + f.z, f.r, f.r / 3, 0, 0, 6.3); g.stroke(); g.lineWidth = 1; } });
  // everything that stands on the floor, far ones first
  var L = [];
  G.props.forEach(function (p) { L.push({ z: p.z, f: function () { shadow(p.x - G.cam, p.z, 16, 0); KIT.spr(p.spr, p.x - G.cam, FLOOR + p.z, { flash: p.flash > 0 }); } }); });
  G.items.forEach(function (it) { L.push({ z: it.z, f: function () { shadow(it.x - G.cam, it.z, 10, it.h); var bob = it.h <= 0 ? Math.round(Math.sin(G.t * 4 + it.x) * 1) : 0; KIT.spr(it.id, it.x - G.cam, FLOOR + it.z - it.h - 1 + bob, {}); if (it.h <= 0 && Math.floor(G.t * 3) % 2 && WEAPONS[it.id]) R('#ffe36a', it.x - G.cam - 1, FLOOR + it.z - 20, 2, 2); } }); });
  G.ents.concat(players()).forEach(function (e) { if (e.st === 'gone') return; L.push({ z: e.z + (e.st === 'grabbed' ? 0.1 : 0), f: function () { shadow(e.x - G.cam, e.z, e.w * (e.sc || 1), e.h); drawFighter(e); } }); });
  G.shots.forEach(function (b) { L.push({ z: b.z, f: function () { shadow(b.x - G.cam, b.z, 8, b.h); var o = { flip: b.vx < 0, anchor: 'c' }; if (b.spin) o.rot = G.t * 18; if (b.big) o.sc = 1.5; if (b.rat) { KIT.spr('f_rat_' + (Math.floor(G.t * 10) % 4), b.x - G.cam, FLOOR + b.z, { flip: b.vx < 0 }); return; } if (b.ground && b.spr === 's_wave') { KIT.spr(b.spr, b.x - G.cam, FLOOR + b.z, { flip: b.vx < 0, sc: b.big ? 1.5 : 1 }); return; }
    if (b.col && b.spr === 's_orb') { g.fillStyle = '#12040a'; g.beginPath(); g.arc(b.x - G.cam, FLOOR + b.z - b.h, 6, 0, 6.3); g.fill(); g.fillStyle = b.col; g.beginPath(); g.arc(b.x - G.cam, FLOOR + b.z - b.h, 5, 0, 6.3); g.fill(); R('#ffffff', b.x - G.cam - 2, FLOOR + b.z - b.h - 3, 2, 2); return; }
    KIT.spr(b.spr, b.x - G.cam, FLOOR + b.z - b.h, o); } }); });
  L.sort(function (a, b) { return a.z - b.z; }); L.forEach(function (l) { l.f(); });
  if (G.pl && !G.duel && window.drawTags) drawTags(); // online co-op: P1-P4 over their heads
  // effects on top
  G.fx.forEach(function (f) { var x = f.x - G.cam, y = FLOOR + (f.z || 0) - (f.h || 0), k = f.t / f.life;
    if (f.k === 'spark') { KIT.spr('fx_spark' + Math.min(3, (f.size || 1) + Math.floor(k * 2)), x, y, { anchor: 'c' }); }
    else if (f.k === 'spr') KIT.spr(f.spr, x, y, { anchor: 'c', sc: f.sc || 1, alpha: 1 - k * 0.6, rot: f.rot ? f.rot + f.t * 10 : undefined });
    else if (f.k === 'text') T(f.s, x, y - k * 16, { size: 8, align: 'center', col: f.col, outline: true, alpha: 1 - Math.max(0, k - 0.6) * 2.5 });
    else if (f.k === 'ring') { g.strokeStyle = f.col; g.lineWidth = 3 * (1 - k) + 1; g.beginPath(); g.ellipse(x, FLOOR + f.z, f.r * (0.3 + k * 0.8), f.r * (0.3 + k * 0.8) / 2.8, 0, 0, 6.3); g.stroke(); g.lineWidth = 1; }
    else if (f.k === 'drip') R('#c08aff', x, y + k * 10, 1, 2);
    else if (f.k === 'spear') { var hh = Math.min(1, k * 4) * 34; KIT.spr('s_spear', x, FLOOR + f.z + 2, { sc: hh / 31 }); }
    else if (f.k === 'column') { var cy = FLOOR + f.z; R('#2aa0a8', x - 9, 0, 18, cy); R('#7ae0e0', x - 5, 0, 6, cy); R('#e8ffff', x - 2, 0, 2, cy); KIT.spr('fx_cream', x, cy, { anchor: 'c', sc: 1.4 }); }
    else if (f.k === 'piefall') { KIT.spr('t_pie', x, FLOOR + f.z - (1 - k) * 200, { anchor: 'c', sc: 1.5 }); }
  });
  // the super beam, Blumhead's beam
  if (G.sup && G.sup.kind === 'beam' && G.sup.t > 0.7) { var S = G.sup, bx = S.x - G.cam, by = FLOOR + S.z - 30, wob = Math.sin(G.t * 40) * 2; var x0 = S.face > 0 ? bx + 10 : 0, x1 = S.face > 0 ? KIT.W : bx - 10; R('#b8a070', x0, by - 14 - wob, x1 - x0, 28 + wob * 2); R('#fffbe8', x0, by - 10, x1 - x0, 20); R('#ffffff', x0, by - 4, x1 - x0, 8); }
  if (G.sup && G.sup.kind === 'flood' && G.sup.t > 0.7) { var r = (G.sup.t - 0.7) * 380, fx = G.sup.x - G.cam; R('#4aa82a', fx - r, FLOOR + 6, r * 2, DEPTH - 4); R('#9aff5a', fx - r, FLOOR + 6, r * 2, 3); }
  if (G.beam) { var B = G.beam, bx2 = B.x - G.cam, by2 = FLOOR + B.z - 34, x02 = B.face > 0 ? bx2 + 20 : 0, x12 = B.face > 0 ? KIT.W : bx2 - 20; if (B.warn) { if (Math.floor(G.t * 16) % 2) R('#ff2630', x02, FLOOR + B.z - 1, x12 - x02, 2); } else { R('#4a1070', x02, by2 - 12, x12 - x02, 24); R('#d08aff', x02, by2 - 8, x12 - x02, 16); R('#ffd0ff', x02, by2 - 3, x12 - x02, 6); } }
  drawFront();
}
/* ---------------------------------------------------------------- the HUD */
function hpBar(x, y, w, h, k, trail, col, flip) {
  R('#12040a', x - 1, y - 1, w + 2, h + 2); R('#2a0a0e', x, y, w, h);
  var tw = Math.max(0, Math.min(1, trail)) * w, kw = Math.max(0, Math.min(1, k)) * w;
  if (flip) { R('#ffe36a', x + w - tw, y, tw, h); R(col, x + w - kw, y, kw, h); R('rgba(255,255,255,0.3)', x + w - kw, y, kw, 1); }
  else { R('#ffe36a', x, y, tw, h); R(col, x, y, kw, h); R('rgba(255,255,255,0.3)', x, y, kw, 1); }
}
function drawHUD() {
  var e = P, H = e.hero, W = KIT.W, HH = KIT.H;
  e.trail = e.trail === undefined ? e.hp : (e.trail > e.hp ? Math.max(e.hp, e.trail - e.mhp * 0.6 / 60) : e.hp);
  KIT.panel(3, 3, 30, 30, { fill: 'solid' }); KIT.spr(H.face, 18, 31, {});
  T(H.n, 37, 4, { size: 8, col: '#f1e7d0' }); T('x' + G.lives, 37 + KIT.tw(H.n, 8) + 6, 4, { size: 8, col: '#ffe36a' });
  var bw = Math.min(120, W * 0.3);
  hpBar(37, 14, bw, 6, e.hp / e.mhp, e.trail / e.mhp, e.hp < e.mhp * 0.25 && Math.floor(G.t * 6) % 2 ? '#ff2630' : '#c4121c');
  var full = e.meter >= 100, sw = (bw - 3) / 4; R('#12040a', 36, 22, bw + 2, 6); for (var i = 0; i < 4; i++) { var seg = clamp(e.meter / 25 - i, 0, 1); R('#1a0a10', 37 + i * (sw + 1), 23, sw, 4); R(full ? (Math.floor(G.t * 8) % 2 ? '#ffe36a' : '#ffffff') : '#ff9a30', 37 + i * (sw + 1), 23, sw * seg, 4); }
  if (full) T('SUPER! Y', 37, 30, { size: 8, col: Math.floor(G.t * 4) % 2 ? '#ffe36a' : '#ff2630', outline: true });
  T(String(G.score).padStart(7, '0'), W / 2 + 10, 4, { size: 8, align: 'center', col: '#ffe36a' });
  var ty = full ? 42 : 34;
  if (e.weapon) { var w = WEAPONS[e.weapon.id]; KIT.panel(3, ty, 30, 18, { fill: 'solid' }); KIT.spr(e.weapon.id, 18, ty + 9, { anchor: 'c', sc: 0.8 }); T(w.n, 37, ty, { size: 6, col: '#f1e7d0' }); KIT.bar(37, ty + 9, 60, 4, e.weapon.dur / w.dur, w.kind === 'melee' ? '#ffc840' : '#7ae0e0'); ty += 22; }
  // who you are hitting, Final Fight style
  if (G.tag && G.tagT > 0 && !G.tag.boss && G.tag.hp >= 0 && G.tag.def) { var tg = G.tag; T(tg.def.n, 37, ty, { size: 6, col: '#a6968f' }); hpBar(37, ty + 7, 80, 4, tg.hp / tg.mhp, tg.hp / tg.mhp, tg.washed ? '#9a3ad8' : '#c4121c'); }
  // boss bars, Street Fighter style, under the sound / pad / pause buttons in the corner
  var bs = G.ents.filter(function (b) { return b.boss; });
  bs.forEach(function (b, i) { b.trail = b.trail === undefined ? b.hp : (b.trail > b.hp ? Math.max(b.hp, b.trail - b.mhp * 0.3 / 60) : b.hp); var bbw = Math.min(170, W * 0.4), bx = W - bbw - 6, by = 44 + i * 18;
    T(b.def.n, W - 6, by - 9, { size: 8, align: 'right', col: b.superOn ? '#d08aff' : '#f1e7d0' }); hpBar(bx, by, bbw, 6, b.hp / b.mhp, b.trail / b.mhp, b.superOn ? '#9a3ad8' : '#c4121c', true); });
  // combo counter
  if (G.combo >= 3) { var pop = Math.max(0, G.comboT - 1.1) * 3, cy = bs.length ? 44 + bs.length * 18 : 46; T(G.combo + ' HITS', W - 8, cy, { size: 16 + Math.round(pop * 8), align: 'right', col: G.combo >= 20 ? '#ffe36a' : G.combo >= 10 ? '#ff9a30' : '#f1e7d0', outline: true, font: 'title' }); if (G.combo >= 10) T(G.combo >= 30 ? 'SKEETACULAR!' : G.combo >= 20 ? 'FILTHY!' : 'MESSY!', W - 8, cy + 20, { size: 8, align: 'right', col: '#ff2630', outline: true }); }
  if (G.callout) T(G.callout.s, W / 2, 64, { size: 8, align: 'center', col: '#ffe36a', outline: true, alpha: Math.min(1, G.callout.t * 3) });
  if (G.go > 0 && Math.floor(G.t * 3) % 2) { T('GO', W - 48, 78, { size: 24, col: '#ff2630', outline: true, font: 'title' }); var g = KIT.ctx; g.fillStyle = '#ff2630'; g.beginPath(); g.moveTo(W - 12, 90); g.lineTo(W - 22, 80); g.lineTo(W - 22, 100); g.fill(); }
  if (G.fightT > 0) { var a = G.fightT > 0.9 ? 'ROUND ' + (G.si + 1) : 'FIGHT!'; T(a, W / 2, 70, { size: 32, align: 'center', col: a === 'FIGHT!' ? '#ff2630' : '#f1e7d0', outline: true, font: 'title' }); }
  if (G.koT > 0.2 && G.koT < 2.8) T('K.O.', W / 2, 60, { size: 48, align: 'center', col: '#ff2630', outline: true, font: 'title' });
  if (G.pl && G.pl.length > 1 && window.drawMates) drawMates(ty);
  if (G.splat > 0) { var al = Math.min(1, G.splat); KIT.ctx.globalAlpha = al * 0.85; [[0.3, 0.35, 3], [0.62, 0.5, 2.6], [0.45, 0.7, 2.2], [0.75, 0.28, 1.8]].forEach(function (s) { KIT.spr('fx_cream', W * s[0], HH * s[1], { anchor: 'c', sc: s[2] }); }); KIT.ctx.globalAlpha = 1; }
  drawCutin();
}
/* ---------------------------------------------------------------- screens */
function drawCard() { // STAGE 1 / CLUBHOUSE ROW over the place itself
  var W = KIT.W, k = Math.min(1, G.cardT * 3); R('rgba(7,4,5,0.7)', 0, 0, W, KIT.H); R(G.S.tint, W / 2 - 140 * k, 84, 280 * k, 2); R(G.S.tint, W / 2 - 140 * k, 130, 280 * k, 2);
  T(G.rush ? 'BOSS RUSH ' + (G.si + 1) + ' / 6' : G.S.sub.toUpperCase(), W / 2, 68, { size: 8, align: 'center', col: '#a6968f' }); T(G.S.n, W / 2, 92, { size: 32, align: 'center', col: '#f1e7d0', outline: true, font: 'title' });
}
function drawVS() {
  var W = KIT.W, HH = KIT.H, t = G.vsT, k = Math.min(1, t * 4), H = P.hero, V = G.vsOpp, g = KIT.ctx;
  R('#070405', 0, 0, W, HH);
  g.fillStyle = '#5a0a10'; g.beginPath(); g.moveTo(0, 0); g.lineTo(W * 0.56 * k, 0); g.lineTo(W * 0.44 * k, HH); g.lineTo(0, HH); g.fill();
  g.fillStyle = '#2a0610'; g.beginPath(); g.moveTo(W, 0); g.lineTo(W - W * 0.44 * k, 0); g.lineTo(W - W * 0.56 * k, HH); g.lineTo(W, HH); g.fill();
  for (var i = 0; i < 12; i++) R('#12040a', 0, i * 19, W, 2);
  KIT.spr(H.A.idle[Math.floor(G.t * 4) % 4], W * 0.22 - (1 - k) * 200, HH - 14, { sc: 2 });
  V.art.forEach(function (a, j) { var tall = KIT.size(a.spr).h * a.sc, n = V.art.length; if (a.shade) g.filter = a.shade;
    KIT.spr(a.spr, W * 0.76 + (1 - k) * 200 + j * 44 - (n - 1) * 22, HH - 14 - j * 4, { sc: a.sc * clamp(130 / tall, 0.7, 2) * (n > 1 ? 0.8 : 1), flip: true }); g.filter = 'none'; });
  T(H.n, W * 0.22, 26, { size: 16, align: 'center', col: '#f1e7d0', outline: true, font: 'title' }); T(V.name, W * 0.76, 26, { size: 16, align: 'center', col: '#ff2630', outline: true, font: 'title', max: W * 0.44 });
  if (P.pname) T(P.pname, W * 0.22, 14, { size: 8, align: 'center', col: '#ffe36a', outline: true }); if (V.o && V.o.pname) T(V.o.pname, W * 0.76, 14, { size: 8, align: 'center', col: '#ffe36a', outline: true }); // online: who is who
  if (G.arc) T('FIGHT ' + (G.arc.i + 1) + ' OF 10', W / 2, HH - 12, { size: 8, align: 'center', col: '#ffe36a' });
  if (t > 0.35) { var s = 1 + Math.max(0, 0.6 - t) * 3; T('VS', W / 2, 84 - (s - 1) * 20, { size: Math.round(48 * s), align: 'center', col: '#ffe36a', outline: true, font: 'title' }); }
  if (t > 0.9) { KIT.wrap('"' + H.quote + '"', W * 0.4, 8).forEach(function (l, i) { T(l, W * 0.22, 50 + i * 11, { size: 8, align: 'center', col: '#f1e7d0' }); }); KIT.wrap('"' + V.quote + '"', W * 0.4, 8).forEach(function (l, i) { T(l, W * 0.76, 50 + i * 11, { size: 8, align: 'center', col: '#ff9ad0' }); }); }
}
/* the one on one HUD: Street Fighter. Two bars at the top meeting at the clock, round wins under them, meters at the bottom */
function drawDuelHUD() {
  var D = G.duel || G.lastDuel, W = KIT.W, HH = KIT.H, foe = D ? D.foe : null; if (!D || !foe) return; G.lastDuel = D;
  var bw = Math.min(150, W / 2 - 34), y = 22, cx = W / 2;
  [P, foe].forEach(function (e, i) { e.trail = e.trail === undefined ? e.hp : (e.trail > e.hp ? Math.max(e.hp, e.trail - e.mhp * 0.5 / 60) : e.hp);
    var x = i ? cx + 22 : cx - 22 - bw, low = e.hp < e.mhp * 0.25 && Math.floor(G.t * 6) % 2;
    hpBar(x, y, bw, 8, e.hp / e.mhp, e.trail / e.mhp, low ? '#ff2630' : e.superOn ? '#9a3ad8' : '#c4121c', i === 0);
    var nm = (e.pname ? e.pname + ' · ' : '') + (i ? (e.hero ? e.hero.n : oppName(D.o)) : P.hero.n);
    T(nm, i ? x + bw : x, y + 11, { size: 8, align: i ? 'right' : 'left', col: '#f1e7d0', outline: true, max: bw });
    for (var r = 0; r < 2; r++) { var wx = i ? x + bw - 6 - r * 9 : x + r * 9, on = D.wins[i] > r; R('#12040a', wx - 1, y - 8, 8, 6); R(on ? '#ffe36a' : '#2a0a0e', wx, y - 7, 6, 4); }
    if (e.hero) { var mw = Math.min(80, W * 0.22), mx = i ? W - 8 - mw : 8, full = e.meter >= 100, sw = (mw - 3) / 4; R('#12040a', mx - 1, HH - 12, mw + 2, 6);
      for (var s = 0; s < 4; s++) { var seg = clamp(e.meter / 25 - s, 0, 1), sx = i ? mx + mw - (s + 1) * (sw + 1) + 1 : mx + s * (sw + 1); R('#1a0a10', sx, HH - 11, sw, 4); R(full ? (Math.floor(G.t * 8) % 2 ? '#ffe36a' : '#ffffff') : '#ff9a30', i ? sx + sw * (1 - seg) : sx, HH - 11, sw * seg, 4); }
      if (full) T('SUPER', i ? mx + mw : mx, HH - 22, { size: 8, align: i ? 'right' : 'left', col: Math.floor(G.t * 4) % 2 ? '#ffe36a' : '#ff2630', outline: true }); }
  });
  KIT.panel(cx - 18, y - 9, 36, 22, { fill: 'solid' }); T(String(Math.ceil(D.clock)).padStart(2, '0'), cx, y - 5, { size: 16, align: 'center', col: D.clock < 10 ? '#ff2630' : '#ffe36a', font: 'px' });
  if (G.arc) T((G.arc.i + 1) + '/10', cx, y + 15, { size: 6, align: 'center', col: '#a6968f' });
  if (G.combo >= 2 && G.comboT > 0) T(G.combo + ' HITS', 10, 52, { size: 16, col: '#ffe36a', outline: true, font: 'title' });
  if (G.callout) T(G.callout.s, cx, HH - 24, { size: 8, align: 'center', col: '#ffe36a', outline: true, alpha: Math.min(1, G.callout.t * 3) }); // move names low, clear of the backdrop's signs
  if (D.phase === 'intro') { var a = D.t < 1.1 ? (D.round === 3 || (D.wins[0] === 1 && D.wins[1] === 1) ? 'FINAL ROUND' : 'ROUND ' + D.round) : 'FIGHT!'; T(a, cx, 70, { size: 32, align: 'center', col: a === 'FIGHT!' ? '#ff2630' : '#f1e7d0', outline: true, font: 'title' }); }
  if (D.phase === 'ko' && D.t > 0.1) { if (D.t < 2) T(D.msg, cx, 60, { size: D.msg === 'K.O.' ? 48 : 32, align: 'center', col: D.msg === 'PERFECT' ? '#ffe36a' : '#ff2630', outline: true, font: 'title' });
    else { var mine = G.versus ? D.winner === G.me : D.winner === P; T(G.versus ? (D.winner && D.winner.pname ? D.winner.pname : 'P' + (D.winner === P ? 1 : 2)) + ' WINS' : mine ? 'YOU WIN' : 'YOU LOSE', cx, 64, { size: 32, align: 'center', col: mine ? '#ffe36a' : '#a6968f', outline: true, font: 'title', max: KIT.W - 16 }); } }
  if (G.splat > 0) { var al = Math.min(1, G.splat); KIT.ctx.globalAlpha = al * 0.85; [[0.3, 0.35, 3], [0.62, 0.5, 2.6], [0.45, 0.7, 2.2]].forEach(function (s) { KIT.spr('fx_cream', W * s[0], HH * s[1], { anchor: 'c', sc: s[2] }); }); KIT.ctx.globalAlpha = 1; }
  drawCutin();
}
function drawCutin() {
  if (!G.cutin) return; var W = KIT.W, HH = KIT.H, ci = G.cutin, k = Math.min(1, ci.t * 5), out = Math.max(0, ci.t - 0.9) * 5; R('rgba(7,4,5,0.6)', 0, 0, W, HH); var bx2 = -W + k * W - out * W; R(ci.boss ? '#4a1070' : '#c4121c', bx2, 70, W, 60); R('#12040a', bx2, 70, W, 3); R('#12040a', bx2, 127, W, 3);
  if (!ci.boss) { if (ci.shade) KIT.ctx.filter = ci.shade; KIT.spr(ci.face || P.hero.face, bx2 + W * 0.22, 126, { sc: 2.2 }); KIT.ctx.filter = 'none'; } T(ci.n, bx2 + W * 0.6, 86, { size: 24, align: 'center', col: '#fffbe8', outline: true, font: 'title' });
}
/* between arcade fights: who won, what they said */
function drawWon() {
  var W = KIT.W, V = G.vsOpp; R('rgba(7,4,5,0.55)', 0, 54, W, 84);
  T('YOU WIN', W / 2, 58, { size: 32, align: 'center', col: '#ffe36a', outline: true, font: 'title' });
  KIT.wrap('"' + P.hero.quote + '"', W - 60, 8).forEach(function (l, i) { T(l, W / 2, 98 + i * 11, { size: 8, align: 'center', col: '#f1e7d0' }); });
  T('NEXT: FIGHT ' + (G.arc.i + 1) + ' OF 10', W / 2, 124, { size: 8, align: 'center', col: '#a6968f' });
}
function drawClear() {
  var W = KIT.W, tl = G.tally, t = G.clearT; R('rgba(7,4,5,0.82)', 0, 0, W, KIT.H);
  T(G.rush ? 'BOSS DOWN' : 'STAGE CLEAR', W / 2, 16, { size: 32, align: 'center', col: '#ffe36a', outline: true, font: 'title' });
  var rows = [['TIME BONUS', tl.time], ['BEST COMBO  x' + (G.best || 0), tl.combo], ['HOMUNCULI FREED  ' + (G.freed || 0), tl.freed], ['NO DAMAGE', tl.nodmg]];
  rows.forEach(function (r, i) { if (t < 0.4 + i * 0.35) return; T(r[0], W / 2 - 120, 62 + i * 15, { size: 8, col: '#f1e7d0' }); T(String(r[1]), W / 2 + 120, 62 + i * 15, { size: 8, align: 'right', col: r[1] ? '#ffe36a' : '#4a1a1c' }); });
  if (t > 2) { var gr = GRADES.filter(function (g) { return G.score >= g[1] * (G.si + 1) / 6; })[0]; T('SCORE ' + G.score, W / 2, 130, { size: 8, align: 'center', col: '#f1e7d0' }); T(gr ? gr[0] : 'D', W / 2, 142, { size: 32, align: 'center', col: '#ff2630', outline: true, font: 'title' }); }
  if (t > 2.6 && Math.floor(G.t * 2) % 2) T('PRESS A', W / 2, KIT.H - 16, { size: 8, align: 'center', col: '#a6968f' });
}
function drawOver() {
  var W = KIT.W, n = Math.max(0, 9 - Math.floor(G.overT)); R('rgba(7,4,5,0.8)', 0, 0, W, KIT.H);
  T('CONTINUE?', W / 2, 40, { size: 32, align: 'center', col: '#f1e7d0', outline: true, font: 'title' }); T(String(n), W / 2, 80, { size: 48, align: 'center', col: '#ff2630', outline: true, font: 'title' });
  T('A: CONTINUE      B: GIVE UP', W / 2, 150, { size: 8, align: 'center', col: '#a6968f' });
}
function drawEnd() {
  var W = KIT.W, t = G.endT; R('#070405', 0, 0, W, KIT.H); moon(W / 2, 48, 30);
  if (G.endArc) KIT.spr(P.hero.A.win[Math.floor(G.t * 3) % 2], W / 2, 112, { sc: 1.4 });
  else HEROLIST.forEach(function (h, i) { KIT.spr(HEROES[h].A.win[Math.floor(G.t * 3 + i) % 2], W / 2 + (i - (HEROLIST.length - 1) / 2) * 50, 112, {}); });
  var lines = G.endArc ? [P.hero.n + ' beat all ten.', 'Blumhead crawls back to his throne, minus a crown.', 'The Clubhouse puts your name on the wall.', 'ARCADE CLEAR', 'Thanks for playing.']
    : ['Blumhead is down. The goo drains out of Cum City.', 'Every homunculus on Clubhouse Row wakes up in their own colours.', 'They go home. The Clubhouse gets the first round in.', 'SKEET FIGHTER', 'Thanks for playing.'];
  lines.forEach(function (l, i) { if (t < 1 + i * 1.4) return; var big = l === 'SKEET FIGHTER' || l === 'ARCADE CLEAR'; T(l, W / 2, 120 + i * 15 + (i >= 3 ? 4 : 0), { size: big ? 16 : 8, align: 'center', col: big ? '#ff2630' : '#f1e7d0', font: big ? 'title' : 'px', max: W - 16 }); });
  if (t > 9 && Math.floor(G.t * 2) % 2) T('PRESS A', W / 2, KIT.H - 12, { size: 8, align: 'center', col: '#a6968f' });
}
/* the fighter select: Street Fighter style. Four portraits across the top, the one you are on stands big with its moves */
function drawSelect() {
  var W = KIT.W, HH = KIT.H, sel = G.sel || 0, H = HEROES[HEROLIST[sel]];
  R('#070405', 0, 0, W, HH); for (var i = 0; i < 12; i++) R(i % 2 ? '#0e0708' : '#120809', 0, i * 20, W, 20);
  moon(W * 0.24, 104, 40);
  T('CHOOSE YOUR FIGHTER', W / 2, 2, { size: 16, align: 'center', col: '#ff2630', outline: true, font: 'title' });
  var NH = HEROLIST.length, cw = 40, gap = 5, x0 = W / 2 - (cw * NH + gap * (NH - 1)) / 2; G.selBox = [];
  HEROLIST.forEach(function (id, i) { var h = HEROES[id], x = x0 + i * (cw + gap), y = 22, on = i === sel;
    KIT.panel(x, y, cw, 40, { edge: on ? '#ffe36a' : '#4a1a1c', fill: on ? 'rgba(90,10,16,0.95)' : 'solid' }); KIT.spr(h.face, x + cw / 2, y + 36, { sc: 1.05 }); G.selBox[i] = [x, y, cw, 40]; });
  var cyc = ['idle', 'idle', 'jab', 'cross', 'kick', 'rh', 'fire', 'idle', 'win'], an = cyc[Math.floor(G.t / 0.9) % cyc.length], L = H.A[an], ph = (G.t / 0.9) % 1;
  KIT.spr(an === 'idle' ? L[Math.floor(G.t * 4) % 4] : L[Math.min(L.length - 1, Math.floor(ph * (L.length + 1)))], W * 0.24, HH - 6, { sc: H.ht > 48 ? 2 : 2.2 });
  T(G.pickKind === 'arcade' ? 'ARCADE' : 'STORY', 8, 8, { size: 8, col: '#ffe36a' });
  var tx = W * 0.47;
  T(H.n, tx, 66, { size: 16, col: '#f1e7d0', outline: true, font: 'title' });
  // everything stacks under the one before, however many lines the blurb wraps to (it ran into the stats on his phone)
  var bl = KIT.wrap(H.blurb, W - tx - 8, 8), yy = 86; bl.forEach(function (l, i) { T(l, tx, yy + i * 10, { size: 8, col: '#a6968f' }); }); yy += bl.length * 10 + 4;
  var room = HH - 22 - yy, gapL = Math.max(9, Math.min(10, Math.floor(room / 8)));
  ['POWER', 'SPEED', 'RANGE'].forEach(function (s, i) { var y2 = yy + i * gapL; T(s, tx, y2, { size: 8, col: '#f1e7d0' }); for (var j = 0; j < 5; j++) R(j < H.stats[i] ? '#ff2630' : '#2a0a0e', tx + 50 + j * 10, y2, 8, 7); }); yy += gapL * 3 + 4;
  var sp = H.sp; [['X', sp.fire.n], ['UP+X', sp.rise.n], ['FWD+X', sp.dash.n], ['DOWN+X', sp.ground.n], ['Y', sp.sup.n]].forEach(function (r, i) { T(r[0], tx, yy + i * gapL, { size: 8, col: '#ffe36a' }); T(r[1], tx + 50, yy + i * gapL, { size: 8, col: '#f1e7d0', max: W - tx - 56 }); });
  if (G.pickKind === 'arcade' && SV.arc && SV.arc[HEROLIST[sel]]) T((SV.arcClear && SV.arcClear[HEROLIST[sel]] ? 'CLEARED' : 'BEST ' + SV.arc[HEROLIST[sel]] + '/10'), x0 + cw * NH + gap * (NH - 1) + 6, 36, { size: 8, col: '#9aff5a' });
  else if (SV.best[HEROLIST[sel]]) T('BEST ' + SV.best[HEROLIST[sel]], x0 + cw * NH + gap * (NH - 1) + 6, 36, { size: 8, col: '#9aff5a' });
  if (Math.floor(G.t * 2) % 2) T('A: FIGHT   B: BACK', W / 2, HH - 10, { size: 8, align: 'center', col: '#a6968f' });
}

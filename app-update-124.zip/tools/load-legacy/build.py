#!/usr/bin/env python3
"""Assemble Load Legacy into one self-contained HTML file, like the other games in the app.

Edit the files in src/, then run:  python3 tools/load-legacy/build.py
It writes www/games/load-legacy.html. Cumhead's atlas and the city backdrops come from tools/spermhog/assets. The homunculus art comes from tools/homunculus. sprites.png/json and icons.json were rendered from Cumheads Quest's own art.
"""
import base64, json, os, re, sys

HERE = os.path.dirname(os.path.abspath(__file__))
APP = sys.argv[1] if len(sys.argv) > 1 else os.path.normpath(os.path.join(HERE, '..', '..'))
GAMES = os.path.join(APP, 'www', 'games')
SRC = os.path.join(HERE, 'src')

head = open(os.path.join(SRC, '00-head.html'), encoding='utf-8').read()
parts = sorted(f for f in os.listdir(SRC) if f.endswith('.js'))
js = '\n'.join(open(os.path.join(SRC, f), encoding='utf-8').read() for f in parts)

# Cumhead's atlas and the city backdrops (first made for Cumhead the Spermhog) live in tools/spermhog/assets
HOGA = os.path.join(HERE, '..', 'spermhog', 'assets')
atlas = open(os.path.join(HOGA, 'atlas.json')).read().strip()
src = {}
for k in ['atlas', 'sky', 'clouds', 'skyline', 'city', 'bricks']:
    f = [x for x in os.listdir(HOGA) if x.split('.')[0] == k][0]
    src[k] = 'data:image/' + ('png' if f.endswith('png') else 'webp') + ';base64,' + base64.b64encode(open(os.path.join(HOGA, f), 'rb').read()).decode()
assert set(['atlas', 'sky', 'clouds', 'skyline', 'city', 'bricks']) <= set(src), src.keys()
# Shithead Laboozie (tools/laboozie/make.py) joins the sheet: his frames go under the others, plus the names an heir needs
import io
from PIL import Image
_sh = Image.open(os.path.join(HERE, 'sprites.png')).convert('RGBA'); _SPRJ = json.load(open(os.path.join(HERE, 'sprites.json')))
_lab = Image.open(os.path.join(HERE, '..', 'laboozie', 'lab.png')).convert('RGBA'); _LJ = json.load(open(os.path.join(HERE, '..', 'laboozie', 'lab.json'))); _LJ = _LJ.get('frames', _LJ)
_new = Image.new('RGBA', (max(_sh.width, _lab.width), _sh.height + _lab.height), (0, 0, 0, 0)); _new.paste(_sh, (0, 0)); _new.paste(_lab, (0, _sh.height))
for _k, _v in _LJ.items(): _SPRJ[_k] = [_v[0], _v[1] + _sh.height, _v[2], _v[3]]
_SPRJ['laboozie_s0'] = _SPRJ['lab_s0']; _SPRJ['laboozie_d'] = _SPRJ['lab_face']
_buf = io.BytesIO(); _new.save(_buf, 'PNG', optimize=True)
src['sheet'] = 'data:image/png;base64,' + base64.b64encode(_buf.getvalue()).decode()

# the soundtrack is Load Legacy's own now: src/15-music.js

def put(s, key, val):
    tag = '/*@' + key + '@*/'
    assert s.count(tag) == 1, key
    if key == 'MUSIC':
        return s.replace(tag, val)
    return s.replace(tag + '{}', val)

js = put(js, 'ATLAS', atlas)
js = put(js, 'SRC', json.dumps(src, separators=(',', ':')))
js = put(js, 'SPR', json.dumps(_SPRJ, separators=(',', ':')))
js = put(js, 'ICONS', open(os.path.join(HERE, 'icons.json')).read())

# the homunculus: pixel art from tools/homunculus/gen.py, merged into SPR (5th value 1 = the hom sheet)
HOMDIR = os.path.join(HERE, '..', 'homunculus')
hom = json.load(open(os.path.join(HOMDIR, 'hom.json')))
FOEDIR = os.path.join(HERE, '..', 'foes')
foes = json.load(open(os.path.join(FOEDIR, 'foes.json')))
js = js.replace("var imgs = {};", "var imgs = {};\nvar FOEFR = " + json.dumps({k: v + [2] for k, v in foes['frames'].items()}, separators=(',', ':')) + ";\nSRC.foe = 'data:image/png;base64," + base64.b64encode(open(os.path.join(FOEDIR, 'foes.png'), 'rb').read()).decode() + "';", 1)
js = js.replace("Object.keys(SRC).forEach(", "Object.keys(FOEFR).forEach(function (k) { SPR[k] = FOEFR[k]; });\nObject.keys(SRC).forEach(", 1)
js = put(js, 'HOM', json.dumps({'breeds': hom['breeds'], 'order': hom['order']}, separators=(',', ':')))
js = js.replace("Object.keys(SRC).forEach(", "Object.keys(HOMFR).forEach(function (k) { SPR[k] = HOMFR[k]; });\nObject.keys(SRC).forEach(", 1)
js = js.replace("var imgs = {};", "var imgs = {};\nvar HOMFR = " + json.dumps({k: v + [1] for k, v in hom['frames'].items()}, separators=(',', ':')) + ";\nSRC.hom = 'data:image/png;base64," + base64.b64encode(open(os.path.join(HOMDIR, 'hom.png'), 'rb').read()).decode() + "';", 1)

out = head + "\n<script>\n(function () {\n'use strict';\n" + js + "\n})();\n</script>\n\n</body></html>\n"
dst = os.path.join(GAMES, 'load-legacy.html')
open(dst, 'w', encoding='utf-8').write(out)
print('wrote', dst, len(out), 'bytes')

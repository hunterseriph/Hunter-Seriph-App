window.PNVOICE = {};
